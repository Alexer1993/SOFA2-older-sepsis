# Baseline SOFA 2 and Early SOFA 2 Trajectories Stratify Mortality Risk in Older Patients With Sepsis

This repository provides the author-owned cohort-construction, data-processing, statistical-analysis, external-validation, reviewer-analysis, and figure-generation code supporting the study **Baseline SOFA 2 and Early SOFA 2 Trajectories Stratify Mortality Risk in Older Patients With Sepsis**.

The final development cohort contains **12,643 ICU admissions from 11,138 patients** in MIMIC-IV v3.1. The final external-validation cohort contains **11,437 ICU admissions** in eICU-CRD v2.0. Individual-level patient data are not distributed in this repository.

## Important final-cohort clarification

**No exclusion criterion in the final study cohort was based on SOFA-2 availability, a SOFA-2 total of 0, or SOFA-2 score range.** Earlier working versions described a post-derivation SOFA-2 filter; that description was removed from the final manuscript and is not part of the final cohort definition.

The final flow-count anchors are:

- **MIMIC-IV:** 23,174 admissions remained after age, first-ICU, and ICU-length-of-stay eligibility; 10,531 did not meet Sepsis-3 within 0–48 h; final cohort = 12,643.
- **eICU-CRD:** 34,481 admissions remained after age, first-ICU, and ICU-length-of-stay eligibility; 21,844 did not enter the final adult sepsis-source cohort, leaving 12,637; 1,200 had missing or out-of-window sepsis timing; final cohort = 11,437.

These counts are cohort-construction audit anchors; SOFA-2 values are analyzed after cohort membership is established.

## Repository contents

```text
SOFA2-older-sepsis/
├── R/
│   ├── data_prep/          # Cohort construction and database-specific preparation
│   ├── analysis/           # Main, prediction, subgroup, sensitivity, and trajectory analyses
│   ├── figures/            # Figure assembly
│   └── reviewer_analyses/  # MaxStat bootstrap, paired AUC/C-index bootstrap, trajectory stability
├── sql/
│   ├── mimic/              # MIMIC cohort-flow audit query
│   └── eicu/               # eICU extraction blueprint and cohort-flow audit query
├── config/                 # Final analysis specifications
├── data/                   # Input-data contracts only; no patient-level data
├── outputs/                # Non-identifiable aggregate release outputs
└── docs/                   # Reproducibility guide, variable dictionary, and release notes
```

## Data access

MIMIC-IV and eICU-CRD are credentialed, deidentified databases distributed through PhysioNet. Researchers must obtain access independently and comply with the corresponding data-use agreements. Raw, intermediate, and analysis-ready patient-level files must not be committed to this repository.

## SOFA-2 scoring dependency

The MIMIC-IV SOFA-2 implementation used locally during the study was supplied as third-party code whose accompanying terms prohibit public redistribution. It is therefore not included. The public release documents the required input/output interface and all author-owned downstream processing and analysis code. See `THIRD_PARTY_CODE.md`.

For eICU, the retained analysis materials do **not** establish a fully auditable upstream rule for every missing hourly organ measurement. The public specification therefore does not assert that an unmeasured component was scored as normal or that a general LOCF rule was used. Final derived component completeness and recoverable source-field proxies should be interpreted separately.

## Software environment

- R 4.4.2 for the final analyses.
- PostgreSQL for database extraction.
- Default reproducibility seed 2026 unless a script documents another fixed seed.

Install R dependencies with:

```r
source("R/install_dependencies.R")
```

Copy `config/.Renviron.example` to a private local environment file and provide only local database credentials. Never commit passwords or tokens.

## Reproduction workflow

1. Obtain authorized MIMIC-IV v3.1 and eICU-CRD v2.0 access.
2. Reconstruct the final cohort using the cohort-flow queries and database-specific source logic. **Do not apply a SOFA-2-based inclusion/exclusion rule.**
3. Create the locally derived SOFA/SOFA-2 input fields using an authorized implementation and the variable contracts in `docs/variable_dictionary.md`.
4. Run the MIMIC preparation scripts `R/data_prep/01_*` through `09_*` and the eICU preparation scripts `11_*` through `16_*`.
5. Place the final analysis-ready RDS files under `data/analysis_ready_current/` as documented in `data/README.md`.
6. Run the principal scripts under `R/analysis/`.
7. Run reviewer analyses under `R/reviewer_analyses/` when reproducing Supplementary Tables 7–12 and the revision-specific uncertainty analyses.
8. Run `R/figures/` only after the corresponding result tables are available.

## Key revision-specific analyses

- MaxStat cutoff optimism: 500 patient-cluster bootstrap resamples, retaining all admissions from each sampled MIMIC-IV patient.
- Paired prediction uncertainty: 2,000 patient-level percentile bootstrap resamples of fixed fitted markers; differences are SOFA-2 minus SOFA and are not DeLong tests or model-refitting optimism correction.
- Multiplicity: Benjamini–Hochberg FDR across the nine prespecified subgroup interaction tests; other secondary/sensitivity analysis families remain exploratory.
- Trajectory stability: 200 random-seed K-means runs and 200 admission-level bootstrap resamples with agreement, adjusted Rand index (ARI), and normalized mutual information (NMI).
- MIMIC principal trajectory Cox models use the full primary covariate set; eICU trajectory Cox models remain adjusted for age, sex, and race/ethnicity as documented in the manuscript.
- Day 1 cumulative/dynamic AUC is not interpreted because the ≥48-h ICU-stay eligibility criterion creates a design-imposed event-free window; reported comparisons begin at Day 3.

## Primary endpoints

- **MIMIC-IV:** all-cause death within 28 days after ICU admission (`icu_28d_death`), regardless of hospital discharge.
- **eICU-CRD:** in-hospital death within 28 days after ICU admission (`mortality_28`), because post-discharge vital status is unavailable.

The two endpoints are not equivalent; absolute cross-database AUC values should not be interpreted as direct evidence of superior external predictive performance.

## Citation

Citation metadata are provided in `CITATION.cff`. Public repository: https://github.com/Alexer1993/SOFA2-older-sepsis

## License

No open-source license has been applied to the author-owned code at this time. The code is made publicly available for transparency and reproducibility. Third-party code is not included and may not be redistributed without permission.
