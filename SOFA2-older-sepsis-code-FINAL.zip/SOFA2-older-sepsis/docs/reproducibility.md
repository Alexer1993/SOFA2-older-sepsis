# Reproducibility guide

## Final analysis anchors

| Cohort | Analysis unit | Final sample | Primary endpoint | Event count |
|---|---|---:|---|---:|
| MIMIC-IV v3.1 | ICU admission | 12,643 admissions from 11,138 patients | All-cause death within 28 days after ICU admission | 3,332 |
| eICU-CRD v2.0 | ICU admission | 11,437 admissions | In-hospital death within 28 days after ICU admission | 2,124 |

The eICU endpoint does not include post-discharge deaths and is not equivalent to MIMIC-IV all-cause 28-day mortality.

## Final cohort construction

Cohort membership is determined by age, ICU-admission sequence, ICU length of stay, study-specific sepsis ascertainment/timing, and required temporal/outcome information. **SOFA-2 availability, a SOFA-2 value of 0, and SOFA-2 score range are not cohort-exclusion criteria.**

Final flow anchors:

- MIMIC-IV: 23,174 after age/first-ICU/LOS eligibility; 10,531 did not meet Sepsis-3 within 0–48 h; final 12,643.
- eICU: 34,481 after age/first-ICU/LOS eligibility; 21,844 did not enter the final adult sepsis-source cohort, leaving 12,637; 1,200 had missing/out-of-window sepsis timing; final 11,437.

The public preparation scripts include explicit guards so that an incorrect upstream count is not silently “fixed” by filtering SOFA-2.

## SOFA-2 component handling

Final SOFA/SOFA-2 variables are kept separate from the ordinary covariate-imputation pipeline. For eICU, the retained materials do not fully reconstruct the upstream hourly measurement/default rule for every organ component. Therefore, this public release does not assume that an unavailable measurement was scored as normal and does not impose a general LOCF rule. Supplementary Table 9 separates final derived-component completeness from recoverable source-field proxies.

## Script map

| Module | Principal scripts | Main result |
|---|---|---|
| Cohort flow | `sql/mimic/cohort_flow_counts.sql`, `sql/eicu/cohort_flow_counts.sql` | Final non-SOFA-defined cohort counts |
| MIMIC preparation | `R/data_prep/01_*`–`09_*` | MIMIC analysis-ready cohort |
| eICU preparation | `R/data_prep/11_*`–`16_*` | eICU external-validation cohort |
| Main association | `R/analysis/21_primary_mortality_models.R` | Continuous/grouped Cox models and splines |
| Prediction | `R/analysis/30_prediction_performance.R` | Day 3–28 adjusted time-dependent AUCs |
| Paired prediction uncertainty | `R/reviewer_analyses/paired_prediction_bootstrap.R` | 2,000 patient-level paired bootstrap intervals and MIMIC C-index differences |
| MaxStat optimism | `R/reviewer_analyses/maxstat_patient_cluster_bootstrap.R` | 500 patient-cluster resamples |
| Prespecified subgroups | `R/analysis/50_subgroup_analysis.R` | Raw interaction P values + BH-FDR q values |
| Trajectory stability | `R/reviewer_analyses/trajectory_stability.R` | 200 seed runs + 200 admission bootstraps; agreement/ARI/NMI |
| MIMIC trajectories | `R/analysis/70_*`–`72_*` | Four early dynamic severity profiles; principal full-covariate Cox models |
| eICU validation | `R/analysis/80_*`–`84_*` | Frozen-center assignment and external analyses |

## Revision-specific statistical rules

### Prediction comparison

Day 1 is not treated as an interpretable cumulative/dynamic AUC horizon because eligibility required ICU stay ≥48 h. Comparisons begin at Day 3. Paired differences are SOFA-2 minus SOFA and use 2,000 patient-level percentile bootstrap resamples, retaining repeated admissions from sampled patients. The fitted markers are held fixed; the procedure is not DeLong testing, model refitting, or optimism correction.

### Multiplicity

Benjamini–Hochberg FDR is applied jointly to the nine prespecified subgroup interaction tests. Sensitivity analyses, secondary organ outcomes, and trajectory comparisons remain correlated exploratory analyses rather than a single confirmatory multiplicity family.

### Trajectory stability

The four-class reference solution is evaluated with 200 random-seed K-means runs and 200 admission-level bootstrap resamples. Agreement, adjusted Rand index (ARI), and normalized mutual information (NMI) are reported. eICU uses frozen MIMIC day-specific scaling and frozen centers with minimum squared Euclidean distance; exact ties are resolved by the first center.

### MIMIC trajectory Cox models

Principal adjusted trajectory estimates use age, sex, Charlson Comorbidity Index, infection source, sepsis timing relative to ICU admission, ICU admission source, ICU type, and lactate. A parsimonious age/sex/race model may be shown separately but is not the principal MIMIC adjusted model.

## MaxStat bootstrap anchors

With 500 patient-cluster resamples: cutoff 8 = 40.4%, cutoff 9 = 17.0%, cutoff 10 = 42.6%; optimism-corrected C-index ≈0.5702; corrected **unadjusted** HR ≈1.85.

## Missing covariates

Ordinary covariates with >30% missingness are excluded unless structurally protected; <5% uses simple imputation; 5–30% uses missForest with seed 2026, 20 trees, maximum five iterations. Final SOFA/SOFA-2 exposure and trajectory columns are not imputed by this covariate pipeline.

## Final validation checks

- MIMIC-IV: 12,643 admissions, 11,138 patients, 3,332 primary events.
- eICU: 11,437 admissions, 2,124 in-hospital deaths within 28 days.
- Low/high cutoff: ≤8 versus >8; MIMIC n=8,971/3,672; eICU n=8,982/2,455.
- MIMIC trajectory cohort: 12,284; 359 lack Day-3 SOFA-2, seven also lack Day 2.
- No public cohort-flow script contains an 8-admission or 197-admission SOFA-2 exclusion step.
