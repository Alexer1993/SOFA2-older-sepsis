# Final public-release checklist

- [x] Public GitHub repository created.
- [x] No patient-level MIMIC-IV/eICU files included.
- [x] No credentials/tokens included.
- [x] Third-party SOFA-2 scoring code excluded and documented.
- [x] Removed all SOFA-2-based cohort-exclusion logic from public flow scripts.
- [x] Corrected final flow anchors: MIMIC 10,531; eICU 21,844; no 8/197 SOFA-2 exclusions.
- [x] Added 2,000-resample paired prediction bootstrap implementation.
- [x] Added BH-FDR implementation for nine prespecified interaction tests.
- [x] Added 200-seed/200-bootstrap trajectory stability implementation.
- [x] Principal MIMIC trajectory Cox code uses full primary covariates.
- [x] Day-1 AUC removed from interpretive prediction workflow; reporting begins Day 3.
- [x] Circular Day1–3 trajectory-class accuracy bar removed; only Day 1 and Day 1–2 anticipation remain.
- [x] Fixed Day-3 septic-shock row removed from the eICU trajectory publication table.
- [x] eICU public specification no longer asserts an unverified missing-component=0 or general LOCF rule.
- [ ] Run data-dependent scripts inside an authorized database environment and compare generated tables against the final manuscript.
- [ ] Replace the GitHub ZIP with this final audited package and update the root README to the included final README.
