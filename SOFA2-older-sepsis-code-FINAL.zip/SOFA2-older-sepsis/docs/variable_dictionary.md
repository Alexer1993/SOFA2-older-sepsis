# Core variable dictionary

This dictionary documents the fields required by the final analysis scripts. Local source names may differ, but the analysis-ready files must expose these standardized variables.

## Identifiers and timing

| Variable | Cohort | Description |
|---|---|---|
| `subject_id` | MIMIC-IV | Patient identifier used for cluster resampling |
| `hadm_id` | MIMIC-IV | Hospital-admission identifier |
| `stay_id` | MIMIC-IV | ICU-stay identifier |
| `patientunitstayid` | eICU-CRD | ICU-stay identifier |
| `icu_intime` | MIMIC-IV | ICU admission time and study time origin |
| `sepsis_time` / `sepsis3_hr` | Both | First Sepsis-3 fulfillment time; constrained to 0-48 hours after ICU admission |

## SOFA exposures

| Variable | Description |
|---|---|
| `sofa2_dynamic24_max` | MIMIC baseline 24-hour SOFA-2 total |
| `sofa2_dynamic_24h_max` | eICU baseline 24-hour SOFA-2 total |
| `sofa_dynamic24_max` | Conventional SOFA comparator |
| `sofa2_d1`, `sofa2_d2`, `sofa2_d3` | Day 1-3 SOFA-2 values used for trajectory analysis |
| Organ component fields | Six neurologic, respiratory, cardiovascular, hepatic, renal, and coagulation subscores, each constrained to 0-4 |

## Primary outcomes

| Variable | Cohort | Definition |
|---|---|---|
| `icu_28d_death` | MIMIC-IV | All-cause death within 28 days after ICU admission |
| `death_days_from_icu` | MIMIC-IV | Days from ICU admission to death; censored at day 28 for the primary model |
| `mortality_28` | eICU-CRD | In-hospital death occurring within 28 days after ICU admission |

## Main adjustment variables

The final adjusted models use age, sex, Charlson Comorbidity Index, infection source, sepsis timing, ICU admission source, ICU type, and lactate. Variable names are normalized inside the analysis scripts because source names differ across the two databases.

## Missingness contract

The analysis-ready files may contain processed or rebuilt covariates. Therefore, a zero missingness count in the final file does not establish complete measurement in the source database. Raw/pre-handling missingness must be calculated before the corresponding cleaning or imputation step.

