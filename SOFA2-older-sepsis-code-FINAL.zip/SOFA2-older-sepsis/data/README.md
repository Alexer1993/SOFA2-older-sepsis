# Local data contract

This directory must not contain data in the public repository. The following files are expected only in the researcher's authorized local checkout.

## Final analysis inputs

```text
data/analysis_ready_current/
  MIMIC_SOFA2_analysis_master_current.rds
  eICU_SOFA2_external_validation_master_current.rds
```

Expected final cohort anchors:

- MIMIC-IV: 12,643 ICU admissions from 11,138 patients; 3,332 deaths within 28 days.
- eICU-CRD: 11,437 ICU admissions; 2,124 in-hospital deaths within 28 days.

## Intermediate directories

The data-preparation scripts additionally use:

```text
data/raw/
data/raw/other/
data/processed/
data/external/eicu/
```

The MIMIC preparation scripts expect `data/raw/other/sofa_merged.csv`, `total_table.csv`, `blood_gas.csv`, `prognosis.csv`, and `infection_site.xlsx`. The eICU preparation scripts expect `data/external/eicu/eicu_external_data.xlsx`, `infection_site_inference.csv`, `infection_site_reinference.csv`, and the three files `sofa_24h.xlsx`, `sofa_48h.xlsx`, and `sofa_72h.xlsx`.

The original project used locally derived spreadsheet inputs for these fields. They contain admission-level records and are not redistributable. Users must recreate equivalent inputs from credentialed database access and map them to the fields documented in `docs/variable_dictionary.md`.

## Prohibited repository content

Do not commit patient-level CSV, RDS, XLSX, Parquet, Stata, or SPSS files; database dumps; credentials; or files containing subject, hospital-admission, ICU-stay, or patient-unit-stay identifiers. The repository `.gitignore` excludes the principal data paths and formats, but authors must still inspect staged files before publishing.

## Paired prediction bootstrap

`R/reviewer_analyses/paired_prediction_bootstrap.R` constructs the MIMIC-IV and eICU score-only and covariate-adjusted fixed markers directly from the two authorized local analysis-ready master files, then performs 2,000 patient-level paired bootstrap resamples. No separate precomputed marker file is required.
