# Public aggregate outputs

This directory contains only aggregate, non-identifiable results approved for the code release.

- `patient_cluster_bootstrap_summary.csv`: overall patient-cluster bootstrap summary.
- `patient_cluster_cutoff_distribution.csv`: frequency distribution of selected MaxStat cutoffs across 500 bootstrap resamples.

Patient-level outputs, resample membership, fitted model objects, and intermediate datasets are intentionally excluded.


Revision-specific scripts also generate paired prediction-bootstrap, BH-FDR interaction, and trajectory-stability outputs inside an authorized local analysis environment. Patient/resample-level outputs should not be committed unless they contain no patient-identifiable data; only non-identifiable aggregate summaries are intended for public release.
