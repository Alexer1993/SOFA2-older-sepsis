# Stability analysis for the prespecified four-class MIMIC-IV SOFA-2 trajectory solution.
# Final revision: 200 random-seed K-means runs and 200 admission-level bootstrap resamples.
set.seed(2026)
suppressPackageStartupMessages({ library(dplyr); library(readr) })

root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
out_dir <- file.path(root, "outputs", "reviewer_analyses", "trajectory_stability")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
obj_path <- file.path(root, "outputs", "internal_part4_cutoff_trajectory_subgroup_sensitivity", "models", "Part4_cutoff_trajectory_subgroup_sensitivity_objects.rds")
obj <- readRDS(obj_path)
train <- obj$trajectory_data
fit_ref <- obj$kmeans_k4
score_cols <- c("sofa2_d1","sofa2_d2","sofa2_d3")
if (is.null(train) || is.null(fit_ref) || !all(c(score_cols,"trajectory_raw") %in% names(train))) {
  stop("Reference trajectory object must contain trajectory_data, kmeans_k4, day 1-3 SOFA-2, and trajectory_raw.")
}
train <- train[complete.cases(train[, score_cols]), , drop=FALSE]
Xraw <- as.matrix(train[, score_cols])
mu <- colMeans(Xraw); sig <- apply(Xraw, 2, sd)
X <- sweep(sweep(Xraw, 2, mu, "-"), 2, sig, "/")
ref <- as.integer(train$trajectory_raw)
if (length(ref) != nrow(X)) stop("Reference trajectory labels do not align with the complete day 1-3 training matrix.")

ari <- function(a,b) {
  tab <- table(a,b); n <- sum(tab); c2 <- function(x) x*(x-1)/2
  sum_ij <- sum(c2(tab)); sum_a <- sum(c2(rowSums(tab))); sum_b <- sum(c2(colSums(tab))); total <- c2(n)
  expected <- if (total == 0) 0 else sum_a*sum_b/total
  maxidx <- (sum_a+sum_b)/2
  if (maxidx == expected) return(1)
  (sum_ij-expected)/(maxidx-expected)
}
nmi <- function(a,b) {
  tab <- table(a,b); pxy <- tab/sum(tab); px <- rowSums(pxy); py <- colSums(pxy)
  nz <- which(pxy>0, arr.ind=TRUE)
  mi <- sum(pxy[nz] * log(pxy[nz]/(px[nz[,1]]*py[nz[,2]])))
  hx <- -sum(px[px>0]*log(px[px>0])); hy <- -sum(py[py>0]*log(py[py>0]))
  if (hx == 0 || hy == 0) return(1)
  mi/sqrt(hx*hy)
}
perms <- function(v) {
  if(length(v)==1) return(matrix(v, nrow=1))
  do.call(rbind, lapply(seq_along(v), function(i) cbind(v[i], perms(v[-i]))))
}
P <- perms(seq_len(nrow(fit_ref$centers)))
align_labels <- function(ref,z) {
  best <- NULL; bestagree <- -Inf
  for(i in seq_len(nrow(P))) {
    zz <- P[i,z]
    ag <- mean(zz==ref)
    if(ag > bestagree) {bestagree <- ag; best <- zz}
  }
  list(labels=best, agreement=bestagree)
}

seed_rows <- vector("list",200)
for(i in seq_len(200)) {
  set.seed(20260000+i)
  km <- kmeans(X, centers=4, nstart=1, iter.max=100)
  al <- align_labels(ref, km$cluster)
  seed_rows[[i]] <- data.frame(run=i, agreement=al$agreement, ARI=ari(ref,al$labels), NMI=nmi(ref,al$labels))
}
seed_df <- bind_rows(seed_rows)

boot_rows <- vector("list",200)
set.seed(2026)
for(i in seq_len(200)) {
  idx <- sample(seq_len(nrow(X)), nrow(X), replace=TRUE)
  km <- kmeans(X[idx,,drop=FALSE], centers=4, nstart=100, iter.max=100)
  # Assign every original admission to the bootstrap centers by squared Euclidean distance.
  dist <- vapply(seq_len(4), function(k) rowSums((sweep(X, 2, km$centers[k,], "-"))^2), numeric(nrow(X)))
  pred <- max.col(-dist, ties.method="first")
  al <- align_labels(ref,pred)
  boot_rows[[i]] <- data.frame(run=i, agreement=al$agreement, ARI=ari(ref,al$labels), NMI=nmi(ref,al$labels))
}
boot_df <- bind_rows(boot_rows)

summary_one <- function(x,type) {
  data.frame(
    type=type,
    metric=c("agreement","ARI","NMI"),
    median=c(median(x$agreement),median(x$ARI),median(x$NMI)),
    p2_5=c(quantile(x$agreement,.025,names=FALSE),quantile(x$ARI,.025,names=FALSE),quantile(x$NMI,.025,names=FALSE)),
    p97_5=c(quantile(x$agreement,.975,names=FALSE),quantile(x$ARI,.975,names=FALSE),quantile(x$NMI,.975,names=FALSE))
  )
}
write_csv(seed_df,file.path(out_dir,"trajectory_random_seed_200_runs.csv"))
write_csv(boot_df,file.path(out_dir,"trajectory_bootstrap_200_runs.csv"))
write_csv(bind_rows(summary_one(seed_df,"random-seed"),summary_one(boot_df,"admission-bootstrap")),file.path(out_dir,"Supplementary_Table_7_trajectory_stability_summary.csv"))
message("Trajectory stability analysis complete: ", out_dir)
