set.seed(2026)

suppressPackageStartupMessages(library(survival))

project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
input_path <- file.path(project_root, "data", "analysis_ready_current", "MIMIC_SOFA2_analysis_master_current.rds")
out_dir <- file.path(project_root, "outputs", "reviewer_analyses", "maxstat_patient_cluster_bootstrap")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

select_maxstat_cutoff <- function(dat, minprop = 0.10) {
  x <- dat$sofa2
  candidates <- sort(unique(x[is.finite(x)]))
  candidates <- candidates[candidates > min(x, na.rm = TRUE) & candidates < max(x, na.rm = TRUE)]
  rows <- lapply(candidates, function(cut) {
    high <- x > cut
    p_high <- mean(high, na.rm = TRUE)
    if (!is.finite(p_high) || p_high < minprop || p_high > (1 - minprop)) return(NULL)
    if (length(unique(high)) < 2) return(NULL)
    stat <- tryCatch(
      survival::survdiff(Surv(time28, event28) ~ high, data = dat)$chisq,
      error = function(e) NA_real_
    )
    if (!is.finite(stat)) return(NULL)
    data.frame(cutoff = cut, chisq = stat, p_high = p_high, p_low = 1 - p_high)
  })
  tab <- do.call(rbind, rows)
  if (is.null(tab) || !nrow(tab)) return(NULL)
  tab[which.max(tab$chisq), , drop = FALSE]
}

cox_metrics_for_cutoff <- function(dat, cutoff) {
  dat$high <- as.integer(dat$sofa2 > cutoff)
  fit <- tryCatch(
    survival::coxph(Surv(time28, event28) ~ high, data = dat),
    error = function(e) NULL
  )
  if (is.null(fit)) {
    return(data.frame(HR = NA_real_, logHR = NA_real_, c_index = NA_real_))
  }
  sm <- summary(fit)
  data.frame(
    HR = unname(sm$conf.int[1, "exp(coef)"]),
    logHR = unname(sm$coefficients[1, "coef"]),
    c_index = unname(sm$concordance[1])
  )
}

master <- readRDS(input_path)
death_days <- suppressWarnings(as.numeric(master$death_days_from_icu))
event28 <- as.integer(master$icu_28d_death == 1)
time28 <- ifelse(event28 == 1 & is.finite(death_days), pmin(death_days, 28), 28)

dat <- data.frame(
  subject_id = master$subject_id,
  sofa2 = suppressWarnings(as.numeric(master$sofa2_dynamic24_max)),
  time28 = time28,
  event28 = event28
)
dat <- dat[
  !is.na(dat$subject_id) & is.finite(dat$sofa2) & is.finite(dat$time28) &
    dat$time28 > 0 & !is.na(dat$event28),
]

cluster_rows <- split(seq_len(nrow(dat)), dat$subject_id)
patient_ids <- names(cluster_rows)

apparent_selection <- select_maxstat_cutoff(dat, minprop = 0.10)
apparent_cutoff <- apparent_selection$cutoff[1]
apparent_metrics <- cox_metrics_for_cutoff(dat, apparent_cutoff)

B <- 500L
boot_rows <- vector("list", B)

for (b in seq_len(B)) {
  sampled_patients <- sample(patient_ids, length(patient_ids), replace = TRUE)
  idx <- unlist(cluster_rows[sampled_patients], use.names = FALSE)
  boot_dat <- dat[idx, , drop = FALSE]

  sel <- select_maxstat_cutoff(boot_dat, minprop = 0.10)
  if (is.null(sel)) next
  cut <- sel$cutoff[1]
  app <- cox_metrics_for_cutoff(boot_dat, cut)
  test <- cox_metrics_for_cutoff(dat, cut)

  boot_rows[[b]] <- data.frame(
    bootstrap = b,
    sampled_patients = length(sampled_patients),
    sampled_admissions = nrow(boot_dat),
    selected_cutoff = cut,
    apparent_c_index = app$c_index,
    test_c_index_original = test$c_index,
    optimism_c_index = app$c_index - test$c_index,
    apparent_logHR = app$logHR,
    test_logHR_original = test$logHR,
    optimism_logHR = app$logHR - test$logHR,
    apparent_unadjusted_HR = app$HR,
    test_unadjusted_HR_original = test$HR
  )

  if (b %% 50L == 0L) cat("Completed", b, "of", B, "resamples\n")
}

boot <- do.call(rbind, boot_rows)
mean_optimism_c <- mean(boot$optimism_c_index, na.rm = TRUE)
mean_optimism_loghr <- mean(boot$optimism_logHR, na.rm = TRUE)
corrected_c <- apparent_metrics$c_index - mean_optimism_c
corrected_loghr <- apparent_metrics$logHR - mean_optimism_loghr
corrected_unadjusted_hr <- exp(corrected_loghr)

cutoff_distribution <- as.data.frame(table(boot$selected_cutoff))
names(cutoff_distribution) <- c("selected_cutoff", "frequency")
cutoff_distribution$selected_cutoff <- as.numeric(as.character(cutoff_distribution$selected_cutoff))
cutoff_distribution$percent <- 100 * cutoff_distribution$frequency / sum(cutoff_distribution$frequency)
cutoff_distribution <- cutoff_distribution[order(cutoff_distribution$selected_cutoff), ]

summary_table <- data.frame(
  resampling_unit = "patient cluster; all admissions retained",
  seed = 2026,
  bootstrap_resamples = B,
  valid_resamples = nrow(boot),
  admissions = nrow(dat),
  patients = length(patient_ids),
  patients_with_repeated_admissions = sum(lengths(cluster_rows) > 1),
  maximum_admissions_per_patient = max(lengths(cluster_rows)),
  original_selected_cutoff = apparent_cutoff,
  apparent_c_index = apparent_metrics$c_index,
  mean_optimism_c_index = mean_optimism_c,
  optimism_corrected_c_index = corrected_c,
  apparent_unadjusted_HR = apparent_metrics$HR,
  mean_optimism_logHR = mean_optimism_loghr,
  optimism_corrected_unadjusted_HR = corrected_unadjusted_hr,
  mean_sampled_admissions = mean(boot$sampled_admissions),
  min_sampled_admissions = min(boot$sampled_admissions),
  max_sampled_admissions = max(boot$sampled_admissions)
)

write.csv(boot, file.path(out_dir, "patient_cluster_bootstrap_resamples.csv"), row.names = FALSE)
write.csv(cutoff_distribution, file.path(out_dir, "patient_cluster_cutoff_distribution.csv"), row.names = FALSE)
write.csv(summary_table, file.path(out_dir, "patient_cluster_bootstrap_summary.csv"), row.names = FALSE)

cat("\nPatient-cluster bootstrap summary\n")
print(summary_table)
cat("\nCutoff distribution\n")
print(cutoff_distribution)

