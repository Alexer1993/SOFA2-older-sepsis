# Paired patient-level bootstrap uncertainty for SOFA-2 minus conventional SOFA.
# Final revision: 2,000 patient-level resamples; fixed fitted markers; no model refitting;
# percentile 95% intervals; not DeLong and not optimism correction.
set.seed(20260905)

suppressPackageStartupMessages({
  library(survival)
  library(dplyr)
  library(readr)
})

root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
out_dir <- file.path(root, "outputs", "reviewer_analyses", "paired_prediction_bootstrap")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
B <- 2000L
horizons <- c(3, 7, 14, 21, 28)

to_num <- function(x) suppressWarnings(as.numeric(as.character(x)))
to_binary <- function(x) {
  if (is.numeric(x) || is.integer(x)) return(as.integer(x > 0))
  z <- tolower(trimws(as.character(x)))
  out <- rep(NA_integer_, length(z))
  out[z %in% c("1","yes","y","true","t","male","m")] <- 1L
  out[z %in% c("0","no","n","false","f","female")] <- 0L
  out
}
parse_time <- function(x) {
  if (inherits(x, "POSIXct")) return(x)
  as.POSIXct(as.character(x), tz = "UTC", tryFormats = c("%Y-%m-%d %H:%M:%S","%Y-%m-%d %H:%M","%Y-%m-%d"))
}
collapse_source <- function(x) {
  z <- tolower(trimws(enc2utf8(as.character(x))))
  out <- rep("Other/undetermined", length(z))
  out[grepl("pulmonary|lung|respir|pneumonia", z)] <- "Pulmonary"
  out[grepl("urinary|urine|uti|renal|kidney", z)] <- "Urinary"
  out[grepl("abdominal|abdomen|biliary|gastro|gi|intra|periton", z)] <- "Abdominal"
  out[grepl("bloodstream|blood stream|bacteremia|catheter|blood", z)] <- "Bloodstream"
  out[grepl("skin|soft tissue", z)] <- "Skin/soft tissue"
  factor(out, levels = c("Pulmonary","Urinary","Abdominal","Bloodstream","Skin/soft tissue","Other/undetermined"))
}
collapse_icu_admission_source_eicu <- function(unit_source, hosp_source) {
  z <- tolower(paste(unit_source, hosp_source))
  out <- rep("Other_unknown", length(z))
  out[grepl("emergency|ed", z)] <- "Emergency_department"
  out[grepl("operating|or|recovery|pacu|procedure", z)] <- "Procedure_or_OR"
  out[grepl("transfer|other hospital|floor|ward", z)] <- "Other_hospital_or_ward"
  out[grepl("direct|clinic|home|office", z)] <- "Ward_or_clinic"
  factor(out, levels = c("Emergency_department","Procedure_or_OR","Other_hospital_or_ward","Ward_or_clinic","Other_unknown"))
}
collapse_icu_type_eicu <- function(x) {
  z <- tolower(as.character(x))
  out <- rep("Other_ICU", length(z))
  out[grepl("med|micu", z)] <- "Medical_ICU"
  out[grepl("card|ccu|cv", z)] <- "Cardiovascular_ICU"
  out[grepl("surg|trauma|neuro", z)] <- "Surgical_trauma_ICU"
  factor(out, levels = c("Medical_ICU","Cardiovascular_ICU","Surgical_trauma_ICU","Other_ICU"))
}
prep_complete <- function(data, vars) {
  z <- data[, vars, drop = FALSE]
  z <- z[complete.cases(z), , drop = FALSE]
  for (nm in names(z)) if (is.factor(z[[nm]])) z[[nm]] <- droplevels(z[[nm]])
  z
}
drop_bad <- function(data, vars) {
  keep <- vars
  for (v in vars) {
    if (!v %in% names(data)) keep <- setdiff(keep, v)
    else if (is.factor(data[[v]]) && nlevels(data[[v]]) < 2) keep <- setdiff(keep, v)
    else if (!is.factor(data[[v]]) && length(unique(data[[v]])) < 2) keep <- setdiff(keep, v)
  }
  keep
}

auc_cd <- function(time, status, marker, t) {
  case <- status == 1 & time <= t
  control <- time > t
  ok <- is.finite(marker) & !is.na(case) & !is.na(control) & (case | control)
  case <- case[ok]; control <- control[ok]; marker <- marker[ok]
  if (sum(case) == 0 || sum(control) == 0) return(NA_real_)
  ranks <- rank(marker, ties.method = "average")
  n1 <- sum(case); n0 <- sum(control)
  (sum(ranks[case]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}

cindex_harrell <- function(time, status, marker) {
  as.numeric(survival::concordance(survival::Surv(time, status) ~ marker, reverse = TRUE)$concordance)
}

cluster_boot <- function(dat, id, marker2, marker1, label, horizons = horizons, B = B) {
  ids <- unique(dat[[id]])
  obs <- data.frame(
    cohort_model = label,
    day = horizons,
    SOFA2 = vapply(horizons, function(t) auc_cd(dat$time, dat$status, dat[[marker2]], t), numeric(1)),
    SOFA = vapply(horizons, function(t) auc_cd(dat$time, dat$status, dat[[marker1]], t), numeric(1))
  )
  obs$difference <- obs$SOFA2 - obs$SOFA
  boot <- matrix(NA_real_, nrow = B, ncol = length(horizons))
  for (b in seq_len(B)) {
    sampled <- sample(ids, length(ids), replace = TRUE)
    db <- bind_rows(lapply(seq_along(sampled), function(k) {
      z <- dat[dat[[id]] == sampled[k], , drop = FALSE]
      z$.boot_cluster <- k
      z
    }))
    boot[b, ] <- vapply(horizons, function(t) {
      auc_cd(db$time, db$status, db[[marker2]], t) - auc_cd(db$time, db$status, db[[marker1]], t)
    }, numeric(1))
  }
  ci <- t(apply(boot, 2, stats::quantile, probs = c(.025, .975), na.rm = TRUE, names = FALSE))
  obs$ci_low <- ci[, 1]
  obs$ci_high <- ci[, 2]
  list(summary = obs, bootstrap = boot)
}

cindex_boot <- function(dat, id, m2, m1, label) {
  ids <- unique(dat[[id]])
  apparent <- c(
    cindex_harrell(dat$time, dat$status, dat[[m2]]),
    cindex_harrell(dat$time, dat$status, dat[[m1]])
  )
  diffs <- rep(NA_real_, B)
  for (b in seq_len(B)) {
    sampled <- sample(ids, length(ids), replace = TRUE)
    db <- bind_rows(lapply(sampled, function(sid) dat[dat[[id]] == sid, , drop = FALSE]))
    diffs[b] <- cindex_harrell(db$time, db$status, db[[m2]]) - cindex_harrell(db$time, db$status, db[[m1]])
  }
  ci <- quantile(diffs, c(.025, .975), na.rm = TRUE, names = FALSE)
  data.frame(model_pair = label, SOFA2 = apparent[1], SOFA = apparent[2], difference = apparent[1]-apparent[2], ci_low = ci[1], ci_high = ci[2])
}

# ---------- MIMIC-IV ----------
m0 <- readRDS(file.path(root, "data", "analysis_ready_current", "MIMIC_SOFA2_analysis_master_current.rds"))
mi <- parse_time(m0$icu_intime)
ms <- parse_time(m0$sepsis_time)
status_m <- as.integer(m0$icu_28d_death == 1)
time_m <- ifelse(status_m == 1, pmin(pmax(to_num(m0$death_days_from_icu), .5), 28), 28.001)
md <- data.frame(
  subject_id = m0$subject_id, time = time_m, status = status_m,
  sofa2 = to_num(m0$sofa2_dynamic24_max), sofa = to_num(m0$sofa_dynamic24_max),
  age = to_num(m0$age), male = to_binary(m0$gender), charlson = to_num(m0$charlson),
  infection_source = collapse_source(m0$infection_site_main_enriched),
  sepsis_onset_h = as.numeric(difftime(ms, mi, units = "hours")),
  admission_source = factor(m0$admission_location), icu_type = factor(m0$careunit), lactate = to_num(m0$lactate_first)
)
score_m <- prep_complete(md, c("subject_id","time","status","sofa2","sofa"))
adj_vars_m <- c("age","male","charlson","infection_source","sepsis_onset_h","admission_source","icu_type","lactate")
adj_m <- prep_complete(md, c("subject_id","time","status","sofa2","sofa",adj_vars_m))
adj_vars_m <- drop_bad(adj_m, adj_vars_m)
fm2 <- coxph(as.formula(paste("Surv(time,status) ~", paste(c("sofa2",adj_vars_m), collapse=" + "))), data=adj_m, ties="efron")
fm1 <- coxph(as.formula(paste("Surv(time,status) ~", paste(c("sofa",adj_vars_m), collapse=" + "))), data=adj_m, ties="efron")
adj_m$lp_sofa2 <- as.numeric(predict(fm2, type="lp"))
adj_m$lp_sofa <- as.numeric(predict(fm1, type="lp"))

res <- list(
  cluster_boot(score_m, "subject_id", "sofa2", "sofa", "MIMIC score-only"),
  cluster_boot(adj_m, "subject_id", "lp_sofa2", "lp_sofa", "MIMIC adjusted")
)

cidx <- bind_rows(
  cindex_boot(score_m,"subject_id","sofa2","sofa","SOFA-2 vs SOFA"),
  cindex_boot(adj_m,"subject_id","lp_sofa2","lp_sofa","SOFA-2 + clinical vs SOFA + clinical")
)

# ---------- eICU-CRD ----------
e0 <- readRDS(file.path(root, "data", "analysis_ready_current", "eICU_SOFA2_external_validation_master_current.rds"))
if (!"uniquepid" %in% names(e0)) stop("eICU master must contain uniquepid for patient-level bootstrap resampling.")
status_e <- as.integer(e0$mortality_28 == 1)
hosp_days <- to_num(e0$hospitaldischargeoffset) / 1440
unit_days <- to_num(e0$unitdischargeoffset) / 1440
event_time <- ifelse(!is.na(hosp_days), hosp_days, unit_days)
time_e <- ifelse(status_e == 1, pmax(pmin(event_time, 28), .5), 28.001)
infection_field <- if ("infection_site_collapsed_final_eicu" %in% names(e0)) e0$infection_site_collapsed_final_eicu else e0$infection_site_main_final_eicu
sepsis_field <- if ("sepsis3_hr_for_window" %in% names(e0)) e0$sepsis3_hr_for_window else e0$sepsis3_hr
ed <- data.frame(
  uniquepid = as.character(e0$uniquepid), time = time_e, status = status_e,
  sofa2 = to_num(e0$sofa2_dynamic_24h_max), sofa = to_num(e0$sofa_dynamic_24h_max),
  age = to_num(e0$age), male = to_binary(e0$gender), charlson = to_num(e0$charlson),
  infection_source = collapse_source(infection_field), sepsis_onset_h = to_num(sepsis_field),
  admission_source = collapse_icu_admission_source_eicu(e0$unitadmitsource, e0$hospitaladmitsource),
  icu_type = collapse_icu_type_eicu(e0$unittype), lactate = to_num(e0$lactate_first)
)
score_e <- prep_complete(ed, c("uniquepid","time","status","sofa2","sofa"))
adj_vars_e <- c("age","male","charlson","infection_source","sepsis_onset_h","admission_source","icu_type","lactate")
adj_e <- prep_complete(ed, c("uniquepid","time","status","sofa2","sofa",adj_vars_e))
adj_vars_e <- drop_bad(adj_e, adj_vars_e)
fe2 <- coxph(as.formula(paste("Surv(time,status) ~", paste(c("sofa2",adj_vars_e), collapse=" + "))), data=adj_e, ties="efron")
fe1 <- coxph(as.formula(paste("Surv(time,status) ~", paste(c("sofa",adj_vars_e), collapse=" + "))), data=adj_e, ties="efron")
adj_e$lp_sofa2 <- as.numeric(predict(fe2, type="lp"))
adj_e$lp_sofa <- as.numeric(predict(fe1, type="lp"))
res[[length(res)+1]] <- cluster_boot(score_e, "uniquepid", "sofa2", "sofa", "eICU score-only")
res[[length(res)+1]] <- cluster_boot(adj_e, "uniquepid", "lp_sofa2", "lp_sofa", "eICU adjusted")

summary_out <- bind_rows(lapply(res, `[[`, "summary"))
write_csv(summary_out, file.path(out_dir, "Supplementary_Table_11_paired_AUC_bootstrap.csv"))
write_csv(cidx, file.path(out_dir, "Supplementary_Table_11_MIMIC_paired_Cindex_bootstrap.csv"))
write_csv(data.frame(
  population=c("MIMIC score-only","MIMIC adjusted","eICU score-only","eICU adjusted"),
  n=c(nrow(score_m),nrow(adj_m),nrow(score_e),nrow(adj_e)),
  events=c(sum(score_m$status),sum(adj_m$status),sum(score_e$status),sum(adj_e$status))
), file.path(out_dir,"paired_bootstrap_population_QC.csv"))
message("Paired prediction bootstrap complete: ", out_dir)
