description <- read.dcf("DESCRIPTION")
imports <- trimws(unlist(strsplit(description[1, "Imports"], ",")))
imports <- imports[nzchar(imports)]
missing <- imports[!vapply(imports, requireNamespace, logical(1), quietly = TRUE)]

if (length(missing)) {
  install.packages(missing, repos = "https://cloud.r-project.org")
} else {
  message("All declared R dependencies are already installed.")
}

