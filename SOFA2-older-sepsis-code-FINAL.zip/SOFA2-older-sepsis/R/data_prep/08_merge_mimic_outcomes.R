project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)

required_packages <- c("dplyr", "readr", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

processed_dir <- file.path(project_root, "data", "processed")
table_dir <- file.path(project_root, "outputs", "tables")
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

sofa_path <- file.path(processed_dir, "SOFA2_analysis_modeling_reference_sofa.rds")
outcomes_path <- file.path(processed_dir, "SOFA2_outcomes_master.rds")

sofa <- readRDS(sofa_path)
outcomes <- readRDS(outcomes_path)

id_cols <- c("subject_id", "hadm_id", "stay_id")
if (!all(id_cols %in% names(sofa)) || !all(id_cols %in% names(outcomes))) {
  stop("ID columns are missing from the SOFA table or outcomes table.")
}

if (anyDuplicated(sofa[id_cols]) > 0) {
  stop("Duplicate subject_id/hadm_id/stay_id combinations in the SOFA table.")
}
if (anyDuplicated(outcomes[id_cols]) > 0) {
  stop("Duplicate subject_id/hadm_id/stay_id combinations in the outcomes table.")
}

outcome_non_id_cols <- setdiff(names(outcomes), id_cols)
overlap_cols <- intersect(outcome_non_id_cols, names(sofa))

same_overlap <- vapply(overlap_cols, function(nm) {
  identical(sofa[[nm]], outcomes[[nm]])
}, logical(1))

drop_from_outcomes <- overlap_cols[same_overlap]
rename_from_outcomes <- overlap_cols[!same_overlap]

outcomes_for_join <- outcomes |>
  dplyr::select(-dplyr::any_of(drop_from_outcomes))

if (length(rename_from_outcomes) > 0) {
  names(outcomes_for_join)[match(rename_from_outcomes, names(outcomes_for_join))] <-
    paste0(rename_from_outcomes, "_outcome")
}

latest <- sofa |>
  dplyr::left_join(outcomes_for_join, by = id_cols)

if (nrow(latest) != nrow(sofa)) {
  stop("Merged table row count changed.")
}

if (anyDuplicated(latest[id_cols]) > 0) {
  stop("Merged table contains duplicate IDs.")
}

missing_outcome_rows <- latest |>
  dplyr::filter(is.na(.data$icu_free_days_28)) |>
  nrow()

if (missing_outcome_rows > 0) {
  stop("Some SOFA cohort rows did not match outcomes_master: ", missing_outcome_rows)
}

out_csv <- file.path(processed_dir, "SOFA2_latest_sofa_with_outcomes.csv")
out_rds <- file.path(processed_dir, "SOFA2_latest_sofa_with_outcomes.rds")
merge_report_csv <- file.path(table_dir, "SOFA2_latest_sofa_with_outcomes_merge_report.csv")

readr::write_csv(latest, out_csv)
saveRDS(latest, out_rds)

merge_report <- data.frame(
  item = c(
    "sofa_rows",
    "outcomes_rows",
    "merged_rows",
    "sofa_columns",
    "outcomes_columns",
    "merged_columns",
    "identical_overlap_columns_dropped",
    "nonidentical_overlap_columns_renamed",
    "missing_outcome_rows"
  ),
  value = c(
    nrow(sofa),
    nrow(outcomes),
    nrow(latest),
    ncol(sofa),
    ncol(outcomes),
    ncol(latest),
    length(drop_from_outcomes),
    length(rename_from_outcomes),
    missing_outcome_rows
  )
)
readr::write_csv(merge_report, merge_report_csv)

key_outcome_summary <- data.frame(
  outcome = c(
    "ICU death",
    "Hospital death",
    "90-day death",
    "365-day death",
    "28-day ventilator-free days, mean",
    "28-day vasopressor-free days, mean",
    "28-day RRT-free days, mean",
    "28-day ICU-free days, mean",
    "Day 3 new invasive ventilation",
    "Day 3 new septic shock",
    "Day 3 new AKI",
    "Day 3 new RRT"
  ),
  value = c(
    sum(latest$icu_expire_flag == 1, na.rm = TRUE),
    sum(latest$hospital_expire_flag == 1, na.rm = TRUE),
    sum(latest$mortality_90 == 1, na.rm = TRUE),
    sum(latest$mortality_365 == 1, na.rm = TRUE),
    mean(latest$invasive_vent_free_days_28, na.rm = TRUE),
    mean(latest$vasopressor_free_days_28, na.rm = TRUE),
    mean(latest$rrt_free_days_28, na.rm = TRUE),
    mean(latest$icu_free_days_28, na.rm = TRUE),
    sum(latest$day3_new_invasive_vent == 1, na.rm = TRUE),
    sum(latest$day3_new_septic_shock == 1, na.rm = TRUE),
    sum(latest$day3_new_aki == 1, na.rm = TRUE),
    sum(latest$day3_new_rrt == 1, na.rm = TRUE)
  ),
  denominator = c(
    nrow(latest), nrow(latest), nrow(latest), nrow(latest),
    nrow(latest), nrow(latest), nrow(latest), nrow(latest),
    sum(latest$day3_preexisting_invasive_vent == 0, na.rm = TRUE),
    sum(latest$day3_preexisting_septic_shock == 0, na.rm = TRUE),
    sum(latest$day3_preexisting_aki == 0, na.rm = TRUE),
    sum(latest$day3_preexisting_rrt == 0, na.rm = TRUE)
  )
)
readr::write_csv(
  key_outcome_summary,
  file.path(table_dir, "SOFA2_latest_sofa_with_outcomes_key_summary.csv")
)

manifest <- list(
  project = "SOFA2 older sepsis",
  output_name = "SOFA2_latest_sofa_with_outcomes",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  description = "Latest analysis-ready SOFA table. Covariates come from SOFA2_analysis_modeling_reference_sofa, where SOFA/SOFA2 exposure and trajectory columns are raw/non-imputed; prognosis/outcome variables come from SOFA2_outcomes_master.",
  sofa_source = sofa_path,
  outcomes_source = outcomes_path,
  id_columns = id_cols,
  merge_policy = list(
    identical_overlap_columns = "Dropped from outcomes before joining because they already exist identically in the SOFA table.",
    nonidentical_overlap_columns = "Renamed with suffix _outcome before joining."
  ),
  counts = list(
    rows = nrow(latest),
    columns = ncol(latest),
    identical_overlap_columns_dropped = length(drop_from_outcomes),
    nonidentical_overlap_columns_renamed = length(rename_from_outcomes)
  ),
  files = list(
    csv = list(path = out_csv, sha256 = digest::digest(file = out_csv, algo = "sha256")),
    rds = list(path = out_rds, sha256 = digest::digest(file = out_rds, algo = "sha256")),
    merge_report = list(path = merge_report_csv, sha256 = digest::digest(file = merge_report_csv, algo = "sha256"))
  )
)
yaml::write_yaml(manifest, file.path(processed_dir, "SOFA2_latest_sofa_with_outcomes_manifest.yml"))

message("Latest SOFA table with outcomes completed.")
message("Rows: ", nrow(latest), "; columns: ", ncol(latest))
message("Output: ", out_csv)


