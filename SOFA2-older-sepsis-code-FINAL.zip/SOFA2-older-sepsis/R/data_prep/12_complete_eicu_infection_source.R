project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "data_prep", "connect_eicu.R"))

required_packages <- c("DBI", "dplyr", "readr", "stringr", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

processed_dir <- file.path(project_root, "data", "processed")
table_dir <- file.path(project_root, "outputs", "tables")
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

enhanced <- readRDS(file.path(processed_dir, "eicu_external_validation_enhanced.rds"))
provided <- readr::read_csv(
  file.path(project_root, "data", "external", "eicu", "infection_site_inference.csv"),
  show_col_types = FALSE,
  locale = readr::locale(encoding = "UTF-8")
)

missing_ids <- setdiff(enhanced$patientunitstayid, provided$patientunitstayid)

con <- connect_eicu()
on.exit(DBI::dbDisconnect(con), add = TRUE)

DBI::dbWriteTable(
  con,
  "tmp_eicu_missing_infection_inference",
  data.frame(patientunitstayid = as.integer(missing_ids)),
  temporary = TRUE,
  overwrite = TRUE
)

diagnosis_all <- DBI::dbGetQuery(con, "
  select
    d.patientunitstayid,
    d.diagnosisoffset,
    d.diagnosisstring,
    d.icd9code,
    d.diagnosispriority
  from public.diagnosis d
  inner join tmp_eicu_missing_infection_inference c using (patientunitstayid)
  order by d.patientunitstayid, d.diagnosisoffset, d.diagnosisid
")

treatment_all <- DBI::dbGetQuery(con, "
  select
    t.patientunitstayid,
    t.treatmentoffset,
    t.treatmentstring
  from public.treatment t
  inner join tmp_eicu_missing_infection_inference c using (patientunitstayid)
  where lower(t.treatmentstring) ~ '(pneumonia|sepsis|septic|infection|infectious|urinary|uti|abdominal|biliary|wound|skin|catheter|meningitis|bacteremia|pulmonary|respiratory)'
  order by t.patientunitstayid, t.treatmentoffset, t.treatmentid
")

medication_all <- DBI::dbGetQuery(con, "
  select
    m.patientunitstayid,
    m.drugstartoffset,
    m.drugname,
    m.dosage,
    m.drughiclseqno
  from public.medication m
  inner join tmp_eicu_missing_infection_inference c using (patientunitstayid)
  where lower(m.drugname) ~ '(cef|cillin|penem|vanco|vancomycin|zosyn|piperacillin|tazobactam|meropenem|imipenem|cefepime|ceftriaxone|levofloxacin|ciprofloxacin|azithromycin|metronidazole|linezolid|daptomycin|gentamicin|tobramycin|amikacin|fluconazole|micafungin)'
  order by m.patientunitstayid, m.drugstartoffset, m.medicationid
")

microlab_all <- DBI::dbGetQuery(con, "
  select
    m.patientunitstayid,
    m.culturetakenoffset,
    m.culturesite,
    m.organism,
    m.antibiotic,
    m.sensitivitylevel
  from public.microlab m
  inner join tmp_eicu_missing_infection_inference c using (patientunitstayid)
  order by m.patientunitstayid, m.culturetakenoffset, m.microlabid
")

collapse_text <- function(x, max_items = 40) {
  x <- unique(x[!is.na(x) & trimws(x) != ""])
  if (length(x) == 0) return("")
  paste(utils::head(x, max_items), collapse = "\n")
}

pattern_score <- function(text, code = "") {
  z <- tolower(paste(text, code, collapse = " "))
  c(
    Pulmonary = sum(stringr::str_count(z, "pneumonia|pulmonary|respiratory|lung|aspiration|bronch|sputum|trache")),
    Urinary = sum(stringr::str_count(z, "urinary|\\buti\\b|urosepsis|pyelo|cystitis|urine")),
    Abdominal = sum(stringr::str_count(z, "abdominal|abdomen|biliary|cholang|cholecyst|periton|gastro|bowel|colitis|diverticul|appendic|pancreat|intra-abdominal"))
  )
}

score_one <- function(id) {
  dx <- diagnosis_all[diagnosis_all$patientunitstayid == id, , drop = FALSE]
  tx <- treatment_all[treatment_all$patientunitstayid == id, , drop = FALSE]
  med <- medication_all[medication_all$patientunitstayid == id, , drop = FALSE]
  micro <- microlab_all[microlab_all$patientunitstayid == id, , drop = FALSE]

  dx_score <- pattern_score(paste(dx$diagnosisstring, collapse = " "), paste(dx$icd9code, collapse = " ")) * 3
  tx_score <- pattern_score(paste(tx$treatmentstring, collapse = " ")) * 1.5
  micro_score <- pattern_score(paste(micro$culturesite, micro$organism, collapse = " ")) * 2
  total <- dx_score + tx_score + micro_score

  if (all(total == 0)) {
    primary <- "Other/undetermined"
    confidence <- "Low"
    basis <- "Undetermined"
    top <- ""
    manual <- 1L
    reason <- "No reliable site-specific evidence in supplemental extraction"
    evidence <- "No reliable site-specific diagnosis, microbiology, or treatment evidence"
    conflict <- 0L
  } else {
    ord <- sort(total, decreasing = TRUE)
    primary <- names(ord)[1]
    second <- if (length(ord) > 1) ord[2] else 0
    conflict <- as.integer(second > 0 & (ord[1] - second) < 2)
    confidence <- if (ord[1] >= 6 & conflict == 0) "High" else if (ord[1] >= 3) "Moderate" else "Low"
    basis <- paste(c(
      if (sum(dx_score) > 0) "Diagnosis/ICD" else character(0),
      if (sum(micro_score) > 0) "Microbiology" else character(0),
      if (sum(tx_score) > 0) "Treatment" else character(0)
    ), collapse = " + ")
    top <- paste(names(ord), as.numeric(ord), sep = "=", collapse = "; ")
    manual <- as.integer(conflict == 1 | confidence == "Low")
    reason <- if (conflict == 1) "Conflicting site signals; manual review suggested" else "Supplemental rule-based site inference"
    evidence <- paste(c(
      if (nrow(dx) > 0) paste0("Diagnosis: ", collapse_text(dx$diagnosisstring, 8)) else character(0),
      if (nrow(micro) > 0) paste0("Microbiology: ", collapse_text(paste(micro$culturesite, micro$organism, sep = " | "), 8)) else character(0),
      if (nrow(tx) > 0) paste0("Treatment: ", collapse_text(tx$treatmentstring, 8)) else character(0)
    ), collapse = " | ")
  }

  data.frame(
    patientunitstayid = id,
    infection_site_primary_updated = primary,
    infection_site_confidence_updated = confidence,
    infection_site_basis_updated = basis,
    infection_site_evidence_updated = evidence,
    supplemental_top_candidates = top,
    classification_changed = NA_integer_,
    supplemental_conflict_flag = conflict,
    manual_review_flag_updated = manual,
    manual_review_reason_updated = ifelse(manual == 1L, reason, ""),
    decision_reason = reason,
    supplemental_diagnosis_rows = nrow(dx),
    supplemental_treatment_rows = nrow(tx),
    supplemental_medication_rows = nrow(med),
    supplemental_microlab_rows = nrow(micro),
    supplemental_site_specific_diagnoses = collapse_text(dx$diagnosisstring, 20),
    supplemental_positive_microbiology = collapse_text(paste(micro$culturesite, micro$organism, sep = " | "), 20),
    supplemental_site_specific_treatments = collapse_text(tx$treatmentstring, 20),
    supplemental_antimicrobial_medications = collapse_text(
      paste0("[offset ", med$drugstartoffset, "] ", med$drugname, " ", med$dosage),
      20
    ),
    inference_source = "supplemented_by_codex_rule_for_missing_60",
    stringsAsFactors = FALSE
  )
}

supplement <- dplyr::bind_rows(lapply(missing_ids, score_one))

provided_core_names <- names(provided)
for (nm in setdiff(provided_core_names, names(supplement))) {
  supplement[[nm]] <- NA
}
supplement_aligned <- supplement[, provided_core_names, drop = FALSE]
supplement_aligned$inference_source <- "supplemented_by_codex_rule_for_missing_60"

provided$inference_source <- "provided_eicu_infection_inference_file"
completed <- dplyr::bind_rows(provided, supplement_aligned)

if (nrow(completed) != nrow(enhanced)) {
  stop("Completed infection inference table row count does not match enhanced cohort.")
}
if (anyDuplicated(completed$patientunitstayid) > 0) {
  stop("Completed infection inference table has duplicate patientunitstayid.")
}

out_csv <- file.path(processed_dir, "eicu_infection_inference_completed_final.csv")
out_rds <- file.path(processed_dir, "eicu_infection_inference_completed_final.rds")
readr::write_csv(completed, out_csv)
saveRDS(completed, out_rds)

summary <- data.frame(
  item = c(
    "enhanced_cohort_rows",
    "provided_infection_inference_rows",
    "missing_ids_supplemented",
    "completed_infection_inference_rows",
    "supplemented_pulmonary",
    "supplemented_urinary",
    "supplemented_abdominal",
    "supplemented_other_undetermined",
    "supplemented_manual_review_flag"
  ),
  value = c(
    nrow(enhanced),
    nrow(provided),
    length(missing_ids),
    nrow(completed),
    sum(supplement$infection_site_primary_updated == "Pulmonary"),
    sum(supplement$infection_site_primary_updated == "Urinary"),
    sum(supplement$infection_site_primary_updated == "Abdominal"),
    sum(supplement$infection_site_primary_updated == "Other/undetermined"),
    sum(supplement$manual_review_flag_updated == 1)
  )
)
readr::write_csv(summary, file.path(table_dir, "eicu_infection_inference_completed_final_summary.csv"))
readr::write_csv(supplement, file.path(table_dir, "eicu_infection_inference_supplemented_60_detail.csv"))

manifest <- list(
  project = "SOFA2 older sepsis",
  output_name = "eicu_infection_inference_completed_final",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  provided_source = file.path(project_root, "data", "external", "eicu", "infection_site_inference.csv"),
  enhanced_cohort_source = file.path(processed_dir, "eicu_external_validation_enhanced.rds"),
  missing_ids_supplemented = length(missing_ids),
  supplemental_rule = "For the 60 patientunitstayid values absent from the provided infection inference file, evidence was extracted from local eICU diagnosis, treatment, medication, and microlab tables. A conservative rule-based site score assigned Pulmonary, Urinary, Abdominal, or Other/undetermined; uncertain cases were flagged for manual review.",
  files = list(
    csv = list(path = out_csv, sha256 = digest::digest(file = out_csv, algo = "sha256")),
    rds = list(path = out_rds, sha256 = digest::digest(file = out_rds, algo = "sha256"))
  )
)
yaml::write_yaml(manifest, file.path(processed_dir, "eicu_infection_inference_completed_final_manifest.yml"))

message("Completed infection inference table created.")
message("Rows: ", nrow(completed))
message("Supplemented missing IDs: ", length(missing_ids))

