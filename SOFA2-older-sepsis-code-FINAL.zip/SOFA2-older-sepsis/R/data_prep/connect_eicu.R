required_packages <- c("DBI", "RPostgres")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

connect_eicu <- function() {
  password <- Sys.getenv("EICU_DB_PASSWORD", unset = Sys.getenv("MIMIC_READONLY_PASSWORD"))
  if (!nzchar(password)) {
    stop("Set EICU_DB_PASSWORD before connecting to the eICU database.")
  }

  DBI::dbConnect(
    RPostgres::Postgres(),
    host = Sys.getenv("EICU_DB_HOST", unset = "localhost"),
    port = as.integer(Sys.getenv("EICU_DB_PORT", unset = "5432")),
    dbname = Sys.getenv("EICU_DB_NAME", unset = "eicu"),
    user = Sys.getenv("EICU_DB_USER", unset = "mimic_readonly"),
    password = password
  )
}


