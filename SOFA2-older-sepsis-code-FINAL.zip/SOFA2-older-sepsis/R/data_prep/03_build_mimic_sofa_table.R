required_packages <- c("dplyr", "readr", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

subject_path <- "data/raw/SOFA2_subject.csv"
sofa_path <- "data/raw/other/sofa_merged.csv"
out_dir <- "data/processed"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

subject <- readr::read_csv(subject_path, show_col_types = FALSE)
sofa <- readr::read_csv(sofa_path, show_col_types = FALSE, locale = readr::locale(encoding = "UTF-8"))

join_keys <- c("subject_id", "hadm_id", "stay_id")

missing_subject_keys <- setdiff(join_keys, names(subject))
missing_sofa_keys <- setdiff(join_keys, names(sofa))
if (length(missing_subject_keys) > 0 || length(missing_sofa_keys) > 0) {
  stop(
    "Missing join keys. subject missing: ",
    paste(missing_subject_keys, collapse = ", "),
    "; sofa missing: ",
    paste(missing_sofa_keys, collapse = ", ")
  )
}

subject_key_dups <- subject |>
  dplyr::count(dplyr::across(dplyr::all_of(join_keys)), name = "n") |>
  dplyr::filter(.data$n > 1)

sofa_key_dups <- sofa |>
  dplyr::count(dplyr::across(dplyr::all_of(join_keys)), name = "n") |>
  dplyr::filter(.data$n > 1)

if (nrow(subject_key_dups) > 0) {
  stop("SOFA2_subject has duplicate subject_id + hadm_id + stay_id keys.")
}

if (nrow(sofa_key_dups) > 0) {
  readr::write_csv(sofa_key_dups, file.path(out_dir, "SOFA_source_duplicate_keys.csv"))
  stop("SOFA source has duplicate subject_id + hadm_id + stay_id keys. See data/processed/SOFA_source_duplicate_keys.csv")
}

sofa_cols <- setdiff(names(sofa), join_keys)

sofa_subject_total <- subject |>
  dplyr::left_join(sofa, by = join_keys) |>
  dplyr::mutate(has_sofa_source = dplyr::if_any(dplyr::all_of(sofa_cols), ~ !is.na(.x))) |>
  dplyr::relocate(
    dplyr::all_of(c(
      join_keys,
      "age",
      "icu_intime",
      "icu_outtime",
      "los_icu",
      "suspected_infection_time",
      "sofa_time",
      "sepsis_time",
      "has_sofa_source"
    ))
  )

sofa_subject_matched <- sofa_subject_total |>
  dplyr::filter(.data$has_sofa_source)

unmatched_subject <- sofa_subject_total |>
  dplyr::filter(!.data$has_sofa_source) |>
  dplyr::select(dplyr::all_of(c(join_keys, "age", "icu_intime", "icu_outtime", "los_icu")))

extra_sofa_not_in_subject <- sofa |>
  dplyr::anti_join(subject, by = join_keys)

total_csv <- file.path(out_dir, "SOFA2_subject_sofa_total.csv")
matched_csv <- file.path(out_dir, "SOFA2_subject_sofa_matched_only.csv")
unmatched_csv <- file.path(out_dir, "SOFA2_subject_without_sofa.csv")
extra_csv <- file.path(out_dir, "SOFA_source_not_in_SOFA2_subject.csv")
rds_path <- file.path(out_dir, "SOFA2_subject_sofa_total.rds")

readr::write_csv(sofa_subject_total, total_csv)
readr::write_csv(sofa_subject_matched, matched_csv)
readr::write_csv(unmatched_subject, unmatched_csv)
readr::write_csv(extra_sofa_not_in_subject, extra_csv)
saveRDS(sofa_subject_total, rds_path)

manifest <- list(
  project = "SOFA2老年脓毒症",
  output_name = "SOFA2_subject_sofa_total",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  join_keys = join_keys,
  source_files = list(
    subject = subject_path,
    sofa = sofa_path
  ),
  counts = list(
    subject_rows = nrow(subject),
    sofa_source_rows = nrow(sofa),
    total_output_rows = nrow(sofa_subject_total),
    matched_subject_rows = nrow(sofa_subject_matched),
    unmatched_subject_rows = nrow(unmatched_subject),
    extra_sofa_rows_not_in_subject = nrow(extra_sofa_not_in_subject),
    output_columns = ncol(sofa_subject_total)
  ),
  files = list(
    total_csv = list(path = total_csv, sha256 = digest::digest(file = total_csv, algo = "sha256")),
    matched_csv = list(path = matched_csv, sha256 = digest::digest(file = matched_csv, algo = "sha256")),
    unmatched_subject_csv = list(path = unmatched_csv, sha256 = digest::digest(file = unmatched_csv, algo = "sha256")),
    extra_sofa_csv = list(path = extra_csv, sha256 = digest::digest(file = extra_csv, algo = "sha256")),
    total_rds = list(path = rds_path, sha256 = digest::digest(file = rds_path, algo = "sha256"))
  )
)

yaml::write_yaml(manifest, file.path(out_dir, "SOFA2_subject_sofa_total_manifest.yml"))

message("SOFA subject table completed.")
message("Subject rows: ", nrow(subject))
message("SOFA source rows: ", nrow(sofa))
message("Matched subject rows: ", nrow(sofa_subject_matched))
message("Unmatched subject rows: ", nrow(unmatched_subject))
message("Total output rows: ", nrow(sofa_subject_total))
message("Total output columns: ", ncol(sofa_subject_total))

