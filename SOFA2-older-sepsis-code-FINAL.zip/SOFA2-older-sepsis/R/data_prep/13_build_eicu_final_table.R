project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)

required_packages <- c("dplyr", "readr", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

processed_dir <- file.path(project_root, "data", "processed")
table_dir <- file.path(project_root, "outputs", "tables")
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

enhanced_path <- file.path(processed_dir, "eicu_external_validation_enhanced.rds")
completed_infection_path <- file.path(processed_dir, "eicu_infection_inference_completed_final.csv")
infection_path <- if (file.exists(completed_infection_path)) {
  completed_infection_path
} else {
  file.path(project_root, "data", "external", "eicu", "infection_site_inference.csv")
}

enhanced <- readRDS(enhanced_path)
infection <- readr::read_csv(infection_path, show_col_types = FALSE, locale = readr::locale(encoding = "UTF-8"))

if (!"patientunitstayid" %in% names(enhanced) || !"patientunitstayid" %in% names(infection)) {
  stop("patientunitstayid is required in both tables.")
}

if (anyDuplicated(enhanced$patientunitstayid) > 0) {
  stop("Enhanced eICU validation table has duplicate patientunitstayid.")
}
if (anyDuplicated(infection$patientunitstayid) > 0) {
  stop("Infection inference table has duplicate patientunitstayid.")
}

collapse_infection_source <- function(x) {
  z <- tolower(trimws(as.character(x)))
  out <- rep("Other/undetermined", length(z))
  out[grepl("pulmonary|respiratory|pneumonia|lung", z)] <- "Pulmonary"
  out[grepl("urinary|uti|uro|kidney", z)] <- "Urinary"
  out[grepl("abdominal|abdomen|biliary|gastro|intestinal|periton", z)] <- "Abdominal"
  out[is.na(z) | z == "" | z %in% c("na", "unknown", "other/undetermined", "undetermined")] <- "Other/undetermined"
  factor(out, levels = c("Pulmonary", "Urinary", "Abdominal", "Other/undetermined"))
}

infection_keep <- infection |>
  dplyr::transmute(
    patientunitstayid = as.integer(.data$patientunitstayid),
    infection_site_primary_eicu = .data$infection_site_primary_updated,
    infection_site_collapsed_eicu = as.character(collapse_infection_source(.data$infection_site_primary_updated)),
    infection_site_confidence_eicu = .data$infection_site_confidence_updated,
    infection_site_basis_eicu = .data$infection_site_basis_updated,
    infection_site_evidence_eicu = .data$infection_site_evidence_updated,
    infection_site_top_candidates_eicu = .data$supplemental_top_candidates,
    infection_classification_changed_eicu = .data$classification_changed,
    infection_conflict_flag_eicu = .data$supplemental_conflict_flag,
    infection_manual_review_flag_eicu = .data$manual_review_flag_updated,
    infection_decision_reason_eicu = .data$decision_reason,
    infection_inference_source_eicu = if ("inference_source" %in% names(infection)) .data$inference_source else NA_character_,
    infection_supplemental_diagnosis_rows = .data$supplemental_diagnosis_rows,
    infection_supplemental_treatment_rows = .data$supplemental_treatment_rows,
    infection_supplemental_medication_rows = .data$supplemental_medication_rows,
    infection_supplemental_microlab_rows = .data$supplemental_microlab_rows
  )

final <- enhanced |>
  dplyr::left_join(infection_keep, by = "patientunitstayid") |>
  dplyr::mutate(
    infection_site_primary_eicu = dplyr::coalesce(.data$infection_site_primary_eicu, "Other/undetermined"),
    infection_site_collapsed_eicu = dplyr::coalesce(.data$infection_site_collapsed_eicu, "Other/undetermined"),
    infection_site_confidence_eicu = dplyr::coalesce(.data$infection_site_confidence_eicu, "Missing inference"),
    infection_site_basis_eicu = dplyr::coalesce(.data$infection_site_basis_eicu, "No inference record"),
    infection_site_evidence_eicu = dplyr::coalesce(.data$infection_site_evidence_eicu, "No infection inference record matched"),
    infection_classification_changed_eicu = dplyr::coalesce(.data$infection_classification_changed_eicu, 0),
    infection_conflict_flag_eicu = dplyr::coalesce(.data$infection_conflict_flag_eicu, 0),
    infection_manual_review_flag_eicu = dplyr::coalesce(.data$infection_manual_review_flag_eicu, 1),
    infection_inference_matched = as.integer(.data$patientunitstayid %in% infection_keep$patientunitstayid)
  )

if (nrow(final) != nrow(enhanced)) {
  stop("Final eICU validation table row count changed unexpectedly.")
}

priority_cols <- c(
  "patientunitstayid", "patienthealthsystemstayid", "uniquepid",
  "age", "gender", "unittype", "unitadmitsource", "hospitaladmitsource",
  "los_icu_days", "los_hospital_days",
  "mortality_28", "mortality_30", "mortality_90", "mortality_365",
  "icu_expire_flag", "hosp_mort",
  "sofa_dynamic_first", "sofa2_dynamic_first",
  "sofa_dynamic_resp_first", "sofa_dynamic_coag_first", "sofa_dynamic_liver_first",
  "sofa_dynamic_cardio_first", "sofa_dynamic_brain_first", "sofa_dynamic_renal_first",
  "sofa2_dynamic_brain_first", "sofa2_dynamic_resp_first", "sofa2_dynamic_cardio_first",
  "sofa2_dynamic_liver_first", "sofa2_dynamic_kidney_first", "sofa2_dynamic_hemo_first",
  "infection_site_primary_eicu", "infection_site_collapsed_eicu",
  "infection_site_confidence_eicu", "infection_site_basis_eicu",
  "infection_conflict_flag_eicu", "infection_manual_review_flag_eicu",
  "sepsis3_hr", "sepsis3_sofa2_hr", "septic_shock_minutes",
  "invasivevent_first_offset", "vasoactive_first_offset", "rrt_first_offset",
  "invasivevent_free_days_28_approx", "vasopressor_free_days_28_approx",
  "rrt_free_days_28_approx", "icu_free_days_28",
  "day3_new_invasivevent", "day3_new_septic_shock", "day3_new_aki", "day3_new_rrt"
)

final <- final |>
  dplyr::select(dplyr::any_of(priority_cols), dplyr::everything())

out_csv <- file.path(processed_dir, "eicu_external_validation_final_for_validation_plots.csv")
out_rds <- file.path(processed_dir, "eicu_external_validation_final_for_validation_plots.rds")

readr::write_csv(final, out_csv)
saveRDS(final, out_rds)

summary_table <- data.frame(
  item = c(
    "enhanced_rows",
    "infection_inference_rows",
    "final_rows",
    "infection_inference_matched_rows",
    "infection_inference_unmatched_rows",
    "pulmonary_collapsed",
    "urinary_collapsed",
    "abdominal_collapsed",
    "other_undetermined_collapsed",
    "icu_28d_mortality_events",
    "day3_new_invasivevent",
    "day3_new_septic_shock",
    "day3_new_aki",
    "day3_new_rrt"
  ),
  value = c(
    nrow(enhanced),
    nrow(infection),
    nrow(final),
    sum(final$infection_inference_matched == 1, na.rm = TRUE),
    sum(final$infection_inference_matched == 0, na.rm = TRUE),
    sum(final$infection_site_collapsed_eicu == "Pulmonary", na.rm = TRUE),
    sum(final$infection_site_collapsed_eicu == "Urinary", na.rm = TRUE),
    sum(final$infection_site_collapsed_eicu == "Abdominal", na.rm = TRUE),
    sum(final$infection_site_collapsed_eicu == "Other/undetermined", na.rm = TRUE),
    sum(final$mortality_28 == 1, na.rm = TRUE),
    sum(final$day3_new_invasivevent == 1, na.rm = TRUE),
    sum(final$day3_new_septic_shock == 1, na.rm = TRUE),
    sum(final$day3_new_aki == 1, na.rm = TRUE),
    sum(final$day3_new_rrt == 1, na.rm = TRUE)
  )
)
readr::write_csv(summary_table, file.path(table_dir, "eicu_external_validation_final_summary.csv"))

source_report <- data.frame(
  variable_group = c(
    "base cohort and baseline covariates",
    "organ-support timing and free-days",
    "infection source inference subset"
  ),
  source = c(
    "eicu_external_validation_enhanced.rds, derived from uploaded Excel plus local eICU database",
    "local eICU public.respiratorycare, infusiondrug, intakeoutput, treatment, apacheapsvar",
    "locally derived infection_site_inference.csv"
  ),
  note = c(
    "Already aligned to age >65, ICU LOS >=2 days, first ICU stay, sepsis adult table membership, and sepsis3_hr 0-48h.",
    "Free-days are approximate in eICU because raw records are not all complete MIMIC-style episodes.",
    "Only selected stable columns were merged; unmatched patients were retained and labeled Other/undetermined."
  )
)
readr::write_csv(source_report, file.path(table_dir, "eicu_external_validation_final_source_report.csv"))

manifest <- list(
  project = "SOFA2 older sepsis",
  output_name = "eicu_external_validation_final_for_validation_plots",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  purpose = "Analysis-ready eICU external validation table for validation plots and external validation models.",
  enhanced_source = enhanced_path,
  infection_inference_source = infection_path,
  merge_key = "patientunitstayid",
  infection_source_policy = "Merge selected updated infection-source inference fields. Retain all enhanced cohort patients; unmatched infection records are labeled Other/undetermined.",
  counts = as.list(stats::setNames(summary_table$value, summary_table$item)),
  files = list(
    csv = list(path = out_csv, sha256 = digest::digest(file = out_csv, algo = "sha256")),
    rds = list(path = out_rds, sha256 = digest::digest(file = out_rds, algo = "sha256"))
  )
)
yaml::write_yaml(manifest, file.path(processed_dir, "eicu_external_validation_final_for_validation_plots_manifest.yml"))

message("Final eICU external validation table completed.")
message("Rows: ", nrow(final), "; columns: ", ncol(final))
message("Output: ", out_csv)

