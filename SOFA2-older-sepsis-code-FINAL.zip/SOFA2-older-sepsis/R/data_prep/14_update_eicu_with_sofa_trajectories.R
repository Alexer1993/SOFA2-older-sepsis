project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)

required_packages <- c("dplyr", "readr", "readxl", "openxlsx", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

processed_dir <- file.path(project_root, "data", "processed")
table_dir <- file.path(project_root, "outputs", "tables")
external_dir <- file.path(project_root, "data", "external", "eicu")
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

enhanced <- readRDS(file.path(processed_dir, "eicu_external_validation_enhanced.rds"))

read_sofa_window <- function(path, suffix) {
  d <- readxl::read_excel(path, sheet = 1) |>
    as.data.frame()
  if (anyDuplicated(d$patientunitstayid) > 0) {
    stop("Duplicate patientunitstayid in ", basename(path))
  }

  score_cols <- c(
    "sofa_dynamic_max",
    "sofa_dynamic_resp_max",
    "sofa_dynamic_coag_max",
    "sofa_dynamic_liver_max",
    "sofa_dynamic_cardio_max",
    "sofa_dynamic_brain_max",
    "sofa_dynamic_renal_max",
    "sofa2_dynamic_max",
    "sofa2_dynamic_brain_max",
    "sofa2_dynamic_resp_max",
    "sofa2_dynamic_cardio_max",
    "sofa2_dynamic_liver_max",
    "sofa2_dynamic_kidney_max",
    "sofa2_dynamic_hemo_max"
  )

  out <- d |>
    dplyr::select(patientunitstayid, dplyr::all_of(score_cols))
  names(out)[names(out) != "patientunitstayid"] <- paste0(
    sub("_max$", "", names(out)[names(out) != "patientunitstayid"]),
    "_",
    suffix,
    "_max"
  )
  out
}

sofa24 <- read_sofa_window(file.path(external_dir, "sofa_24h.xlsx"), "24h")
sofa48 <- read_sofa_window(file.path(external_dir, "sofa_48h.xlsx"), "48h")
sofa72 <- read_sofa_window(file.path(external_dir, "sofa_72h.xlsx"), "72h")

infection <- readr::read_csv(
  file.path(external_dir, "infection_site_reinference.csv"),
  show_col_types = FALSE,
  locale = readr::locale(encoding = "UTF-8")
)
if (anyDuplicated(infection$patientunitstayid) > 0) {
  stop("Duplicate patientunitstayid in infection_site_reinference.csv")
}

cohort_flag_col <- grep("^cohort_main_", names(infection), value = TRUE)
if (length(cohort_flag_col) > 0) {
  infection$infection_cohort_main_final <- infection[[cohort_flag_col[1]]]
}

collapse_infection_source <- function(x) {
  z <- tolower(trimws(as.character(x)))
  out <- rep("Other/undetermined", length(z))
  out[grepl("pulmonary|respiratory|pneumonia|lung", z)] <- "Pulmonary"
  out[grepl("urinary|uti|uro|kidney", z)] <- "Urinary"
  out[grepl("abdominal|abdomen|biliary|gastro|intestinal|periton", z)] <- "Abdominal"
  out[is.na(z) | z == "" | z %in% c("na", "unknown", "other/undetermined", "undetermined")] <- "Other/undetermined"
  out
}

infection_keep <- infection |>
  dplyr::transmute(
    patientunitstayid = as.integer(.data$patientunitstayid),
    infection_site_main_final_eicu = .data$infection_site_main_final,
    infection_site_collapsed_final_eicu = collapse_infection_source(.data$infection_site_main_final),
    infection_site_flags_final_eicu = .data$infection_site_flags_final,
    infection_site_confidence_final_eicu = .data$infection_site_confidence_final,
    infection_site_evidence_final_eicu = .data$infection_site_evidence_final,
    infection_site_score_summary_eicu = .data$infection_site_score_summary,
    infection_clinical_baseline_support_eicu = .data$clinical_baseline_support,
    infection_manual_review_flag_final_eicu = .data$manual_review_flag_final,
    infection_decision_reason_final_eicu = .data$decision_reason_final,
    infection_classification_changed_final_eicu = .data$classification_changed_final,
    infection_reinference_source_eicu = .data$inference_source,
    infection_site_primary_updated_eicu = .data$infection_site_primary_updated,
    infection_site_confidence_updated_eicu = .data$infection_site_confidence_updated,
    infection_site_basis_updated_eicu = .data$infection_site_basis_updated,
    infection_site_evidence_updated_eicu = .data$infection_site_evidence_updated
  )

final <- enhanced |>
  dplyr::left_join(sofa24, by = "patientunitstayid") |>
  dplyr::left_join(sofa48, by = "patientunitstayid") |>
  dplyr::left_join(sofa72, by = "patientunitstayid") |>
  dplyr::left_join(infection_keep, by = "patientunitstayid") |>
  dplyr::mutate(
    infection_site_main_final_eicu = dplyr::coalesce(.data$infection_site_main_final_eicu, "Other/undetermined"),
    infection_site_collapsed_final_eicu = dplyr::coalesce(.data$infection_site_collapsed_final_eicu, "Other/undetermined"),
    infection_site_confidence_final_eicu = dplyr::coalesce(.data$infection_site_confidence_final_eicu, "Missing inference"),
    infection_reinference_matched = as.integer(.data$patientunitstayid %in% infection_keep$patientunitstayid)
  )

if (nrow(final) != nrow(enhanced)) {
  stop("Updated final table row count changed unexpectedly.")
}
if (anyDuplicated(final$patientunitstayid) > 0) {
  stop("Updated final table has duplicate patientunitstayid.")
}

priority_cols <- c(
  "patientunitstayid", "patienthealthsystemstayid", "uniquepid",
  "age", "gender", "unittype", "unitadmitsource", "hospitaladmitsource",
  "los_icu_days", "los_hospital_days",
  "mortality_28", "mortality_30", "mortality_90", "mortality_365",
  "icu_expire_flag", "hosp_mort",
  "sofa_dynamic_24h_max", "sofa_dynamic_48h_max", "sofa_dynamic_72h_max",
  "sofa2_dynamic_24h_max", "sofa2_dynamic_48h_max", "sofa2_dynamic_72h_max",
  "sofa_dynamic_resp_24h_max", "sofa_dynamic_resp_48h_max", "sofa_dynamic_resp_72h_max",
  "sofa_dynamic_coag_24h_max", "sofa_dynamic_coag_48h_max", "sofa_dynamic_coag_72h_max",
  "sofa_dynamic_liver_24h_max", "sofa_dynamic_liver_48h_max", "sofa_dynamic_liver_72h_max",
  "sofa_dynamic_cardio_24h_max", "sofa_dynamic_cardio_48h_max", "sofa_dynamic_cardio_72h_max",
  "sofa_dynamic_brain_24h_max", "sofa_dynamic_brain_48h_max", "sofa_dynamic_brain_72h_max",
  "sofa_dynamic_renal_24h_max", "sofa_dynamic_renal_48h_max", "sofa_dynamic_renal_72h_max",
  "sofa2_dynamic_brain_24h_max", "sofa2_dynamic_brain_48h_max", "sofa2_dynamic_brain_72h_max",
  "sofa2_dynamic_resp_24h_max", "sofa2_dynamic_resp_48h_max", "sofa2_dynamic_resp_72h_max",
  "sofa2_dynamic_cardio_24h_max", "sofa2_dynamic_cardio_48h_max", "sofa2_dynamic_cardio_72h_max",
  "sofa2_dynamic_liver_24h_max", "sofa2_dynamic_liver_48h_max", "sofa2_dynamic_liver_72h_max",
  "sofa2_dynamic_kidney_24h_max", "sofa2_dynamic_kidney_48h_max", "sofa2_dynamic_kidney_72h_max",
  "sofa2_dynamic_hemo_24h_max", "sofa2_dynamic_hemo_48h_max", "sofa2_dynamic_hemo_72h_max",
  "infection_site_main_final_eicu", "infection_site_collapsed_final_eicu",
  "infection_site_confidence_final_eicu", "infection_site_flags_final_eicu",
  "infection_manual_review_flag_final_eicu", "infection_decision_reason_final_eicu",
  "sepsis3_hr", "sepsis3_sofa2_hr", "septic_shock_minutes",
  "invasivevent_first_offset", "vasoactive_first_offset", "rrt_first_offset",
  "invasivevent_free_days_28_approx", "vasopressor_free_days_28_approx",
  "rrt_free_days_28_approx", "icu_free_days_28",
  "day3_new_invasivevent", "day3_new_septic_shock", "day3_new_aki", "day3_new_rrt"
)
final <- final |>
  dplyr::select(dplyr::any_of(priority_cols), dplyr::everything())

out_csv <- file.path(processed_dir, "eicu_external_validation_final_updated.csv")
out_rds <- file.path(processed_dir, "eicu_external_validation_final_updated.rds")
out_xlsx <- file.path(processed_dir, "eicu_external_validation_final_updated.xlsx")

readr::write_csv(final, out_csv)
saveRDS(final, out_rds)
openxlsx::write.xlsx(final, out_xlsx, overwrite = TRUE)

summary <- data.frame(
  item = c(
    "final_rows",
    "final_columns",
    "duplicate_patientunitstayid",
    "sofa24_matched_rows",
    "sofa48_matched_rows",
    "sofa72_matched_rows",
    "infection_reinference_matched_rows",
    "infection_reinference_unmatched_rows",
    "pulmonary_collapsed_final",
    "urinary_collapsed_final",
    "abdominal_collapsed_final",
    "other_undetermined_collapsed_final",
    "icu_28d_mortality_events",
    "day3_new_invasivevent",
    "day3_new_septic_shock",
    "day3_new_aki",
    "day3_new_rrt"
  ),
  value = c(
    nrow(final),
    ncol(final),
    anyDuplicated(final$patientunitstayid),
    sum(!is.na(final$sofa2_dynamic_24h_max)),
    sum(!is.na(final$sofa2_dynamic_48h_max)),
    sum(!is.na(final$sofa2_dynamic_72h_max)),
    sum(final$infection_reinference_matched == 1, na.rm = TRUE),
    sum(final$infection_reinference_matched == 0, na.rm = TRUE),
    sum(final$infection_site_collapsed_final_eicu == "Pulmonary", na.rm = TRUE),
    sum(final$infection_site_collapsed_final_eicu == "Urinary", na.rm = TRUE),
    sum(final$infection_site_collapsed_final_eicu == "Abdominal", na.rm = TRUE),
    sum(final$infection_site_collapsed_final_eicu == "Other/undetermined", na.rm = TRUE),
    sum(final$mortality_28 == 1, na.rm = TRUE),
    sum(final$day3_new_invasivevent == 1, na.rm = TRUE),
    sum(final$day3_new_septic_shock == 1, na.rm = TRUE),
    sum(final$day3_new_aki == 1, na.rm = TRUE),
    sum(final$day3_new_rrt == 1, na.rm = TRUE)
  )
)
readr::write_csv(summary, file.path(table_dir, "eicu_external_validation_final_updated_summary.csv"))

source_report <- data.frame(
  source_file = c(
    "eicu_external_validation_enhanced.rds",
    "sofa_24h.xlsx",
    "sofa_48h.xlsx",
    "sofa_72h.xlsx",
    "infection_site_reinference.csv"
  ),
  use = c(
    "Base aligned cohort, outcomes, database-derived organ support timing and free-days",
    "24-hour SOFA/SOFA2 maximum scores and organ subscores",
    "48-hour SOFA/SOFA2 maximum scores and organ subscores",
    "72-hour SOFA/SOFA2 maximum scores and organ subscores",
    "Final infection source inference fields"
  )
)
readr::write_csv(source_report, file.path(table_dir, "eicu_external_validation_final_updated_source_report.csv"))

manifest <- list(
  project = "SOFA2 older sepsis",
  output_name = "eicu_external_validation_final_updated",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  purpose = "Updated eICU external validation analysis table after merging the newly added SOFA 24/48/72h files and the final infection reinference file.",
  cohort = "Aligned to age >65, ICU LOS >=2 days, first ICU stay, adult sepsis table membership, and sepsis3_hr 0-48h.",
  merge_key = "patientunitstayid",
  counts = as.list(stats::setNames(summary$value, summary$item)),
  files = list(
    csv = list(path = out_csv, sha256 = digest::digest(file = out_csv, algo = "sha256")),
    rds = list(path = out_rds, sha256 = digest::digest(file = out_rds, algo = "sha256")),
    xlsx = list(path = out_xlsx, sha256 = digest::digest(file = out_xlsx, algo = "sha256"))
  )
)
yaml::write_yaml(manifest, file.path(processed_dir, "eicu_external_validation_final_updated_manifest.yml"))

message("Updated eICU external validation table completed.")
message("Rows: ", nrow(final), "; columns: ", ncol(final))
message("Output: ", out_csv)


