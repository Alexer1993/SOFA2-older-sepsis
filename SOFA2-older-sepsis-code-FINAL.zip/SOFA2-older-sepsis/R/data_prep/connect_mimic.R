required_packages <- c("DBI", "RPostgres")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

connect_mimic <- function() {
  password <- Sys.getenv("MIMIC_DB_PASSWORD", unset = Sys.getenv("MIMIC_READONLY_PASSWORD"))
  if (!nzchar(password)) {
    stop("Set MIMIC_DB_PASSWORD before connecting to the database.")
  }

  DBI::dbConnect(
    RPostgres::Postgres(),
    host = Sys.getenv("MIMIC_DB_HOST", unset = "localhost"),
    port = as.integer(Sys.getenv("MIMIC_DB_PORT", unset = "5432")),
    dbname = Sys.getenv("MIMIC_DB_NAME", unset = "mimiciv"),
    user = Sys.getenv("MIMIC_DB_USER", unset = "mimic_readonly"),
    password = password
  )
}

