required_packages <- c("DBI", "RPostgres", "readr", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

source(file.path(normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE), "R", "data_prep", "connect_mimic.R"))

project_root <- normalizePath(getwd(), mustWork = TRUE)
raw_dir <- file.path(project_root, "data", "raw")
dir.create(raw_dir, recursive = TRUE, showWarnings = FALSE)

sql <- "
WITH icu_base AS (
    SELECT
        icu.subject_id,
        icu.stay_id,
        icu.hadm_id,
        age.age,
        icu.icu_intime,
        icu.icu_outtime,
        icu.los_icu
    FROM mimiciv_derived.icustay_detail AS icu
    LEFT JOIN mimiciv_derived.age AS age
        ON age.hadm_id = icu.hadm_id
),
after_age AS (
    SELECT *
    FROM icu_base
    WHERE age > 65
),
ranked_after_age AS (
    SELECT
        *,
        ROW_NUMBER() OVER (
            PARTITION BY hadm_id
            ORDER BY icu_intime ASC, stay_id ASC
        ) AS rn
    FROM after_age
),
after_first_icu AS (
    SELECT *
    FROM ranked_after_age
    WHERE rn = 1
),
after_los AS (
    SELECT *
    FROM after_first_icu
    WHERE los_icu >= 2.0
),
sepsis_time_calc AS (
    SELECT
        stay_id,
        suspected_infection_time,
        sofa_time,
        GREATEST(suspected_infection_time, sofa_time) AS sepsis_time
    FROM mimiciv_derived.sepsis3
)
SELECT
    icu.subject_id,
    icu.stay_id,
    icu.hadm_id,
    icu.age,
    icu.icu_intime,
    icu.icu_outtime,
    icu.los_icu,
    sep.suspected_infection_time,
    sep.sofa_time,
    sep.sepsis_time
FROM after_los AS icu
INNER JOIN sepsis_time_calc AS sep
    ON sep.stay_id = icu.stay_id
WHERE sep.sepsis_time IS NOT NULL
  AND sep.sepsis_time >= icu.icu_intime
  AND sep.sepsis_time <= icu.icu_intime + INTERVAL '48 hour'
ORDER BY icu.subject_id, icu.hadm_id, icu.stay_id
"

con <- connect_mimic()
on.exit(DBI::dbDisconnect(con), add = TRUE)

sofa2_subject <- DBI::dbGetQuery(con, sql)

csv_path <- file.path(raw_dir, "SOFA2_subject.csv")
rds_path <- file.path(raw_dir, "SOFA2_subject.rds")

readr::write_csv(sofa2_subject, csv_path)
saveRDS(sofa2_subject, rds_path)

csv_sha256 <- digest::digest(file = csv_path, algo = "sha256")
rds_sha256 <- digest::digest(file = rds_path, algo = "sha256")

summary_info <- list(
  project = "SOFA2老年脓毒症",
  extract_name = "SOFA2_subject",
  extracted_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  database = "mimiciv",
  source_type = "read_only_select",
  n_rows = nrow(sofa2_subject),
  n_cols = ncol(sofa2_subject),
  columns = names(sofa2_subject),
  files = list(
    csv = list(path = "data/raw/SOFA2_subject.csv", sha256 = csv_sha256),
    rds = list(path = "data/raw/SOFA2_subject.rds", sha256 = rds_sha256)
  ),
  sql = sql
)

yaml::write_yaml(summary_info, file.path(raw_dir, "SOFA2_subject_manifest.yml"))

message("Extract completed.")
message("Rows: ", nrow(sofa2_subject))
message("Columns: ", ncol(sofa2_subject))
message("CSV: ", csv_path)
message("CSV SHA256: ", csv_sha256)

