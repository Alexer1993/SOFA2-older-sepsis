set.seed(2026)

project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "data_prep", "connect_mimic.R"))

required_packages <- c("DBI", "dplyr", "readr", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

out_dir <- file.path(project_root, "data", "processed")
table_dir <- file.path(project_root, "outputs", "tables")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

master_path <- file.path(out_dir, "SOFA2_analysis_master.rds")
master <- readRDS(master_path)

parse_time <- function(x) {
  if (inherits(x, "POSIXct")) return(x)
  x <- as.character(x)
  x[trimws(x) %in% c("", "NA", "NaN", "NULL", "NaT")] <- NA_character_
  as.POSIXct(x, tz = "UTC", tryFormats = c(
    "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M",
    "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M",
    "%Y-%m-%d", "%Y/%m/%d"
  ))
}

to_binary <- function(x) {
  if (is.numeric(x) || is.integer(x)) return(as.integer(x > 0))
  z <- tolower(trimws(as.character(x)))
  as.integer(z %in% c("1", "yes", "y", "true", "t"))
}

cohort <- master |>
  dplyr::transmute(
    subject_id = as.integer(.data$subject_id),
    hadm_id = as.integer(.data$hadm_id),
    stay_id = as.integer(.data$stay_id),
    icu_intime = parse_time(.data$icu_intime),
    icu_outtime = parse_time(.data$icu_outtime),
    admittime = parse_time(.data$admittime),
    dischtime = parse_time(.data$dischtime),
    dod = parse_time(.data$dod),
    los_icu = as.numeric(.data$los_icu),
    los_hospital = as.numeric(.data$los_hospital),
    icu_expire_flag = to_binary(.data$icu_expire_flag),
    hospital_expire_flag = to_binary(.data$hospital_expire_flag),
    mortality_28 = to_binary(.data$mortality_28),
    mortality_90 = to_binary(.data$mortality_90),
    mortality_365 = to_binary(.data$mortality_365),
    invasivevent_time_first_current = parse_time(.data$invasivevent_time_first),
    septic_shock_time_current = parse_time(.data$septic_shock_time),
    aki_time_current = parse_time(.data$aki_time),
    rrt_time_first_current = parse_time(.data$rrt_time_first),
    crrt_time_first_current = parse_time(.data$crrt_time_first),
    vasoactive_first_time_current = parse_time(.data$vasoactive_first_time)
  ) |>
  dplyr::mutate(
    horizon28_start = .data$icu_intime,
    horizon28_end = pmin(.data$icu_intime + 28 * 24 * 3600, .data$icu_outtime, na.rm = TRUE),
    day3_cutoff = .data$icu_intime + 72 * 3600,
    death_days_from_icu = as.numeric(difftime(.data$dod, .data$icu_intime, units = "days")),
    icu_28d_death = as.integer(!is.na(.data$death_days_from_icu) &
                                 .data$death_days_from_icu >= 0 &
                                 .data$death_days_from_icu <= 28),
    icu_los_days_28 = pmax(0, as.numeric(difftime(.data$horizon28_end, .data$icu_intime, units = "days"))),
    icu_free_days_28 = dplyr::if_else(
      .data$icu_28d_death == 1L,
      0,
      pmax(0, 28 - pmin(.data$los_icu, 28))
    )
  )

if (anyDuplicated(cohort$stay_id) > 0) {
  stop("stay_id is not unique in the final cohort.")
}

con <- connect_mimic()
on.exit(DBI::dbDisconnect(con), add = TRUE)

DBI::dbWriteTable(
  con,
  name = "tmp_sofa2_outcome_cohort",
  value = cohort |> dplyr::select(stay_id),
  temporary = TRUE,
  overwrite = TRUE
)

ventilation_sql <- "
select v.stay_id, v.starttime, v.endtime, v.ventilation_status
from mimiciv_derived.ventilation v
inner join tmp_sofa2_outcome_cohort c on c.stay_id = v.stay_id
where v.starttime is not null
  and v.endtime is not null
  and v.ventilation_status in ('InvasiveVent', 'Tracheostomy')
"

vasoactive_sql <- "
select v.stay_id, v.starttime, v.endtime
from mimiciv_derived.vasoactive_agent v
inner join tmp_sofa2_outcome_cohort c on c.stay_id = v.stay_id
where v.starttime is not null
  and v.endtime is not null
  and (
    v.dopamine is not null
    or v.epinephrine is not null
    or v.norepinephrine is not null
    or v.phenylephrine is not null
    or v.vasopressin is not null
    or v.dobutamine is not null
  )
"

rrt_sql <- "
select r.stay_id, r.charttime, r.dialysis_present, r.dialysis_active, r.dialysis_type
from mimiciv_derived.rrt r
inner join tmp_sofa2_outcome_cohort c on c.stay_id = r.stay_id
where r.charttime is not null
  and r.dialysis_present = 1
"

crrt_sql <- "
select r.stay_id, r.charttime, r.system_active
from mimiciv_derived.crrt r
inner join tmp_sofa2_outcome_cohort c on c.stay_id = r.stay_id
where r.charttime is not null
"

ventilation <- DBI::dbGetQuery(con, ventilation_sql)
vasoactive <- DBI::dbGetQuery(con, vasoactive_sql)
rrt <- DBI::dbGetQuery(con, rrt_sql)
crrt <- DBI::dbGetQuery(con, crrt_sql)

as_utc <- function(x) as.POSIXct(x, tz = "UTC")

interval_summary <- function(events, prefix) {
  if (nrow(events) == 0) {
    return(cohort |> dplyr::transmute(
      stay_id,
      "{prefix}_first_time_db" := as.POSIXct(NA, tz = "UTC"),
      "{prefix}_last_time_db" := as.POSIXct(NA, tz = "UTC"),
      "{prefix}_hours_28" := 0,
      "{prefix}_days_28" := 0
    ))
  }

  clipped <- events |>
    dplyr::mutate(
      starttime = as_utc(.data$starttime),
      endtime = as_utc(.data$endtime)
    ) |>
    dplyr::inner_join(
      cohort |> dplyr::select(stay_id, horizon28_start, horizon28_end),
      by = "stay_id"
    ) |>
    dplyr::mutate(
      clipped_start = pmax(.data$starttime, .data$horizon28_start, na.rm = TRUE),
      clipped_end = pmin(.data$endtime, .data$horizon28_end, na.rm = TRUE),
      overlap_hours = pmax(0, as.numeric(difftime(.data$clipped_end, .data$clipped_start, units = "hours")))
    ) |>
    dplyr::filter(.data$overlap_hours > 0)

  merge_one_stay <- function(df) {
    df <- df[order(df$clipped_start, df$clipped_end), , drop = FALSE]
    merged_start <- df$clipped_start[1]
    merged_end <- df$clipped_end[1]
    total_hours <- 0

    if (nrow(df) > 1) {
      for (i in 2:nrow(df)) {
        if (df$clipped_start[i] <= merged_end) {
          merged_end <- max(merged_end, df$clipped_end[i], na.rm = TRUE)
        } else {
          total_hours <- total_hours + as.numeric(difftime(merged_end, merged_start, units = "hours"))
          merged_start <- df$clipped_start[i]
          merged_end <- df$clipped_end[i]
        }
      }
    }
    total_hours <- total_hours + as.numeric(difftime(merged_end, merged_start, units = "hours"))

    data.frame(
      first_time = min(df$starttime, na.rm = TRUE),
      last_time = max(df$endtime, na.rm = TRUE),
      hours_28 = total_hours
    )
  }

  clipped |>
    dplyr::group_by(.data$stay_id) |>
    dplyr::group_modify(~ merge_one_stay(.x)) |>
    dplyr::ungroup() |>
    dplyr::rename(
      "{prefix}_first_time_db" := "first_time",
      "{prefix}_last_time_db" := "last_time",
      "{prefix}_hours_28" := "hours_28"
    ) |>
    dplyr::mutate("{prefix}_days_28" := .data[[paste0(prefix, "_hours_28")]] / 24) |>
    dplyr::right_join(cohort |> dplyr::select(stay_id), by = "stay_id") |>
    dplyr::mutate(
      "{prefix}_hours_28" := dplyr::coalesce(.data[[paste0(prefix, "_hours_28")]], 0),
      "{prefix}_days_28" := dplyr::coalesce(.data[[paste0(prefix, "_days_28")]], 0)
    )
}

rrt_day_summary <- function(rrt_data, crrt_data) {
  rrt_days <- rrt_data |>
    dplyr::mutate(
      charttime = as_utc(.data$charttime),
      dialysis_active = to_binary(.data$dialysis_active),
      dialysis_present = to_binary(.data$dialysis_present)
    ) |>
    dplyr::inner_join(
      cohort |> dplyr::select(stay_id, horizon28_start, horizon28_end),
      by = "stay_id"
    ) |>
    dplyr::filter(.data$charttime >= .data$horizon28_start, .data$charttime <= .data$horizon28_end) |>
    dplyr::mutate(
      day_index = pmax(1L, pmin(28L, floor(as.numeric(difftime(.data$charttime, .data$horizon28_start, units = "days"))) + 1L))
    ) |>
    dplyr::group_by(.data$stay_id) |>
    dplyr::summarise(
      rrt_first_time_db = min(.data$charttime, na.rm = TRUE),
      rrt_days_present_28 = dplyr::n_distinct(.data$day_index[.data$dialysis_present == 1L]),
      rrt_days_active_28 = dplyr::n_distinct(.data$day_index[.data$dialysis_active == 1L]),
      .groups = "drop"
    )

  crrt_days <- crrt_data |>
    dplyr::mutate(
      charttime = as_utc(.data$charttime),
      system_active = to_binary(.data$system_active)
    ) |>
    dplyr::inner_join(
      cohort |> dplyr::select(stay_id, horizon28_start, horizon28_end),
      by = "stay_id"
    ) |>
    dplyr::filter(.data$charttime >= .data$horizon28_start, .data$charttime <= .data$horizon28_end) |>
    dplyr::mutate(
      day_index = pmax(1L, pmin(28L, floor(as.numeric(difftime(.data$charttime, .data$horizon28_start, units = "days"))) + 1L))
    ) |>
    dplyr::group_by(.data$stay_id) |>
    dplyr::summarise(
      crrt_first_time_db = if (any(.data$system_active == 1L, na.rm = TRUE)) {
        min(.data$charttime[.data$system_active == 1L], na.rm = TRUE)
      } else {
        as.POSIXct(NA, tz = "UTC")
      },
      crrt_days_active_28 = dplyr::n_distinct(.data$day_index[.data$system_active == 1L]),
      .groups = "drop"
    )

  cohort |> dplyr::select(stay_id) |>
    dplyr::left_join(rrt_days, by = "stay_id") |>
    dplyr::left_join(crrt_days, by = "stay_id") |>
    dplyr::mutate(
      rrt_days_present_28 = dplyr::coalesce(.data$rrt_days_present_28, 0L),
      rrt_days_active_28 = pmax(dplyr::coalesce(.data$rrt_days_active_28, 0L), dplyr::coalesce(.data$crrt_days_active_28, 0L)),
      crrt_days_active_28 = dplyr::coalesce(.data$crrt_days_active_28, 0L),
      rrt_first_time_db = pmin(.data$rrt_first_time_db, .data$crrt_first_time_db, na.rm = TRUE),
      rrt_first_time_db = dplyr::if_else(is.infinite(.data$rrt_first_time_db), as.POSIXct(NA, tz = "UTC"), .data$rrt_first_time_db)
    )
}

vent_summary <- interval_summary(ventilation, "invasive_vent")
vaso_summary <- interval_summary(vasoactive, "vasoactive")
rrt_summary <- rrt_day_summary(rrt, crrt)

outcomes <- cohort |>
  dplyr::left_join(vent_summary, by = "stay_id") |>
  dplyr::left_join(vaso_summary, by = "stay_id", suffix = c("", "_db_episode")) |>
  dplyr::left_join(rrt_summary, by = "stay_id") |>
  dplyr::mutate(
    invasive_vent_free_days_28 = dplyr::if_else(
      .data$icu_28d_death == 1L,
      0,
      pmax(0, 28 - .data$invasive_vent_days_28)
    ),
    vasopressor_free_days_28 = dplyr::if_else(
      .data$icu_28d_death == 1L,
      0,
      pmax(0, 28 - .data$vasoactive_days_28)
    ),
    rrt_free_days_28 = dplyr::if_else(
      .data$icu_28d_death == 1L,
      0,
      pmax(0, 28 - .data$rrt_days_active_28)
    ),
    day3_new_invasive_vent = as.integer(!is.na(.data$invasivevent_time_first_current) &
                                          .data$invasivevent_time_first_current > .data$day3_cutoff),
    day3_preexisting_invasive_vent = as.integer(!is.na(.data$invasivevent_time_first_current) &
                                                  .data$invasivevent_time_first_current <= .data$day3_cutoff),
    day3_new_septic_shock = as.integer(!is.na(.data$septic_shock_time_current) &
                                         .data$septic_shock_time_current > .data$day3_cutoff),
    day3_preexisting_septic_shock = as.integer(!is.na(.data$septic_shock_time_current) &
                                                 .data$septic_shock_time_current <= .data$day3_cutoff),
    day3_new_aki = as.integer(!is.na(.data$aki_time_current) &
                                .data$aki_time_current > .data$day3_cutoff),
    day3_preexisting_aki = as.integer(!is.na(.data$aki_time_current) &
                                        .data$aki_time_current <= .data$day3_cutoff),
    day3_new_rrt = as.integer(!is.na(.data$rrt_first_time_db) &
                                .data$rrt_first_time_db > .data$day3_cutoff),
    day3_preexisting_rrt = as.integer(!is.na(.data$rrt_first_time_db) &
                                        .data$rrt_first_time_db <= .data$day3_cutoff)
  ) |>
  dplyr::select(
    subject_id, hadm_id, stay_id,
    icu_intime, icu_outtime, admittime, dischtime, dod,
    icu_expire_flag, hospital_expire_flag, mortality_28, mortality_90, mortality_365,
    los_icu, los_hospital, death_days_from_icu, icu_28d_death,
    invasive_vent_first_time_db, invasive_vent_last_time_db,
    invasive_vent_hours_28, invasive_vent_days_28, invasive_vent_free_days_28,
    vasoactive_first_time_db, vasoactive_last_time_db,
    vasoactive_hours_28, vasoactive_days_28, vasopressor_free_days_28,
    rrt_first_time_db, rrt_days_present_28, rrt_days_active_28, crrt_first_time_db,
    crrt_days_active_28, rrt_free_days_28, icu_free_days_28,
    day3_cutoff,
    day3_preexisting_invasive_vent, day3_new_invasive_vent,
    day3_preexisting_septic_shock, day3_new_septic_shock,
    day3_preexisting_aki, day3_new_aki,
    day3_preexisting_rrt, day3_new_rrt,
    invasivevent_time_first_current, septic_shock_time_current, aki_time_current,
    rrt_time_first_current, crrt_time_first_current, vasoactive_first_time_current
  )

out_csv <- file.path(out_dir, "SOFA2_outcomes_master.csv")
out_rds <- file.path(out_dir, "SOFA2_outcomes_master.rds")
readr::write_csv(outcomes, out_csv)
saveRDS(outcomes, out_rds)

summary_table <- data.frame(
  outcome = c(
    "ICU death",
    "Hospital death",
    "90-day death",
    "365-day death",
    "28-day ventilator-free days: mean",
    "28-day vasopressor-free days: mean",
    "28-day RRT-free days: mean",
    "28-day ICU-free days: mean",
    "Day 3 new invasive ventilation",
    "Day 3 new septic shock",
    "Day 3 new AKI",
    "Day 3 new RRT"
  ),
  value = c(
    sum(outcomes$icu_expire_flag == 1, na.rm = TRUE),
    sum(outcomes$hospital_expire_flag == 1, na.rm = TRUE),
    sum(outcomes$mortality_90 == 1, na.rm = TRUE),
    sum(outcomes$mortality_365 == 1, na.rm = TRUE),
    mean(outcomes$invasive_vent_free_days_28, na.rm = TRUE),
    mean(outcomes$vasopressor_free_days_28, na.rm = TRUE),
    mean(outcomes$rrt_free_days_28, na.rm = TRUE),
    mean(outcomes$icu_free_days_28, na.rm = TRUE),
    sum(outcomes$day3_new_invasive_vent == 1, na.rm = TRUE),
    sum(outcomes$day3_new_septic_shock == 1, na.rm = TRUE),
    sum(outcomes$day3_new_aki == 1, na.rm = TRUE),
    sum(outcomes$day3_new_rrt == 1, na.rm = TRUE)
  ),
  denominator = c(
    nrow(outcomes), nrow(outcomes), nrow(outcomes), nrow(outcomes),
    nrow(outcomes), nrow(outcomes), nrow(outcomes), nrow(outcomes),
    sum(outcomes$day3_preexisting_invasive_vent == 0, na.rm = TRUE),
    sum(outcomes$day3_preexisting_septic_shock == 0, na.rm = TRUE),
    sum(outcomes$day3_preexisting_aki == 0, na.rm = TRUE),
    sum(outcomes$day3_preexisting_rrt == 0, na.rm = TRUE)
  )
)
write.csv(summary_table, file.path(table_dir, "SOFA2_outcomes_master_summary.csv"), row.names = FALSE)

manifest <- list(
  project = "SOFA2 older sepsis",
  output_name = "SOFA2_outcomes_master",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  cohort_source = master_path,
  cohort_n = nrow(cohort),
  definitions = list(
    invasive_vent_free_days_28 = "28 minus invasive mechanical ventilation days during the first 28 days after ICU admission, set to 0 for ICU 28-day deaths. Invasive ventilation uses mimiciv_derived.ventilation statuses InvasiveVent and Tracheostomy.",
    vasopressor_free_days_28 = "28 minus six-agent vasoactive infusion days during the first 28 days after ICU admission, set to 0 for ICU 28-day deaths. Agents: dopamine, epinephrine, norepinephrine, phenylephrine, vasopressin, dobutamine.",
    rrt_free_days_28 = "28 minus days with active RRT/CRRT records during the first 28 days after ICU admission, set to 0 for ICU 28-day deaths. RRT uses mimiciv_derived.rrt dialysis_active=1 and mimiciv_derived.crrt system_active=1.",
    icu_free_days_28 = "28 minus ICU length of stay capped at 28 days, set to 0 for ICU 28-day deaths.",
    day3_new_events = "First event time strictly after ICU admission plus 72 hours; companion preexisting flags identify patients with events on or before 72 hours."
  ),
  database_sources = list(
    ventilation = "mimiciv_derived.ventilation",
    vasoactive = "mimiciv_derived.vasoactive_agent",
    rrt = "mimiciv_derived.rrt",
    crrt = "mimiciv_derived.crrt"
  ),
  files = list(
    csv = list(path = out_csv, sha256 = digest::digest(file = out_csv, algo = "sha256")),
    rds = list(path = out_rds, sha256 = digest::digest(file = out_rds, algo = "sha256"))
  )
)
yaml::write_yaml(manifest, file.path(out_dir, "SOFA2_outcomes_master_manifest.yml"))

message("Outcomes master completed.")
message("Rows: ", nrow(outcomes), "; columns: ", ncol(outcomes))
message("Output: ", out_csv)

