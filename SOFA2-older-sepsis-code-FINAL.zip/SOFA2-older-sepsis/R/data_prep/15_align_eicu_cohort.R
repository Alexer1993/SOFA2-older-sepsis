set.seed(2026)
project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
processed_dir <- file.path(project_root, "data", "processed")
table_dir <- file.path(project_root, "outputs", "tables")
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

required <- c("readr", "openxlsx", "yaml", "digest")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) stop("Missing packages: ", paste(missing, collapse = ", "))

input_rds <- file.path(processed_dir, "eicu_external_validation_final_updated.rds")
d <- readRDS(input_rds)

# FINAL REVISION RULE: do not remove admissions because SOFA-2 is missing, zero,
# or outside a prespecified range. The input to this step must already represent
# the final eICU cohort defined by non-SOFA eligibility criteria.
out <- d
expected_n <- 11437L
if (nrow(out) != expected_n) {
  stop(
    "Final eICU cohort audit expected ", expected_n, " admissions but found ", nrow(out),
    ". Regenerate the upstream final adult sepsis-source/timing cohort. Do not repair the count by filtering SOFA-2 values."
  )
}

sofa2_name <- "sofa2_dynamic_24h_max"
sofa2 <- if (sofa2_name %in% names(out)) suppressWarnings(as.numeric(out[[sofa2_name]])) else rep(NA_real_, nrow(out))
summary_table <- data.frame(
  item = c("final_validation_rows", "sofa2_24h_missing", "sofa2_24h_equal_0", "sofa2_24h_outside_0_24", "duplicate_patientunitstayid"),
  value = c(nrow(out), sum(is.na(sofa2)), sum(sofa2 == 0, na.rm = TRUE), sum(sofa2 < 0 | sofa2 > 24, na.rm = TRUE), sum(duplicated(out$patientunitstayid)))
)

out_csv <- file.path(processed_dir, "eicu_external_validation_final_cohort.csv")
out_rds <- file.path(processed_dir, "eicu_external_validation_final_cohort.rds")
out_xlsx <- file.path(processed_dir, "eicu_external_validation_final_cohort.xlsx")
saveRDS(out, out_rds)
readr::write_csv(out, out_csv)
openxlsx::write.xlsx(out, out_xlsx, overwrite = TRUE)
readr::write_csv(summary_table, file.path(table_dir, "eicu_final_cohort_sofa2_availability_audit.csv"))

manifest <- list(
  project = "SOFA2 older sepsis",
  output_name = "eicu_external_validation_final_cohort",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  purpose = "Final eICU validation cohort; no SOFA-2-based cohort exclusion is applied at this step.",
  expected_final_rows = expected_n,
  input = input_rds,
  counts = as.list(stats::setNames(summary_table$value, summary_table$item)),
  files = list(
    csv = list(path = out_csv, sha256 = digest::digest(file = out_csv, algo = "sha256")),
    rds = list(path = out_rds, sha256 = digest::digest(file = out_rds, algo = "sha256")),
    xlsx = list(path = out_xlsx, sha256 = digest::digest(file = out_xlsx, algo = "sha256"))
  )
)
yaml::write_yaml(manifest, file.path(processed_dir, "eicu_external_validation_final_cohort_manifest.yml"))
print(summary_table)
