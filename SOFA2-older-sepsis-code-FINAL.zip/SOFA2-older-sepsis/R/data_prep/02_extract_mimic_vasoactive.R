required_packages <- c("DBI", "RPostgres", "dplyr", "readr", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

source(file.path(normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE), "R", "data_prep", "connect_mimic.R"))

cohort_path <- "data/processed/SOFA2_final_cohort.csv"
out_dir <- "data/processed"

cohort <- readr::read_csv(cohort_path, show_col_types = FALSE) |>
  dplyr::select(subject_id, hadm_id, stay_id)

sql <- "
WITH CombinedMeds AS (
    SELECT stay_id, starttime
    FROM mimiciv_derived.dopamine
    WHERE starttime IS NOT NULL
    UNION ALL
    SELECT stay_id, starttime
    FROM mimiciv_derived.epinephrine
    WHERE starttime IS NOT NULL
    UNION ALL
    SELECT stay_id, starttime
    FROM mimiciv_derived.norepinephrine
    WHERE starttime IS NOT NULL
    UNION ALL
    SELECT stay_id, starttime
    FROM mimiciv_derived.phenylephrine
    WHERE starttime IS NOT NULL
    UNION ALL
    SELECT stay_id, starttime
    FROM mimiciv_derived.dobutamine
    WHERE starttime IS NOT NULL
    UNION ALL
    SELECT stay_id, starttime
    FROM mimiciv_derived.vasopressin
    WHERE starttime IS NOT NULL
)
SELECT
    stay_id,
    MIN(starttime) AS vasoactive_first_time
FROM CombinedMeds
GROUP BY stay_id
"

con <- connect_mimic()
on.exit(DBI::dbDisconnect(con), add = TRUE)

vaso_first_all <- DBI::dbGetQuery(con, sql)

vaso_first <- cohort |>
  dplyr::left_join(vaso_first_all, by = "stay_id") |>
  dplyr::mutate(
    vasoactive_use = dplyr::if_else(is.na(.data$vasoactive_first_time), 0L, 1L),
    vasoactive_first_time = as.POSIXct(.data$vasoactive_first_time, tz = "UTC")
  ) |>
  dplyr::select(subject_id, hadm_id, stay_id, vasoactive_use, vasoactive_first_time)

out_csv <- file.path(out_dir, "SOFA2_final_cohort_vasoactive_first_use.csv")
out_rds <- file.path(out_dir, "SOFA2_final_cohort_vasoactive_first_use.rds")

readr::write_csv(vaso_first, out_csv)
saveRDS(vaso_first, out_rds)

manifest <- list(
  project = "SOFA2老年脓毒症",
  output_name = "SOFA2_final_cohort_vasoactive_first_use",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  cohort_file = cohort_path,
  definition = "vasoactive_use is 1 if dopamine, epinephrine, norepinephrine, phenylephrine, dobutamine, or vasopressin was used at least once for the ICU stay; vasoactive_first_time is the earliest non-missing starttime across these six derived medication tables.",
  counts = list(
    final_cohort_rows = nrow(cohort),
    output_rows = nrow(vaso_first),
    vasoactive_use_1 = sum(vaso_first$vasoactive_use == 1),
    vasoactive_use_0 = sum(vaso_first$vasoactive_use == 0),
    missing_first_time_among_use_1 = sum(vaso_first$vasoactive_use == 1 & is.na(vaso_first$vasoactive_first_time))
  ),
  files = list(
    csv = list(path = out_csv, sha256 = digest::digest(file = out_csv, algo = "sha256")),
    rds = list(path = out_rds, sha256 = digest::digest(file = out_rds, algo = "sha256"))
  )
)

yaml::write_yaml(manifest, file.path(out_dir, "SOFA2_final_cohort_vasoactive_first_use_manifest.yml"))

message("Vasoactive first-use table completed.")
message("Output rows: ", nrow(vaso_first))
message("vasoactive_use = 1: ", sum(vaso_first$vasoactive_use == 1))
message("vasoactive_use = 0: ", sum(vaso_first$vasoactive_use == 0))

