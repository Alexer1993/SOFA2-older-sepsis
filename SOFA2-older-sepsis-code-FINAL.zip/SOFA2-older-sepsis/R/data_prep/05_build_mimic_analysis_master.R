required_packages <- c("dplyr", "readr", "readxl", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

join_keys <- c("subject_id", "hadm_id", "stay_id")
out_dir <- "data/processed"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

read_csv_utf8 <- function(path) {
  readr::read_csv(path, show_col_types = FALSE, locale = readr::locale(encoding = "UTF-8"))
}

normalize_join_keys <- function(data, source_name) {
  missing_keys <- setdiff(join_keys, names(data))
  if (length(missing_keys) > 0) {
    stop(source_name, " is missing join keys: ", paste(missing_keys, collapse = ", "))
  }

  data |>
    dplyr::mutate(dplyr::across(dplyr::all_of(join_keys), ~ suppressWarnings(as.numeric(.x))))
}

assert_unique_keys <- function(data, source_name) {
  missing_keys <- setdiff(join_keys, names(data))
  if (length(missing_keys) > 0) {
    stop(source_name, " is missing join keys: ", paste(missing_keys, collapse = ", "))
  }

  dup <- data |>
    dplyr::count(dplyr::across(dplyr::all_of(join_keys)), name = "n") |>
    dplyr::filter(.data$n > 1)

  if (nrow(dup) > 0) {
    dup_path <- file.path(out_dir, paste0("duplicate_keys_", source_name, ".csv"))
    readr::write_csv(dup, dup_path)
    stop(source_name, " has duplicate subject_id + hadm_id + stay_id keys. See ", dup_path)
  }
}

merge_source <- function(master, source, source_name, source_path) {
  assert_unique_keys(source, source_name)

  source_keys <- source |>
    dplyr::select(dplyr::all_of(join_keys))

  matched_rows <- master |>
    dplyr::select(dplyr::all_of(join_keys)) |>
    dplyr::inner_join(source_keys, by = join_keys) |>
    nrow()

  unmatched_master_rows <- nrow(master) - matched_rows
  extra_source_rows <- source |>
    dplyr::anti_join(master |> dplyr::select(dplyr::all_of(join_keys)), by = join_keys) |>
    nrow()

  duplicate_columns <- intersect(setdiff(names(source), join_keys), names(master))
  source_reduced <- source |>
    dplyr::select(dplyr::all_of(join_keys), dplyr::all_of(setdiff(setdiff(names(source), join_keys), duplicate_columns)))

  merged <- master |>
    dplyr::left_join(source_reduced, by = join_keys)

  list(
    data = merged,
    summary = list(
      source_name = source_name,
      source_path = source_path,
      source_rows = nrow(source),
      source_columns = ncol(source),
      added_columns = ncol(source_reduced) - length(join_keys),
      duplicate_columns_dropped = duplicate_columns,
      matched_master_rows = matched_rows,
      unmatched_master_rows = unmatched_master_rows,
      extra_source_rows_not_in_master = extra_source_rows
    )
  )
}

master <- read_csv_utf8("data/processed/SOFA2_final_cohort.csv") |>
  normalize_join_keys("SOFA2_final_cohort")
assert_unique_keys(master, "SOFA2_final_cohort")
initial_rows <- nrow(master)
initial_cols <- ncol(master)

sources <- list(
  list(
    name = "vasoactive_first_use",
    path = "data/processed/SOFA2_final_cohort_vasoactive_first_use.csv",
    data = read_csv_utf8("data/processed/SOFA2_final_cohort_vasoactive_first_use.csv") |>
      normalize_join_keys("vasoactive_first_use")
  ),
  list(
    name = "other_total",
    path = "data/raw/other/total_table.csv",
    data = read_csv_utf8("data/raw/other/total_table.csv") |>
      normalize_join_keys("other_total")
  ),
  list(
    name = "other_blood_gas",
    path = "data/raw/other/blood_gas.csv",
    data = read_csv_utf8("data/raw/other/blood_gas.csv") |>
      normalize_join_keys("other_blood_gas")
  ),
  list(
    name = "other_prognosis",
    path = "data/raw/other/prognosis.csv",
    data = read_csv_utf8("data/raw/other/prognosis.csv") |>
      normalize_join_keys("other_prognosis")
  ),
  list(
    name = "other_infection_site",
    path = "data/raw/other/infection_site.xlsx",
    data = readxl::read_excel("data/raw/other/infection_site.xlsx", sheet = "Classification") |>
      normalize_join_keys("other_infection_site")
  )
)

merge_summaries <- list()
for (source in sources) {
  result <- merge_source(master, source$data, source$name, source$path)
  master <- result$data
  merge_summaries[[source$name]] <- result$summary
}

if (nrow(master) != initial_rows) {
  stop("Master table row count changed from ", initial_rows, " to ", nrow(master), ".")
}

master_csv <- file.path(out_dir, "SOFA2_analysis_master.csv")
master_rds <- file.path(out_dir, "SOFA2_analysis_master.rds")
readr::write_csv(master, master_csv)
saveRDS(master, master_rds)

merge_summary_rows <- do.call(
  rbind,
  lapply(merge_summaries, function(x) {
    data.frame(
      source_name = x$source_name,
      source_path = x$source_path,
      source_rows = x$source_rows,
      source_columns = x$source_columns,
      added_columns = x$added_columns,
      matched_master_rows = x$matched_master_rows,
      unmatched_master_rows = x$unmatched_master_rows,
      extra_source_rows_not_in_master = x$extra_source_rows_not_in_master,
      duplicate_columns_dropped = paste(x$duplicate_columns_dropped, collapse = "; "),
      stringsAsFactors = FALSE
    )
  })
)
summary_csv <- file.path(out_dir, "SOFA2_analysis_master_merge_summary.csv")
readr::write_csv(merge_summary_rows, summary_csv)

manifest <- list(
  project = "SOFA2老年脓毒症",
  output_name = "SOFA2_analysis_master",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  cohort_basis = "SOFA2_final_cohort; all sources were left-joined to this cohort using subject_id + hadm_id + stay_id.",
  join_keys = join_keys,
  counts = list(
    final_cohort_rows = initial_rows,
    final_cohort_columns = initial_cols,
    master_rows = nrow(master),
    master_columns = ncol(master)
  ),
  merge_summaries = merge_summaries,
  files = list(
    master_csv = list(path = master_csv, sha256 = digest::digest(file = master_csv, algo = "sha256")),
    master_rds = list(path = master_rds, sha256 = digest::digest(file = master_rds, algo = "sha256")),
    merge_summary_csv = list(path = summary_csv, sha256 = digest::digest(file = summary_csv, algo = "sha256"))
  )
)

yaml::write_yaml(manifest, file.path(out_dir, "SOFA2_analysis_master_manifest.yml"))

message("Analysis master table completed.")
message("Rows: ", nrow(master))
message("Columns: ", ncol(master))
for (row in seq_len(nrow(merge_summary_rows))) {
  message(
    merge_summary_rows$source_name[row],
    ": matched ", merge_summary_rows$matched_master_rows[row],
    "/", initial_rows,
    ", added columns ", merge_summary_rows$added_columns[row]
  )
}

