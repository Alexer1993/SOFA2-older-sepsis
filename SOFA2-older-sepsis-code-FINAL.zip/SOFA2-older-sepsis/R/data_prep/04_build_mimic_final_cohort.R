required_packages <- c("dplyr", "readr", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))

input_path <- "data/processed/SOFA2_subject_sofa_total.csv"
out_dir <- "data/processed"
cohort <- readr::read_csv(input_path, show_col_types = FALSE)

# FINAL REVISION RULE:
# Cohort membership is determined upstream by age, first ICU admission, ICU LOS,
# required temporal/outcome information, and Sepsis-3 within 0-48 h. SOFA-2
# availability/value is NOT an inclusion or exclusion criterion.
final_cohort <- cohort

expected_n <- 12643L
if (nrow(final_cohort) != expected_n) {
  warning(
    "Final MIMIC cohort audit expected ", expected_n, " admissions but found ", nrow(final_cohort),
    ". Recheck the upstream Sepsis-3 cohort query. Do not repair the count by filtering SOFA-2 values."
  )
}

sofa2_audit <- data.frame(
  item = c("final_cohort_rows", "missing_24h_sofa2_total", "sofa2_total_equal_0", "sofa2_total_outside_0_24"),
  value = c(
    nrow(final_cohort),
    if ("sofa2_dynamic24_max" %in% names(final_cohort)) sum(is.na(final_cohort$sofa2_dynamic24_max)) else NA_integer_,
    if ("sofa2_dynamic24_max" %in% names(final_cohort)) sum(final_cohort$sofa2_dynamic24_max == 0, na.rm = TRUE) else NA_integer_,
    if ("sofa2_dynamic24_max" %in% names(final_cohort)) sum(final_cohort$sofa2_dynamic24_max < 0 | final_cohort$sofa2_dynamic24_max > 24, na.rm = TRUE) else NA_integer_
  )
)

final_csv <- file.path(out_dir, "SOFA2_final_cohort.csv")
final_rds <- file.path(out_dir, "SOFA2_final_cohort.rds")
audit_csv <- file.path(out_dir, "SOFA2_final_cohort_sofa2_availability_audit.csv")
readr::write_csv(final_cohort, final_csv)
saveRDS(final_cohort, final_rds)
readr::write_csv(sofa2_audit, audit_csv)

manifest <- list(
  project = "SOFA2 older sepsis",
  output_name = "SOFA2_final_cohort",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  input_file = input_path,
  final_definition = "No cohort exclusion is based on SOFA-2 availability, total=0, or SOFA-2 range. Upstream cohort membership is based on age, first ICU admission, ICU LOS, key temporal/outcome information, and Sepsis-3 within 0-48 h.",
  expected_final_rows = expected_n,
  counts = list(input_rows = nrow(cohort), final_rows = nrow(final_cohort), final_columns = ncol(final_cohort)),
  files = list(
    final_csv = list(path = final_csv, sha256 = digest::digest(file = final_csv, algo = "sha256")),
    final_rds = list(path = final_rds, sha256 = digest::digest(file = final_rds, algo = "sha256")),
    sofa2_availability_audit = list(path = audit_csv, sha256 = digest::digest(file = audit_csv, algo = "sha256"))
  )
)
yaml::write_yaml(manifest, file.path(out_dir, "SOFA2_final_cohort_manifest.yml"))
print(sofa2_audit)
