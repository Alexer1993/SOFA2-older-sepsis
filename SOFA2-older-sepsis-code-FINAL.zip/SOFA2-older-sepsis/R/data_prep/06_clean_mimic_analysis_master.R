required_packages <- c("dplyr", "readr", "missForest", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

set.seed(2026)

input_path <- "data/processed/SOFA2_analysis_master.csv"
out_dir <- "data/processed"
report_dir <- "outputs/tables"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(report_dir, recursive = TRUE, showWarnings = FALSE)

data <- readr::read_csv(input_path, show_col_types = FALSE, locale = readr::locale(encoding = "UTF-8"))

simple_threshold <- 0.05
delete_threshold <- 0.30
seed_value <- 2026
missforest_maxiter <- 5
missforest_ntree <- 20

id_cols <- c("subject_id", "hadm_id", "stay_id")

core_time_cols <- c(
  "icu_intime", "icu_outtime", "suspected_infection_time", "sofa_time", "sepsis_time",
  "admittime", "dischtime", "dod"
)

structural_time_cols <- names(data)[grepl("(^|_)(time|intime|outtime|admittime|dischtime|dod)($|_)", names(data), ignore.case = TRUE)]
structural_time_cols <- union(structural_time_cols, core_time_cols)

structural_interval_cols <- names(data)[grepl("^hours_(since|to)_", names(data), ignore.case = TRUE)]

sofa_long_window_cols <- names(data)[grepl("^(sofa|sofa2)_dynamic(120|144|168)_", names(data), ignore.case = TRUE)]

protected_from_deletion <- unique(intersect(
  c(id_cols, core_time_cols, structural_time_cols, structural_interval_cols, sofa_long_window_cols),
  names(data)
))

missing_rate <- colMeans(is.na(data))
n_unique <- vapply(data, function(x) dplyr::n_distinct(x, na.rm = TRUE), integer(1))
classes <- vapply(data, function(x) paste(class(x), collapse = ";"), character(1))

decision <- data.frame(
  variable = names(data),
  class = classes,
  n_unique_nonmissing = n_unique,
  missing_n = colSums(is.na(data)),
  missing_rate = as.numeric(missing_rate),
  protected_from_deletion = names(data) %in% protected_from_deletion,
  decision = NA_character_,
  reason = NA_character_,
  stringsAsFactors = FALSE
)

all_missing_cols <- decision$variable[decision$missing_rate == 1 & !decision$protected_from_deletion]
high_missing_drop_cols <- decision$variable[
  decision$missing_rate > delete_threshold &
    decision$missing_rate < 1 &
    !decision$protected_from_deletion
]

delete_cols <- c(all_missing_cols, high_missing_drop_cols)

protected_high_missing_cols <- decision$variable[
  decision$missing_rate > delete_threshold &
    decision$protected_from_deletion
]

cleaned <- data |>
  dplyr::select(-dplyr::any_of(delete_cols))

remaining_missing_rate <- colMeans(is.na(cleaned))

non_impute_cols <- unique(intersect(
  c(id_cols, structural_time_cols, structural_interval_cols),
  names(cleaned)
))

simple_impute_cols <- names(cleaned)[
  remaining_missing_rate > 0 &
    remaining_missing_rate < simple_threshold &
    !(names(cleaned) %in% non_impute_cols)
]

missforest_cols <- names(cleaned)[
  remaining_missing_rate >= simple_threshold &
    remaining_missing_rate <= delete_threshold &
    !(names(cleaned) %in% non_impute_cols)
]

high_cardinality_categorical_cols <- missforest_cols[
  vapply(cleaned[missforest_cols], function(x) {
    (is.character(x) || is.factor(x)) && dplyr::n_distinct(x, na.rm = TRUE) > 50
  }, logical(1))
]

for (col in high_cardinality_categorical_cols) {
  cleaned[[col]] <- as.character(cleaned[[col]])
  cleaned[[col]][is.na(cleaned[[col]])] <- "Missing"
}

missforest_cols <- setdiff(missforest_cols, high_cardinality_categorical_cols)

mode_value <- function(x) {
  x_no_na <- x[!is.na(x)]
  if (length(x_no_na) == 0) {
    return(NA)
  }
  names(sort(table(x_no_na), decreasing = TRUE))[1]
}

simple_impute_one <- function(x) {
  if (is.numeric(x) || inherits(x, "Date") || inherits(x, "POSIXct")) {
    x_num <- as.numeric(x)
    skew <- stats::median(x_num, na.rm = TRUE) - mean(x_num, na.rm = TRUE)
    use_median <- isTRUE(abs(skew) > stats::sd(x_num, na.rm = TRUE) * 0.1)
    fill <- if (use_median) stats::median(x, na.rm = TRUE) else mean(x, na.rm = TRUE)
    x[is.na(x)] <- fill
    return(x)
  }

  fill <- mode_value(x)
  x[is.na(x)] <- fill
  x
}

for (col in simple_impute_cols) {
  cleaned[[col]] <- simple_impute_one(cleaned[[col]])
}

missforest_input <- cleaned |>
  dplyr::select(dplyr::all_of(missforest_cols)) |>
  as.data.frame()

missforest_imputed_cols <- character(0)
missforest_skipped_cols <- character(0)
missforest_oob_error <- NULL

if (length(missforest_cols) > 0) {
  for (col in names(missforest_input)) {
    if (is.character(missforest_input[[col]]) || is.logical(missforest_input[[col]])) {
      missforest_input[[col]] <- as.factor(missforest_input[[col]])
    }
    if (inherits(missforest_input[[col]], "POSIXct") || inherits(missforest_input[[col]], "Date")) {
      missforest_input[[col]] <- as.numeric(missforest_input[[col]])
    }
  }

  constant_cols <- names(missforest_input)[
    vapply(missforest_input, function(x) dplyr::n_distinct(x, na.rm = TRUE) <= 1, logical(1))
  ]
  if (length(constant_cols) > 0) {
    missforest_input <- missforest_input |>
      dplyr::select(-dplyr::all_of(constant_cols))
    missforest_skipped_cols <- constant_cols
  }

  if (ncol(missforest_input) > 0) {
    set.seed(seed_value)
    mf <- missForest::missForest(
      missforest_input,
      maxiter = missforest_maxiter,
      ntree = missforest_ntree,
      variablewise = FALSE,
      verbose = TRUE
    )
    imputed <- mf$ximp
    missforest_oob_error <- mf$OOBerror
    missforest_imputed_cols <- names(imputed)

    for (col in names(imputed)) {
      cleaned[[col]] <- imputed[[col]]
    }
  }
}

decision$decision[decision$variable %in% delete_cols] <- "deleted_high_missing"
decision$reason[decision$variable %in% all_missing_cols] <- "missing_rate_is_100_percent_and_not_structurally_protected"
decision$reason[decision$variable %in% high_missing_drop_cols] <- "missing_rate_above_30_percent_and_not_structurally_protected"

decision$decision[decision$variable %in% protected_high_missing_cols] <- "kept_structural_or_time_related"
decision$reason[decision$variable %in% protected_high_missing_cols] <- "high_missing_but_structural_time_interval_or_long_window_variable"

decision$decision[decision$variable %in% simple_impute_cols] <- "simple_imputed"
decision$reason[decision$variable %in% simple_impute_cols] <- "missing_rate_below_5_percent"

decision$decision[decision$variable %in% missforest_imputed_cols] <- "missforest_imputed"
decision$reason[decision$variable %in% missforest_imputed_cols] <- "missing_rate_between_5_and_30_percent"

decision$decision[decision$variable %in% missforest_skipped_cols] <- "missforest_skipped_constant"
decision$reason[decision$variable %in% missforest_skipped_cols] <- "constant_or_single_nonmissing_value_after_preparation"

decision$decision[decision$variable %in% high_cardinality_categorical_cols] <- "missing_category_imputed"
decision$reason[decision$variable %in% high_cardinality_categorical_cols] <- "high_cardinality_categorical_or_text_variable_not_suitable_for_random_forest_factor_imputation"

decision$decision[is.na(decision$decision) & decision$variable %in% names(cleaned)] <- "kept_no_imputation"
decision$reason[is.na(decision$reason) & decision$variable %in% names(cleaned)] <- "complete_or_non_imputed_protected_variable"

decision$decision[is.na(decision$decision)] <- "not_classified"

final_missing <- data.frame(
  variable = names(cleaned),
  missing_n_after_cleaning = colSums(is.na(cleaned)),
  missing_rate_after_cleaning = as.numeric(colMeans(is.na(cleaned))),
  stringsAsFactors = FALSE
)

cleaned_csv <- file.path(out_dir, "SOFA2_analysis_master_cleaned.csv")
cleaned_rds <- file.path(out_dir, "SOFA2_analysis_master_cleaned.rds")
decision_csv <- file.path(report_dir, "SOFA2_cleaning_decision_report.csv")
final_missing_csv <- file.path(report_dir, "SOFA2_cleaning_final_missing_report.csv")

readr::write_csv(cleaned, cleaned_csv)
saveRDS(cleaned, cleaned_rds)
readr::write_csv(decision, decision_csv)
readr::write_csv(final_missing, final_missing_csv)

manifest <- list(
  project = "SOFA2老年脓毒症",
  output_name = "SOFA2_analysis_master_cleaned",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  input_file = input_path,
  seed = seed_value,
  rules = list(
    delete_threshold = delete_threshold,
    simple_impute_threshold = simple_threshold,
    missforest_missing_range = ">=5% and <=30%",
    missforest_maxiter = missforest_maxiter,
    missforest_ntree = missforest_ntree,
    structural_exemption = "ID columns, event/time columns, interval columns, and long SOFA window columns were protected from deletion and not blindly imputed."
  ),
  counts = list(
    input_rows = nrow(data),
    input_columns = ncol(data),
    output_rows = nrow(cleaned),
    output_columns = ncol(cleaned),
    deleted_columns = length(delete_cols),
    protected_high_missing_columns = length(protected_high_missing_cols),
    simple_imputed_columns = length(simple_impute_cols),
    high_cardinality_categorical_missing_category_columns = length(high_cardinality_categorical_cols),
    missforest_imputed_columns = length(missforest_imputed_cols),
    missforest_skipped_constant_columns = length(missforest_skipped_cols)
  ),
  missforest_oob_error = missforest_oob_error,
  files = list(
    cleaned_csv = list(path = cleaned_csv, sha256 = digest::digest(file = cleaned_csv, algo = "sha256")),
    cleaned_rds = list(path = cleaned_rds, sha256 = digest::digest(file = cleaned_rds, algo = "sha256")),
    decision_report = list(path = decision_csv, sha256 = digest::digest(file = decision_csv, algo = "sha256")),
    final_missing_report = list(path = final_missing_csv, sha256 = digest::digest(file = final_missing_csv, algo = "sha256"))
  )
)

yaml::write_yaml(manifest, file.path(out_dir, "SOFA2_analysis_master_cleaned_manifest.yml"))

message("Cleaning completed.")
message("Rows: ", nrow(cleaned))
message("Columns before: ", ncol(data), "; after: ", ncol(cleaned))
message("Deleted columns: ", length(delete_cols))
message("Protected high-missing columns kept: ", length(protected_high_missing_cols))
message("Simple-imputed columns: ", length(simple_impute_cols))
message("High-cardinality categorical columns imputed with Missing: ", length(high_cardinality_categorical_cols))
message("MissForest-imputed columns: ", length(missforest_imputed_cols))

