project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)

required_packages <- c("dplyr", "readr", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

processed_dir <- file.path(project_root, "data", "processed")
table_dir <- file.path(project_root, "outputs", "tables")
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

raw_path <- file.path(processed_dir, "SOFA2_analysis_master.rds")
cleaned_path <- file.path(processed_dir, "SOFA2_analysis_master_cleaned.rds")

raw <- readRDS(raw_path)
cleaned <- readRDS(cleaned_path)

id_cols <- c("subject_id", "hadm_id", "stay_id")
if (!all(id_cols %in% names(raw)) || !all(id_cols %in% names(cleaned))) {
  stop("ID columns are missing from raw or cleaned data.")
}

if (nrow(raw) != nrow(cleaned)) {
  stop("Raw and cleaned data do not have the same row count.")
}

if (anyDuplicated(raw[id_cols]) > 0 || anyDuplicated(cleaned[id_cols]) > 0) {
  stop("Duplicate subject_id/hadm_id/stay_id combinations found.")
}

score_pattern <- "^(sofa|sofa2)_dynamic|^sofa$|^sofa2$|^sepsis3_sofa2$|^sepsis3_sofa2_time$|^sofa_time$"
sofa_score_cols <- grep(score_pattern, names(raw), value = TRUE, ignore.case = TRUE)
sofa_score_cols <- unique(c(id_cols, sofa_score_cols))

cleaned_without_sofa_scores <- cleaned |>
  dplyr::select(-dplyr::any_of(setdiff(sofa_score_cols, id_cols)))

modeling <- cleaned_without_sofa_scores |>
  dplyr::left_join(raw |> dplyr::select(dplyr::all_of(sofa_score_cols)), by = id_cols)

if (nrow(modeling) != nrow(cleaned)) {
  stop("Modeling dataset row count changed during SOFA score replacement.")
}

score_report <- data.frame(
  variable = setdiff(sofa_score_cols, id_cols),
  source_in_modeling_dataset = "SOFA2_analysis_master_raw_unimputed",
  missing_n_raw = vapply(raw[setdiff(sofa_score_cols, id_cols)], function(x) sum(is.na(x)), integer(1)),
  missing_rate_raw = vapply(raw[setdiff(sofa_score_cols, id_cols)], function(x) mean(is.na(x)), numeric(1)),
  stringsAsFactors = FALSE
)

out_csv <- file.path(processed_dir, "SOFA2_analysis_modeling_reference_sofa.csv")
out_rds <- file.path(processed_dir, "SOFA2_analysis_modeling_reference_sofa.rds")
score_report_csv <- file.path(table_dir, "SOFA2_modeling_reference_sofa_score_sources.csv")

readr::write_csv(modeling, out_csv)
saveRDS(modeling, out_rds)
readr::write_csv(score_report, score_report_csv)

manifest <- list(
  project = "SOFA2 older sepsis",
  output_name = "SOFA2_analysis_modeling_reference_sofa",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  principle = "Covariates are taken from the cleaned/MissForest-imputed analysis table, while all SOFA/SOFA2 exposure and trajectory variables are taken from the raw, non-imputed SOFA analysis master table.",
  raw_source = raw_path,
  cleaned_covariate_source = cleaned_path,
  id_columns = id_cols,
  sofa_score_columns_replaced_from_raw = setdiff(sofa_score_cols, id_cols),
  counts = list(
    rows = nrow(modeling),
    columns = ncol(modeling),
    sofa_score_columns_from_raw = length(setdiff(sofa_score_cols, id_cols))
  ),
  files = list(
    csv = list(path = out_csv, sha256 = digest::digest(file = out_csv, algo = "sha256")),
    rds = list(path = out_rds, sha256 = digest::digest(file = out_rds, algo = "sha256")),
    sofa_score_source_report = list(path = score_report_csv, sha256 = digest::digest(file = score_report_csv, algo = "sha256"))
  )
)

yaml::write_yaml(manifest, file.path(processed_dir, "SOFA2_analysis_modeling_reference_sofa_manifest.yml"))

message("Modeling dataset with raw SOFA/SOFA2 scores completed.")
message("Rows: ", nrow(modeling), "; columns: ", ncol(modeling))
message("SOFA/SOFA2 score columns replaced from raw: ", length(setdiff(sofa_score_cols, id_cols)))
message("Output: ", out_csv)


