project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "data_prep", "connect_eicu.R"))

required_packages <- c("DBI", "dplyr", "readr", "readxl", "openxlsx", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

processed_dir <- file.path(project_root, "data", "processed")
table_dir <- file.path(project_root, "outputs", "tables")
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

input_excel <- file.path(project_root, "data", "external", "eicu", "eicu_external_data.xlsx")
raw <- readxl::read_excel(input_excel, sheet = 1)
raw <- as.data.frame(raw)

id_col <- "patientunitstayid"
if (!id_col %in% names(raw)) stop("patientunitstayid is missing from the uploaded eICU Excel file.")
if (!"sepsis3_hr" %in% names(raw)) stop("sepsis3_hr is required to align the sepsis timing window.")

raw_n <- nrow(raw)
raw_unique_stay_n <- dplyr::n_distinct(raw[[id_col]])

cohort <- raw |>
  dplyr::mutate(
    sepsis3_hr_for_window = suppressWarnings(as.numeric(.data$sepsis3_hr)),
    eicu_sepsis_within_48h = as.integer(!is.na(.data$sepsis3_hr_for_window) &
                                          .data$sepsis3_hr_for_window >= 0 &
                                          .data$sepsis3_hr_for_window <= 48)
  ) |>
  dplyr::filter(.data$eicu_sepsis_within_48h == 1)

# Final revision audit: this input must represent the final non-SOFA-defined eICU cohort.
if (nrow(cohort) != 11437L) {
  stop("Expected 11,437 final eICU admissions after non-SOFA eligibility criteria; found ", nrow(cohort),
       ". Regenerate the source cohort rather than applying a SOFA-2 availability/value filter.")
}

if (anyDuplicated(cohort[[id_col]]) > 0) {
  stop("The aligned eICU cohort contains duplicate patientunitstayid values.")
}

con <- connect_eicu()
on.exit(DBI::dbDisconnect(con), add = TRUE)

DBI::dbWriteTable(
  con,
  name = "tmp_eicu_external_cohort",
  value = data.frame(patientunitstayid = as.integer(cohort[[id_col]])),
  temporary = TRUE,
  overwrite = TRUE
)

patient_source <- DBI::dbGetQuery(con, "
  select
    p.patientunitstayid,
    p.unitadmitsource,
    p.hospitaladmitsource,
    p.apacheadmissiondx
  from public.patient p
  inner join tmp_eicu_external_cohort c using (patientunitstayid)
")

vent_raw <- DBI::dbGetQuery(con, "
  select
    r.patientunitstayid,
    r.respcareid,
    r.respcarestatusoffset,
    r.airwaytype,
    r.ventstartoffset,
    r.ventendoffset,
    r.priorventstartoffset,
    r.priorventendoffset
  from public.respiratorycare r
  inner join tmp_eicu_external_cohort c using (patientunitstayid)
  where r.ventstartoffset is not null
")

vaso_raw <- DBI::dbGetQuery(con, "
  select
    i.patientunitstayid,
    i.infusiondrugid,
    i.infusionoffset,
    i.drugname,
    i.drugrate,
    i.infusionrate,
    i.drugamount,
    i.patientweight
  from public.infusiondrug i
  inner join tmp_eicu_external_cohort c using (patientunitstayid)
  where lower(i.drugname) ~ '(norepinephrine|levophed|epinephrine|dopamine|dobutamine|phenylephrine|neosynephrine|vasopressin)'
")

rrt_io_raw <- DBI::dbGetQuery(con, "
  select
    io.patientunitstayid,
    io.intakeoutputid,
    io.intakeoutputoffset as rrt_offset,
    io.dialysistotal,
    io.cellpath,
    io.celllabel,
    io.cellvaluenumeric,
    io.cellvaluetext
  from public.intakeoutput io
  inner join tmp_eicu_external_cohort c using (patientunitstayid)
  where io.dialysistotal > 0
     or lower(coalesce(io.cellpath, '')) like '%dialysis%'
     or lower(coalesce(io.celllabel, '')) like '%dialysis%'
")

rrt_treatment_raw <- DBI::dbGetQuery(con, "
  select
    t.patientunitstayid,
    t.treatmentid,
    t.treatmentoffset as rrt_offset,
    t.treatmentstring
  from public.treatment t
  inner join tmp_eicu_external_cohort c using (patientunitstayid)
  where lower(t.treatmentstring) ~ '(dialysis|crrt|cvvh|rrt|renal replacement)'
")

apache_dialysis <- DBI::dbGetQuery(con, "
  select
    a.patientunitstayid,
    max(case when a.dialysis = 1 then 1 else 0 end) as apache_dialysis
  from public.apacheapsvar a
  inner join tmp_eicu_external_cohort c using (patientunitstayid)
  group by a.patientunitstayid
")

day_index <- function(offset_min) {
  pmax(1L, pmin(28L, floor(as.numeric(offset_min) / 1440) + 1L))
}

summarise_vent <- function(df) {
  if (nrow(df) == 0) {
    return(data.frame(patientunitstayid = integer()))
  }

  df |>
    dplyr::mutate(
      ventstartoffset = as.numeric(.data$ventstartoffset),
      ventendoffset = as.numeric(.data$ventendoffset),
      clipped_start = pmax(.data$ventstartoffset, 0, na.rm = TRUE),
      clipped_end = dplyr::case_when(
        !is.na(.data$ventendoffset) & .data$ventendoffset > .data$ventstartoffset ~ pmin(.data$ventendoffset, 40320, na.rm = TRUE),
        TRUE ~ .data$clipped_start
      ),
      has_interval = !is.na(.data$ventendoffset) & .data$ventendoffset > .data$ventstartoffset,
      day_start = day_index(.data$clipped_start),
      day_end = day_index(.data$clipped_end)
    ) |>
    dplyr::filter(.data$ventstartoffset <= 40320) |>
    dplyr::rowwise() |>
    dplyr::mutate(vent_days_list = list(seq.int(.data$day_start, .data$day_end))) |>
    dplyr::ungroup() |>
    dplyr::group_by(.data$patientunitstayid) |>
    dplyr::summarise(
      invasivevent_first_offset = min(.data$ventstartoffset, na.rm = TRUE),
      invasivevent_first_offset_after_icu = if (any(.data$ventstartoffset >= 0, na.rm = TRUE)) {
        min(.data$ventstartoffset[.data$ventstartoffset >= 0], na.rm = TRUE)
      } else {
        NA_real_
      },
      invasivevent_days_28_approx = dplyr::n_distinct(unlist(.data$vent_days_list)),
      invasivevent_has_true_interval = as.integer(any(.data$has_interval, na.rm = TRUE)),
      .groups = "drop"
    )
}

summarise_offset_days <- function(df, offset_col, prefix) {
  if (nrow(df) == 0) {
    return(data.frame(patientunitstayid = integer()))
  }
  df[[offset_col]] <- as.numeric(df[[offset_col]])
  df |>
    dplyr::filter(!is.na(.data[[offset_col]]), .data[[offset_col]] <= 40320) |>
    dplyr::mutate(
      offset_after_icu = dplyr::if_else(.data[[offset_col]] >= 0, .data[[offset_col]], NA_real_),
      day = day_index(pmax(.data[[offset_col]], 0, na.rm = TRUE))
    ) |>
    dplyr::group_by(.data$patientunitstayid) |>
    dplyr::summarise(
      "{prefix}_first_offset" := min(.data[[offset_col]], na.rm = TRUE),
      "{prefix}_first_offset_after_icu" := if (any(!is.na(.data$offset_after_icu))) {
        min(.data$offset_after_icu, na.rm = TRUE)
      } else {
        NA_real_
      },
      "{prefix}_days_28_approx" := dplyr::n_distinct(.data$day),
      .groups = "drop"
    )
}

vent_summary <- summarise_vent(vent_raw)
vaso_summary <- summarise_offset_days(vaso_raw, "infusionoffset", "vasoactive")

rrt_offsets <- dplyr::bind_rows(
  rrt_io_raw |>
    dplyr::transmute(patientunitstayid, rrt_offset = as.numeric(.data$rrt_offset), rrt_source = "intakeoutput"),
  rrt_treatment_raw |>
    dplyr::transmute(patientunitstayid, rrt_offset = as.numeric(.data$rrt_offset), rrt_source = "treatment")
)
rrt_summary <- summarise_offset_days(rrt_offsets, "rrt_offset", "rrt")

add_missing_support_values <- function(df) {
  df |>
    dplyr::mutate(
      invasivevent_first_offset = dplyr::coalesce(.data$invasivevent_first_offset, NA_real_),
      invasivevent_days_28_approx = dplyr::coalesce(.data$invasivevent_days_28_approx, 0L),
      vasoactive_first_offset = dplyr::coalesce(.data$vasoactive_first_offset, NA_real_),
      vasoactive_days_28_approx = dplyr::coalesce(.data$vasoactive_days_28_approx, 0L),
      rrt_first_offset = dplyr::coalesce(.data$rrt_first_offset, NA_real_),
      rrt_days_28_approx = dplyr::coalesce(.data$rrt_days_28_approx, 0L)
    )
}

enhanced <- cohort |>
  dplyr::left_join(patient_source, by = "patientunitstayid") |>
  dplyr::left_join(vent_summary, by = "patientunitstayid") |>
  dplyr::left_join(vaso_summary, by = "patientunitstayid") |>
  dplyr::left_join(rrt_summary, by = "patientunitstayid") |>
  dplyr::left_join(apache_dialysis, by = "patientunitstayid") |>
  add_missing_support_values() |>
  dplyr::mutate(
    invasivevent_use_db = as.integer(!is.na(.data$invasivevent_first_offset)),
    vasoactive_use_db = as.integer(!is.na(.data$vasoactive_first_offset)),
    rrt_use_db = as.integer(!is.na(.data$rrt_first_offset) | dplyr::coalesce(.data$apache_dialysis, 0L) == 1L),
    mortality_28_for_free_days = as.integer(dplyr::coalesce(as.numeric(.data$mortality_28), 0) == 1),
    invasivevent_free_days_28_approx = dplyr::if_else(
      .data$mortality_28_for_free_days == 1L,
      0,
      pmax(0, 28 - .data$invasivevent_days_28_approx)
    ),
    vasopressor_free_days_28_approx = dplyr::if_else(
      .data$mortality_28_for_free_days == 1L,
      0,
      pmax(0, 28 - .data$vasoactive_days_28_approx)
    ),
    rrt_free_days_28_approx = dplyr::if_else(
      .data$mortality_28_for_free_days == 1L,
      0,
      pmax(0, 28 - .data$rrt_days_28_approx)
    ),
    icu_free_days_28 = dplyr::if_else(
      .data$mortality_28_for_free_days == 1L,
      0,
      pmax(0, 28 - pmin(as.numeric(.data$los_icu_days), 28))
    ),
    day3_preexisting_invasivevent = as.integer(!is.na(.data$invasivevent_first_offset) &
                                                 .data$invasivevent_first_offset <= 4320),
    day3_new_invasivevent = as.integer(!is.na(.data$invasivevent_first_offset) &
                                         .data$invasivevent_first_offset > 4320),
    day3_preexisting_septic_shock = as.integer(!is.na(.data$septic_shock_minutes) &
                                                 as.numeric(.data$septic_shock_minutes) <= 4320),
    day3_new_septic_shock = as.integer(!is.na(.data$septic_shock_minutes) &
                                         as.numeric(.data$septic_shock_minutes) > 4320),
    day3_preexisting_aki = as.integer(!is.na(.data$aki_hr) & as.numeric(.data$aki_hr) <= 72),
    day3_new_aki = as.integer(!is.na(.data$aki_hr) & as.numeric(.data$aki_hr) > 72),
    day3_preexisting_rrt = as.integer(!is.na(.data$rrt_first_offset) & .data$rrt_first_offset <= 4320),
    day3_new_rrt = as.integer(!is.na(.data$rrt_first_offset) & .data$rrt_first_offset > 4320)
  )

if (nrow(enhanced) != nrow(cohort)) {
  stop("Enhanced eICU table row count changed unexpectedly.")
}

infection_diagnosis <- DBI::dbGetQuery(con, "
  select
    d.patientunitstayid,
    'diagnosis' as evidence_source,
    d.diagnosisoffset as evidence_offset,
    d.diagnosisstring as evidence_text,
    d.icd9code as evidence_code,
    d.diagnosispriority as evidence_detail
  from public.diagnosis d
  inner join tmp_eicu_external_cohort c using (patientunitstayid)
  where lower(coalesce(d.diagnosisstring, '')) ~ '(pneumonia|pulmonary|respiratory|lung|urinary|uti|kidney|renal|abdominal|abdomen|biliary|gastro|periton|sepsis|septic|bacteremia|bloodstream|wound|skin|soft tissue|catheter|meningitis|cns)'
     or lower(coalesce(d.icd9code, '')) ~ '^(480|481|482|483|484|485|486|590|599|540|541|542|567|038|99591|99592|9966|320|322)'
")

infection_micro <- DBI::dbGetQuery(con, "
  select
    m.patientunitstayid,
    'microlab' as evidence_source,
    m.culturetakenoffset as evidence_offset,
    concat_ws(' | ', m.culturesite, m.organism) as evidence_text,
    m.antibiotic as evidence_code,
    m.sensitivitylevel as evidence_detail
  from public.microlab m
  inner join tmp_eicu_external_cohort c using (patientunitstayid)
")

infection_treatment <- DBI::dbGetQuery(con, "
  select
    t.patientunitstayid,
    'treatment' as evidence_source,
    t.treatmentoffset as evidence_offset,
    t.treatmentstring as evidence_text,
    null::varchar as evidence_code,
    null::varchar as evidence_detail
  from public.treatment t
  inner join tmp_eicu_external_cohort c using (patientunitstayid)
  where lower(t.treatmentstring) ~ '(pneumonia|sepsis|septic|infection|infectious|urinary|uti|abdominal|biliary|wound|skin|catheter|meningitis|bacteremia)'
")

infection_medication <- DBI::dbGetQuery(con, "
  select
    m.patientunitstayid,
    'medication' as evidence_source,
    m.drugstartoffset as evidence_offset,
    m.drugname as evidence_text,
    m.drughiclseqno::varchar as evidence_code,
    m.dosage as evidence_detail
  from public.medication m
  inner join tmp_eicu_external_cohort c using (patientunitstayid)
  where lower(m.drugname) ~ '(cef|cillin|penem|vanco|vancomycin|zosyn|piperacillin|tazobactam|meropenem|imipenem|cefepime|ceftriaxone|levofloxacin|ciprofloxacin|azithromycin|metronidazole|linezolid|daptomycin|gentamicin|tobramycin|amikacin|fluconazole|micafungin)'
")

infection_evidence <- dplyr::bind_rows(
  infection_diagnosis,
  infection_micro,
  infection_treatment,
  infection_medication
) |>
  dplyr::arrange(.data$patientunitstayid, .data$evidence_source, .data$evidence_offset)

out_enhanced_csv <- file.path(processed_dir, "eicu_external_validation_enhanced.csv")
out_enhanced_rds <- file.path(processed_dir, "eicu_external_validation_enhanced.rds")
out_infection_csv <- file.path(processed_dir, "eicu_external_infection_source_evidence.csv")
out_infection_rds <- file.path(processed_dir, "eicu_external_infection_source_evidence.rds")
out_xlsx <- file.path(processed_dir, "eicu_external_validation_enhanced.xlsx")

readr::write_csv(enhanced, out_enhanced_csv)
saveRDS(enhanced, out_enhanced_rds)
readr::write_csv(infection_evidence, out_infection_csv)
saveRDS(infection_evidence, out_infection_rds)

openxlsx::write.xlsx(
  list(
    enhanced_cohort = enhanced,
    infection_source_evidence = infection_evidence
  ),
  file = out_xlsx,
  overwrite = TRUE
)

summary_table <- data.frame(
  item = c(
    "uploaded_excel_rows",
    "uploaded_excel_unique_patientunitstayid",
    "excluded_sepsis_time_missing_or_outside_0_48h",
    "aligned_cohort_rows",
    "invasivevent_use_db",
    "vasoactive_use_db",
    "rrt_use_db",
    "day3_new_invasivevent",
    "day3_new_septic_shock",
    "day3_new_aki",
    "day3_new_rrt",
    "infection_evidence_rows"
  ),
  value = c(
    raw_n,
    raw_unique_stay_n,
    raw_n - nrow(cohort),
    nrow(enhanced),
    sum(enhanced$invasivevent_use_db == 1, na.rm = TRUE),
    sum(enhanced$vasoactive_use_db == 1, na.rm = TRUE),
    sum(enhanced$rrt_use_db == 1, na.rm = TRUE),
    sum(enhanced$day3_new_invasivevent == 1, na.rm = TRUE),
    sum(enhanced$day3_new_septic_shock == 1, na.rm = TRUE),
    sum(enhanced$day3_new_aki == 1, na.rm = TRUE),
    sum(enhanced$day3_new_rrt == 1, na.rm = TRUE),
    nrow(infection_evidence)
  )
)
readr::write_csv(summary_table, file.path(table_dir, "eicu_external_validation_enhanced_summary.csv"))

manifest <- list(
  project = "SOFA2 older sepsis",
  output_name = "eicu_external_validation_enhanced",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  input_excel = input_excel,
  cohort_alignment = list(
    base_population_from_excel = "age > 65, ICU LOS >= 2 days, adult sepsis table membership, first ICU stay per patienthealthsystemstayid",
    added_filter = "sepsis3_hr must be between 0 and 48 hours after ICU admission",
    sepsis_timing_column = "sepsis3_hr"
  ),
  added_database_sources = list(
    admission_source = "public.patient",
    invasive_ventilation = "public.respiratorycare",
    vasoactive_therapy = "public.infusiondrug",
    rrt = "public.intakeoutput + public.treatment + public.apacheapsvar",
    infection_source_evidence = "public.diagnosis + public.microlab + public.treatment + public.medication"
  ),
  notes = list(
    free_days = "eICU organ-support free days are approximate and based on ICU days with support records within the first 28 days; eICU raw tables do not provide MIMIC-style complete support episodes for all domains.",
    long_term_mortality = "eICU 90-day and 365-day mortality are not true post-discharge mortality measures."
  ),
  counts = as.list(stats::setNames(summary_table$value, summary_table$item)),
  files = list(
    enhanced_csv = list(path = out_enhanced_csv, sha256 = digest::digest(file = out_enhanced_csv, algo = "sha256")),
    enhanced_rds = list(path = out_enhanced_rds, sha256 = digest::digest(file = out_enhanced_rds, algo = "sha256")),
    infection_evidence_csv = list(path = out_infection_csv, sha256 = digest::digest(file = out_infection_csv, algo = "sha256")),
    infection_evidence_rds = list(path = out_infection_rds, sha256 = digest::digest(file = out_infection_rds, algo = "sha256")),
    xlsx = list(path = out_xlsx, sha256 = digest::digest(file = out_xlsx, algo = "sha256"))
  )
)
yaml::write_yaml(manifest, file.path(processed_dir, "eicu_external_validation_enhanced_manifest.yml"))

message("Enhanced eICU external validation data completed.")
message("Rows after 0-48h sepsis alignment: ", nrow(enhanced))
message("Infection evidence rows: ", nrow(infection_evidence))
message("Output: ", out_enhanced_csv)

