set.seed(2026)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
input_path <- file.path(project_root, "data", "processed", "eicu_external_validation_final_updated.rds")
out_rds <- file.path(project_root, "data", "processed", "eicu_external_prediction_cleaned.rds")
out_csv <- file.path(project_root, "data", "processed", "eicu_external_prediction_cleaned.csv")
out_manifest <- file.path(project_root, "data", "processed", "eicu_external_prediction_cleaned_manifest.yml")
out_table_dir <- file.path(project_root, "outputs", "internal_part3_prediction_performance", "tables")
dir.create(dirname(out_rds), recursive = TRUE, showWarnings = FALSE)
dir.create(out_table_dir, recursive = TRUE, showWarnings = FALSE)

required_packages <- c("dplyr", "missForest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

to_num <- function(x) suppressWarnings(as.numeric(x))

to_binary <- function(x) {
  if (is.numeric(x) || is.integer(x)) return(as.integer(x > 0))
  z <- tolower(trimws(as.character(x)))
  as.integer(z %in% c("1", "yes", "y", "true", "t", "male", "m"))
}

mode_value <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) == 0) return(NA)
  names(sort(table(x), decreasing = TRUE))[1]
}

simple_impute <- function(x) {
  if (is.factor(x) || is.character(x)) {
    z <- as.character(x)
    z[is.na(z) | trimws(z) == ""] <- mode_value(z)
    return(factor(z))
  }
  z <- x
  z[is.na(z)] <- stats::median(z, na.rm = TRUE)
  z
}

collapse_source <- function(x) {
  z <- tolower(trimws(enc2utf8(as.character(x))))
  out <- rep("Other/undetermined", length(z))
  out[grepl("pulmonary|lung|respir|pneumonia", z)] <- "Pulmonary"
  out[grepl("urinary|urine|uti|renal|kidney", z)] <- "Urinary"
  out[grepl("abdominal|abdomen|biliary|gastro|gi|intra|periton|intra-abdominal|hepatobiliary", z)] <- "Abdominal"
  out[grepl("bloodstream|blood stream|bacteremia|catheter", z)] <- "Bloodstream"
  out[grepl("skin|soft tissue", z)] <- "Skin/soft tissue"
  out[is.na(z) | z == ""] <- "Other/undetermined"
  factor(out, levels = c("Pulmonary", "Urinary", "Abdominal", "Bloodstream", "Skin/soft tissue", "Other/undetermined"))
}

collapse_icu_admission_source <- function(unit_source, hosp_source) {
  src <- ifelse(!is.na(unit_source) & trimws(as.character(unit_source)) != "", as.character(unit_source), as.character(hosp_source))
  z <- tolower(trimws(src))
  factor(dplyr::case_when(
    grepl("emergency", z) ~ "Emergency_department",
    grepl("operating|recovery|pacu|procedure", z) ~ "Procedure_or_OR",
    grepl("other hospital", z) ~ "Other_hospital",
    grepl("floor|direct|step-down|sdu|observation|chest pain", z) ~ "Ward_or_clinic",
    TRUE ~ "Other_unknown"
  ), levels = c("Emergency_department", "Procedure_or_OR", "Other_hospital", "Ward_or_clinic", "Other_unknown"))
}

collapse_icu_type <- function(x) {
  z <- tolower(trimws(as.character(x)))
  factor(dplyr::case_when(
    grepl("micu|med-surg", z) ~ "Medical_ICU",
    grepl("cardiac|ccu|cticu|csicu", z) ~ "Cardiovascular_ICU",
    grepl("sicu|surgical|trauma|neuro", z) ~ "Surgical_trauma_ICU",
    TRUE ~ "Other_ICU"
  ), levels = c("Medical_ICU", "Cardiovascular_ICU", "Surgical_trauma_ICU", "Other_ICU"))
}

d0 <- readRDS(input_path)
event28 <- suppressWarnings(as.integer(d0$mortality_28))
hospital_discharge_days <- to_num(d0$hospitaldischargeoffset) / 1440
unit_discharge_days <- to_num(d0$unitdischargeoffset) / 1440
event_time <- ifelse(!is.na(hospital_discharge_days), hospital_discharge_days, unit_discharge_days)

clean <- data.frame(
  cohort = "eICU",
  subject_id = d0$patientunitstayid,
  time28 = ifelse(event28 == 1, pmax(pmin(event_time, 28), 0.5), 28.001),
  event28 = event28,
  sofa = to_num(d0$sofa_dynamic_24h_max),
  sofa2 = to_num(d0$sofa2_dynamic_24h_max),
  age = to_num(d0$age),
  male = to_binary(d0$gender),
  charlson = to_num(d0$charlson),
  infection_source = collapse_source(d0$infection_site_collapsed_final_eicu),
  sepsis_onset_h = if ("sepsis3_hr_for_window" %in% names(d0)) to_num(d0$sepsis3_hr_for_window) else to_num(d0$sepsis3_hr),
  icu_admission_source = collapse_icu_admission_source(d0$unitadmitsource, d0$hospitaladmitsource),
  icu_type = collapse_icu_type(d0$unittype),
  lactate = to_num(d0$lactate_first)
)

id_outcome_exposure <- c("cohort", "subject_id", "time28", "event28", "sofa", "sofa2")
candidate_covariates <- c("age", "male", "charlson", "infection_source", "sepsis_onset_h", "icu_admission_source", "icu_type", "lactate")

missing_rate <- vapply(candidate_covariates, function(v) {
  x <- clean[[v]]
  if (is.factor(x) || is.character(x)) mean(is.na(x) | trimws(as.character(x)) == "") else mean(is.na(x))
}, numeric(1))

decisions <- data.frame(
  variable = candidate_covariates,
  missing_rate = as.numeric(missing_rate),
  action = NA_character_,
  reason = NA_character_,
  stringsAsFactors = FALSE
)

drop_vars <- names(missing_rate)[missing_rate > 0.30]
simple_vars <- names(missing_rate)[missing_rate > 0 & missing_rate < 0.05]
missforest_vars <- names(missing_rate)[missing_rate >= 0.05 & missing_rate <= 0.30]
complete_vars <- names(missing_rate)[missing_rate == 0]

decisions$action[decisions$variable %in% complete_vars] <- "keep_complete"
decisions$reason[decisions$variable %in% complete_vars] <- "No missing values after derivation."
decisions$action[decisions$variable %in% simple_vars] <- "simple_imputation"
decisions$reason[decisions$variable %in% simple_vars] <- "Missing rate <5%; median for continuous and mode for categorical/binary variables."
decisions$action[decisions$variable %in% missforest_vars] <- "missForest_imputation"
decisions$reason[decisions$variable %in% missforest_vars] <- "Missing rate 5%-30%; imputed with missForest, seed 2026."
decisions$action[decisions$variable %in% drop_vars] <- "deleted"
decisions$reason[decisions$variable %in% drop_vars] <- "Missing rate >30%; excluded from formal external validation models."

for (v in simple_vars) {
  clean[[v]] <- simple_impute(clean[[v]])
}

if (length(missforest_vars) > 0) {
  impute_vars <- setdiff(candidate_covariates, drop_vars)
  impute_data <- clean[, impute_vars, drop = FALSE]
  for (v in names(impute_data)) {
    if (is.character(impute_data[[v]])) impute_data[[v]] <- factor(impute_data[[v]])
  }
  mf <- missForest::missForest(impute_data, maxiter = 5, ntree = 20, variablewise = TRUE, verbose = FALSE)
  clean[, impute_vars] <- mf$ximp
}

retained_covariates <- setdiff(candidate_covariates, drop_vars)
clean_final <- clean[, c(id_outcome_exposure, retained_covariates), drop = FALSE]
clean_final <- clean_final[complete.cases(clean_final[, c("time28", "event28", "sofa", "sofa2"), drop = FALSE]), , drop = FALSE]

utils::write.csv(decisions, file.path(out_table_dir, "TableS_eICU_cleaning_imputation_decisions.csv"), row.names = FALSE)
utils::write.csv(clean_final, out_csv, row.names = FALSE, fileEncoding = "UTF-8")
saveRDS(clean_final, out_rds)

manifest <- list(
  project = "SOFA2 older sepsis",
  analysis = "eICU external validation cleaning and imputation aligned with MIMIC principles",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  input = input_path,
  output_rds = out_rds,
  output_csv = out_csv,
  source_rows = nrow(d0),
  output_rows = nrow(clean_final),
  seed = 2026,
  rule = list(
    exposure_outcome = "SOFA, SOFA-2, time28, and event28 are not imputed.",
    delete = "Candidate covariates with missing rate >30% are deleted.",
    simple = "Candidate covariates with missing rate <5% are median/mode imputed.",
    missForest = "Candidate covariates with missing rate 5%-30% are missForest-imputed."
  ),
  deleted_covariates = drop_vars,
  simple_imputed_covariates = simple_vars,
  missForest_imputed_covariates = missforest_vars,
  retained_covariates = retained_covariates
)
yaml::write_yaml(manifest, out_manifest)

message("eICU cleaning completed.")
message("Output: ", out_rds)

