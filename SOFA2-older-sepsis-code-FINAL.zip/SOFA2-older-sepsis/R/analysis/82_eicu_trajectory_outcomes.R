set.seed(2026)

project_root <- Sys.getenv("SOFA2_PROJECT_ROOT", unset = ".")
project_root <- gsub("\\\\", "/", project_root)
project_root <- normalizePath(project_root, winslash = "/", mustWork = TRUE)
out_dir <- Sys.getenv(
  "SOFA2_TABLES5_OUT_DIR",
  unset = file.path(project_root, "outputs", "manuscript_figure7_eicu_external_validation")
)
out_dir <- gsub("\\\\", "/", out_dir)
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

trajectory_helper <- Sys.getenv(
  "SOFA2_TRAJECTORY_HELPER",
  unset = file.path(project_root, "R", "analysis", "80_eicu_trajectory_assignment.R")
)
source(trajectory_helper)

required <- c("dplyr", "officer", "flextable", "survival", "broom")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) stop("Missing packages: ", paste(missing, collapse = ", "))

fmt_p <- function(p) ifelse(is.na(p), "", ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
fmt_pct <- function(x) sprintf("%.1f", 100 * x)
fmt_int <- function(x) formatC(as.integer(round(x)), format = "d", big.mark = ",")
fmt_ci <- function(est, lo, hi) sprintf("%.2f (%.2f-%.2f)", est, lo, hi)
to_num <- function(x) suppressWarnings(as.numeric(as.character(x)))
to_bin <- function(x) {
  if (is.null(x)) return(rep(NA_integer_, 0))
  if (is.numeric(x) || is.integer(x)) return(as.integer(x > 0))
  z <- tolower(trimws(as.character(x)))
  out <- rep(NA_integer_, length(z))
  out[z %in% c("1", "yes", "y", "true", "t")] <- 1L
  out[z %in% c("0", "no", "n", "false", "f")] <- 0L
  out
}
to_male <- function(x) {
  if (is.numeric(x) || is.integer(x)) return(as.integer(x > 0))
  z <- tolower(trimws(as.character(x)))
  out <- rep(NA_integer_, length(z))
  out[z %in% c("male", "m", "1", "yes", "y", "true", "t")] <- 1L
  out[z %in% c("female", "f", "0", "no", "n", "false")] <- 0L
  out
}
fmt_event <- function(x) {
  ok <- !is.na(x)
  if (!sum(ok)) return("")
  n <- sum(x[ok] == 1)
  paste0(fmt_int(n), " (", fmt_pct(n / sum(ok)), ")")
}
fmt_eligible <- function(x) {
  ok <- !is.na(x)
  if (!sum(ok)) return("")
  n <- sum(x[ok] == 1)
  paste0(fmt_int(n), "/", fmt_int(sum(ok)), " (", fmt_pct(n / sum(ok)), ")")
}
fmt_cont <- function(x) {
  x <- to_num(x)
  ok <- !is.na(x)
  if (!sum(ok)) return("")
  q <- stats::quantile(x[ok], probs = c(0.25, 0.50, 0.75), names = FALSE, type = 2)
  sprintf("%.1f (%.1f-%.1f)", q[2], q[1], q[3])
}
p_cat <- function(x, g) {
  ok <- !is.na(x) & !is.na(g)
  if (sum(ok) < 3 || length(unique(g[ok])) < 2 || length(unique(x[ok])) < 2) return(NA_real_)
  tab <- table(droplevels(factor(x[ok])), droplevels(g[ok]))
  suppressWarnings({
    chi <- tryCatch(stats::chisq.test(tab), error = function(e) NULL)
    if (is.null(chi)) return(NA_real_)
    if (any(chi$expected < 5)) {
      tryCatch(stats::fisher.test(tab, simulate.p.value = any(dim(tab) > 2), B = 20000)$p.value, error = function(e) chi$p.value)
    } else {
      chi$p.value
    }
  })
}
p_cont <- function(x, g) {
  x <- to_num(x)
  ok <- !is.na(x) & !is.na(g)
  if (sum(ok) < 3 || length(unique(g[ok])) < 2) return(NA_real_)
  suppressWarnings(tryCatch(stats::kruskal.test(x[ok] ~ droplevels(factor(g[ok])))$p.value, error = function(e) NA_real_))
}
new_after_day3 <- function(new_var, pre_var) {
  newx <- to_bin(new_var)
  pre <- to_bin(pre_var)
  out <- newx
  out[pre == 1] <- NA_integer_
  out[is.na(out) & !(pre == 1)] <- 0L
  out
}
collapse_ethnicity <- function(x) {
  z <- toupper(trimws(as.character(x)))
  out <- rep("Other/Unknown", length(z))
  out[grepl("CAUCASIAN|WHITE", z)] <- "White"
  out[grepl("AFRICAN|BLACK", z)] <- "Black"
  out[grepl("^ASIAN$|\\bASIAN\\b", z)] <- "Asian"
  out[grepl("HISPANIC|LATINO", z)] <- "Hispanic/Latino"
  out[is.na(z) | z == "" | z %in% c("NA", "UNKNOWN", "OTHER")] <- "Other/Unknown"
  factor(out, levels = c("White", "Black", "Asian", "Hispanic/Latino", "Other/Unknown"))
}
prep_complete <- function(data, vars) {
  z <- data[, vars, drop = FALSE]
  z <- z[complete.cases(z), , drop = FALSE]
  for (nm in names(z)) if (is.factor(z[[nm]])) z[[nm]] <- droplevels(z[[nm]])
  z
}

eicu_raw <- readRDS(file.path(project_root, "data", "analysis_ready_current", "eICU_SOFA2_external_validation_master_current.rds"))

event28 <- suppressWarnings(as.integer(eicu_raw$mortality_28))
hospital_discharge_days <- to_num(eicu_raw$hospitaldischargeoffset) / 1440
unit_discharge_days <- to_num(eicu_raw$unitdischargeoffset) / 1440
event_time <- ifelse(!is.na(hospital_discharge_days), hospital_discharge_days, unit_discharge_days)
time28 <- ifelse(event28 == 1, pmax(pmin(event_time, 28), 0.5), 28.001)

mimic_model <- load_mimic_trajectory_model(file.path(
  project_root, "outputs", "internal_part4_cutoff_trajectory_subgroup_sensitivity",
  "models", "Part4_cutoff_trajectory_subgroup_sensitivity_objects.rds"
))

analysis <- data.frame(
  patientunitstayid = eicu_raw$patientunitstayid,
  time28 = time28,
  event28 = event28,
  age = to_num(eicu_raw$age),
  male = to_male(eicu_raw$gender),
  ethnicity_raw = as.character(eicu_raw$ethnicity),
  sofa2_d1 = to_num(eicu_raw$sofa2_dynamic_24h_max),
  sofa2_d2 = to_num(eicu_raw$sofa2_dynamic_48h_max),
  sofa2_d3 = to_num(eicu_raw$sofa2_dynamic_72h_max),
  icu_mort = to_bin(eicu_raw$icu_expire_flag),
  hosp_mort = to_bin(eicu_raw$hosp_mort),
  mort90 = to_bin(eicu_raw$mortality_90),
  mort365 = to_bin(eicu_raw$mortality_365),
  day3_new_invasive_vent = new_after_day3(eicu_raw$day3_new_invasivevent, eicu_raw$day3_preexisting_invasivevent),
  day3_new_septic_shock = new_after_day3(eicu_raw$day3_new_septic_shock, eicu_raw$day3_preexisting_septic_shock),
  day3_new_aki = new_after_day3(eicu_raw$day3_new_aki, eicu_raw$day3_preexisting_aki),
  day3_new_rrt = new_after_day3(eicu_raw$day3_new_rrt, eicu_raw$day3_preexisting_rrt),
  los_icu = to_num(eicu_raw$los_icu_days),
  los_hospital = to_num(eicu_raw$los_hospital_days),
  invasive_vent_free_days_28 = to_num(eicu_raw$invasivevent_free_days_28_approx),
  vasopressor_free_days_28 = to_num(eicu_raw$vasopressor_free_days_28_approx),
  rrt_free_days_28 = to_num(eicu_raw$rrt_free_days_28_approx),
  icu_free_days_28 = to_num(eicu_raw$icu_free_days_28)
)
analysis$ethnicity_group <- collapse_ethnicity(analysis$ethnicity_raw)

traj_ok <- complete.cases(analysis[, c("sofa2_d1", "sofa2_d2", "sofa2_d3")])
analysis$trajectory_class <- NA_character_
trajectory_assignment <- assign_eicu_to_mimic_trajectory(
  analysis[traj_ok, , drop = FALSE], mimic_model,
  id = analysis$patientunitstayid[traj_ok]
)
analysis$trajectory_class[traj_ok] <- as.character(trajectory_assignment$trajectory_class)
analysis$trajectory_class <- factor(analysis$trajectory_class, levels = trajectory_levels)
analysis <- analysis[!is.na(analysis$trajectory_class), , drop = FALSE]
utils::write.csv(trajectory_model_parameters(mimic_model), file.path(out_dir, "TableS5_MIMIC_trajectory_model_parameters.csv"), row.names = FALSE)
utils::write.csv(trajectory_assignment, file.path(out_dir, "TableS5_eICU_patient_trajectory_assignments.csv"), row.names = FALSE)

empty_row <- function(section) {
  data.frame(
    Outcome = section, Overall = "", `Low-stable` = "", `Moderate-stable` = "",
    `High-stable` = "", `Persistent-high/worsening` = "", `P value` = "",
    check.names = FALSE
  )
}
make_row <- function(name, var, type, report_p = TRUE) {
  x <- analysis[[var]]
  formatter <- switch(type, eligible = fmt_eligible, binary = fmt_event, continuous = fmt_cont)
  p_value <- switch(type, eligible = p_cat(x, analysis$trajectory_class), binary = p_cat(x, analysis$trajectory_class), continuous = p_cont(x, analysis$trajectory_class))
  data.frame(
    Outcome = name,
    Overall = formatter(x),
    `Low-stable` = formatter(x[analysis$trajectory_class == "Low-stable"]),
    `Moderate-stable` = formatter(x[analysis$trajectory_class == "Moderate-stable"]),
    `High-stable` = formatter(x[analysis$trajectory_class == "High-stable"]),
    `Persistent-high/worsening` = formatter(x[analysis$trajectory_class == "Persistent-high/worsening"]),
    `P value` = if (report_p) fmt_p(p_value) else "-",
    check.names = FALSE
  )
}

table_s5 <- dplyr::bind_rows(
  empty_row("Mortality outcomes"),
  make_row("In-hospital death within 28 days after ICU admission, n (%)", "event28", "binary"),
  make_row("ICU mortality, n (%)", "icu_mort", "binary"),
  make_row("In-hospital mortality, n (%)", "hosp_mort", "binary"),
  empty_row("Incident outcomes after day 3"),
  make_row("New AKI after day 3, n/N eligible (%)", "day3_new_aki", "eligible"),
  make_row("New RRT after day 3, n/N eligible (%)", "day3_new_rrt", "eligible"),
  empty_row("Length of stay and organ-support-free days"),
  make_row("ICU length of stay, days, median (IQR)", "los_icu", "continuous"),
  make_row("Hospital length of stay, days, median (IQR)", "los_hospital", "continuous"),
  make_row("28-day vasopressor-free days, median (IQR)", "vasopressor_free_days_28", "continuous"),
  make_row("28-day RRT-free days, median (IQR)", "rrt_free_days_28", "continuous"),
  make_row("28-day ICU-free days, median (IQR)", "icu_free_days_28", "continuous")
)
utils::write.csv(table_s5, file.path(out_dir, "TableS5_eICU_outcomes_by_SOFA2_trajectory.csv"), row.names = FALSE, fileEncoding = "UTF-8")

cox_data <- prep_complete(analysis, c("time28", "event28", "trajectory_class", "age", "male", "ethnicity_group"))
cox_data$trajectory_class <- stats::relevel(cox_data$trajectory_class, ref = "Low-stable")
fit_crude <- survival::coxph(survival::Surv(time28, event28) ~ trajectory_class, data = cox_data, ties = "efron")
fit_adj <- survival::coxph(survival::Surv(time28, event28) ~ trajectory_class + age + male + ethnicity_group, data = cox_data, ties = "efron")
tidy_model <- function(fit, model) {
  broom::tidy(fit, exponentiate = TRUE, conf.int = TRUE) |>
    dplyr::filter(grepl("^trajectory_class", term)) |>
    dplyr::transmute(
      Analysis = "eICU SOFA2 trajectory group",
      Model = model,
      Reference = "Low-stable",
      `Trajectory group` = sub("^trajectory_class", "", term),
      N = nrow(cox_data),
      Events = sum(cox_data$event28 == 1),
      HR = estimate,
      `Lower 95% CI` = conf.low,
      `Upper 95% CI` = conf.high,
      `HR (95% CI)` = fmt_ci(estimate, conf.low, conf.high),
      `P value` = fmt_p(p.value)
    )
}
cox_results <- dplyr::bind_rows(
  tidy_model(fit_crude, "Crude"),
  tidy_model(fit_adj, "Adjusted for age, sex, and ethnicity/race")
)
utils::write.csv(cox_results, file.path(out_dir, "TableS5_eICU_Cox_SOFA2_trajectory_groups.csv"), row.names = FALSE, fileEncoding = "UTF-8")

section_rows <- which(table_s5$Overall == "" & table_s5$`P value` == "")
ft <- flextable::flextable(table_s5)
ft <- flextable::theme_booktabs(ft)
ft <- flextable::font(ft, fontname = "Arial", part = "all")
ft <- flextable::fontsize(ft, size = 8, part = "all")
ft <- flextable::fontsize(ft, size = 8.5, part = "header")
ft <- flextable::bold(ft, part = "header")
ft <- flextable::bg(ft, bg = "#F2F4F7", part = "header")
ft <- flextable::align(ft, align = "center", part = "header")
ft <- flextable::align(ft, j = 1, align = "left", part = "body")
ft <- flextable::align(ft, j = 2:ncol(table_s5), align = "center", part = "body")
ft <- flextable::padding(ft, padding.top = 2, padding.bottom = 2, padding.left = 3, padding.right = 3, part = "all")
for (i in section_rows) {
  ft <- flextable::merge_at(ft, i = i, j = 1:ncol(table_s5), part = "body")
  ft <- flextable::bold(ft, i = i, bold = TRUE, part = "body")
  ft <- flextable::italic(ft, i = i, italic = TRUE, part = "body")
  ft <- flextable::bg(ft, i = i, bg = "#E8EEF5", part = "body")
  ft <- flextable::align(ft, i = i, align = "left", part = "body")
}
ft <- flextable::set_table_properties(ft, layout = "fixed", width = 1)
ft <- flextable::width(ft, j = 1, width = 2.25)
ft <- flextable::width(ft, j = 2, width = 1.15)
ft <- flextable::width(ft, j = 3, width = 1.15)
ft <- flextable::width(ft, j = 4, width = 1.20)
ft <- flextable::width(ft, j = 5, width = 1.20)
ft <- flextable::width(ft, j = 6, width = 1.55)
ft <- flextable::width(ft, j = 7, width = 0.70)
ft <- flextable::autofit(ft)

doc <- officer::read_docx()
doc <- officer::body_add_par(doc, "Table S5. Clinical outcomes according to SOFA2 trajectory group in the eICU cohort", style = "heading 1")
doc <- officer::body_add_par(
  doc,
  "Values are presented as n (%), n/N eligible (%), or median (IQR). Day-specific SOFA2 values were standardized using the MIMIC training means and standard deviations; eICU patients were assigned to the nearest frozen MIMIC K-means center by squared Euclidean distance, without model refitting. P values were calculated using chi-square/Fisher exact tests for categorical variables and Kruskal-Wallis tests for continuous variables.",
  style = "Normal"
)
doc <- flextable::body_add_flextable(doc, ft)
doc <- officer::body_add_par(
  doc,
  "Abbreviations: AKI, acute kidney injury; eICU, electronic Intensive Care Unit Collaborative Research Database; ICU, intensive care unit; IQR, interquartile range; RRT, renal replacement therapy; SOFA2, Sequential Organ Failure Assessment 2. eICU 90-day and 365-day mortality are not true post-discharge mortality measures, and organ-support-free days are approximate eICU-derived measures.",
  style = "Normal"
)
doc <- officer::body_end_section_landscape(doc)
print(doc, target = file.path(out_dir, "TableS5_eICU_outcomes_by_SOFA2_trajectory.docx"))

traj_summary <- analysis |>
  dplyr::group_by(trajectory_class) |>
  dplyr::summarise(
    n = dplyr::n(),
    deaths_28d = sum(event28 == 1),
    mortality_28d = deaths_28d / n,
    mean_day1 = mean(sofa2_d1),
    mean_day2 = mean(sofa2_d2),
    mean_day3 = mean(sofa2_d3),
    .groups = "drop"
  )
utils::write.csv(traj_summary, file.path(out_dir, "TableS5_eICU_trajectory_group_summary.csv"), row.names = FALSE, fileEncoding = "UTF-8")

qc <- data.frame(
  item = c(
    "source_data", "source_rows", "trajectory_analysis_rows", "trajectory_missing_day1_3_excluded",
    "death_28d_events", "cox_n", "cox_events", "cox_missing_age_sex_ethnicity_excluded",
    "ethnicity_levels", "missing_los_icu", "missing_los_hospital", "missing_ventilator_free_days_28",
    "missing_vasopressor_free_days_28", "missing_rrt_free_days_28", "missing_icu_free_days_28",
    "trajectory_assignment_method"
  ),
  value = c(
    file.path(project_root, "data", "analysis_ready_current", "eICU_SOFA2_external_validation_master_current.rds"),
    nrow(eicu_raw), nrow(analysis), nrow(eicu_raw) - nrow(analysis), sum(analysis$event28 == 1),
    nrow(cox_data), sum(cox_data$event28 == 1), nrow(analysis) - nrow(cox_data),
    paste(levels(droplevels(analysis$ethnicity_group)), collapse = "; "),
    sum(is.na(analysis$los_icu)), sum(is.na(analysis$los_hospital)), sum(is.na(analysis$invasive_vent_free_days_28)),
    sum(is.na(analysis$vasopressor_free_days_28)), sum(is.na(analysis$rrt_free_days_28)), sum(is.na(analysis$icu_free_days_28)),
    "Nearest frozen MIMIC K-means center in MIMIC-standardized day1-3 SOFA2 space; squared Euclidean distance; no eICU refitting"
  )
)
utils::write.csv(qc, file.path(out_dir, "TableS5_eICU_trajectory_QC.csv"), row.names = FALSE, fileEncoding = "UTF-8")

cat("Outputs written to:", out_dir, "\n")


