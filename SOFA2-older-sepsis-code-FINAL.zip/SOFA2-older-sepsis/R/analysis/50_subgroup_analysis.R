suppressPackageStartupMessages({
  library(survival)
  library(dplyr)
  library(ggplot2)
  library(readr)
  library(stringr)
})

root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
data_file <- file.path(root, "data/analysis_ready_current/MIMIC_SOFA2_analysis_master_current.rds")
out_dir <- file.path(root, "outputs", "manuscript_subgroup_mimic")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

d0 <- readRDS(data_file)

exposure_var <- "sofa2_dynamic24_max"
status_var <- "icu_28d_death"
time_var <- "death_days_from_icu"
malnutrition_var <- names(d0)[116]

fmt_p <- function(p) {
  ifelse(is.na(p), NA_character_, ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
}

collapse_binary <- function(x, yes_label = "Yes", no_label = "No") {
  z <- as.character(x)
  z_low <- tolower(trimws(z))
  out <- ifelse(is.na(x), NA_character_,
                ifelse(z_low %in% c("1", "yes", "true", "y", "present"), yes_label,
                       ifelse(z_low %in% c("0", "no", "false", "n", "absent"), no_label, z)))
  factor(out, levels = c(no_label, yes_label))
}

collapse_infection <- function(x) {
  z <- tolower(as.character(x))
  out <- ifelse(is.na(x) | trimws(z) == "", "Other/unknown",
                ifelse(str_detect(z, "pulmonary|pneumonia|lung|resp|\\u80ba\\u90e8"), "Pulmonary",
                       ifelse(str_detect(z, "urinary|uti|renal|kidney|\\u6ccc\\u5c3f"), "Urinary",
                              ifelse(str_detect(z, "abdominal|abdomen|intra|gastro|biliary|periton|\\u8179\\u8154|\\u80c6\\u9053|\\u80c3\\u80a0"), "Abdominal", "Other/unknown"))))
  factor(out, levels = c("Pulmonary", "Urinary", "Abdominal", "Other/unknown"))
}

safe_tertile <- function(x, prefix) {
  qs <- as.numeric(quantile(x, probs = c(1 / 3, 2 / 3), na.rm = TRUE, type = 2))
  qs <- unique(qs)
  if (length(qs) < 2) {
    return(factor(ifelse(is.na(x), NA_character_, prefix)))
  }
  cut(x,
      breaks = c(-Inf, qs[1], qs[2], Inf),
      include.lowest = TRUE,
      right = TRUE,
      labels = c(
        sprintf("%s T1 (<=%.0f)", prefix, qs[1]),
        sprintf("%s T2 (%.0f-%.0f)", prefix, qs[1] + 1, qs[2]),
        sprintf("%s T3 (>%.0f)", prefix, qs[2])
      ))
}

safe_median_split <- function(x, prefix) {
  med <- as.numeric(median(x, na.rm = TRUE))
  low_label <- sprintf("<= median (<=%.1f h)", med)
  high_label <- sprintf("> median (>%.1f h)", med)
  factor(ifelse(is.na(x), NA_character_,
                ifelse(x <= med,
                       low_label,
                       high_label)),
         levels = c(low_label, high_label))
}

parse_factor <- function(x) {
  out <- as.character(x)
  out[is.na(out) | trimws(out) == ""] <- NA_character_
  factor(out)
}

collapse_icu_type <- function(x) {
  z <- as.character(x)
  out <- ifelse(is.na(z) | trimws(z) == "", NA_character_,
                ifelse(str_detect(z, "Medical Intensive|Medical/Surgical|Coronary Care"), "Medical ICU",
                       ifelse(str_detect(z, "Surgical Intensive|Trauma SICU|Cardiac Vascular"), "Surgical ICU",
                              "Other ICU")))
  factor(out, levels = c("Medical ICU", "Surgical ICU", "Other ICU"))
}

d <- d0 %>%
  mutate(
    sofa2 = .data[[exposure_var]],
    status = as.integer(.data[[status_var]] == 1),
    time_28 = ifelse(status == 1, pmin(.data[[time_var]], 28), 28),
    age_group = cut(age,
                    breaks = c(65, 74, 84, Inf),
                    labels = c("66-74 years", "75-84 years", ">=85 years"),
                    right = TRUE,
                    include.lowest = TRUE),
    sex_group = factor(as.character(gender)),
    malnutrition_group = collapse_binary(.data[[malnutrition_var]]),
    dementia_group = collapse_binary(dementia),
    cci_tertile = safe_tertile(charlson, "CCI"),
    infection_group = collapse_infection(infection_site_main_enriched),
    sepsis_offset_hours = as.numeric(difftime(sepsis_time, icu_intime, units = "hours")),
    sepsis_timing_median = safe_median_split(sepsis_offset_hours, "Sepsis timing"),
    icu_type_group = collapse_icu_type(careunit),
    lactate_group = factor(ifelse(is.na(lactate_first), NA_character_,
                                  ifelse(lactate_first <= 2, "<=2 mmol/L", ">2 mmol/L")),
                           levels = c("<=2 mmol/L", ">2 mmol/L")),
    race_group = parse_factor(race),
    admission_source = parse_factor(admission_location),
    infection_cov = collapse_infection(infection_site_main_enriched),
    icu_type_cov = collapse_icu_type(careunit)
  )

qc <- tibble(
  item = c(
    "Source MIMIC master N",
    "SOFA2 missing",
    "ICU 28-day death missing",
    "Death time missing among 28-day deaths",
    "Follow-up time <=0",
    "Complete-case N for full adjusted subgroup model",
    "Complete-case ICU 28-day deaths"
  ),
  value = c(
    nrow(d),
    sum(is.na(d$sofa2)),
    sum(is.na(d$status)),
    sum(d$status == 1 & is.na(d$time_28), na.rm = TRUE),
    sum(d$time_28 <= 0, na.rm = TRUE),
    NA_integer_,
    NA_integer_
  )
)

base_covariates <- c("age", "gender", "charlson", "infection_cov",
                     "sepsis_offset_hours", "admission_source", "icu_type_cov",
                     "lactate_first")

subgroups <- list(
  age_group = list(label = "Age", omit = "age"),
  sex_group = list(label = "Sex", omit = "gender"),
  malnutrition_group = list(label = "Malnutrition", omit = character(0)),
  dementia_group = list(label = "Dementia", omit = character(0)),
  cci_tertile = list(label = "Charlson Comorbidity Index", omit = "charlson"),
  infection_group = list(label = "Infection source", omit = "infection_cov"),
  sepsis_timing_median = list(label = "Sepsis timing\nrelative to ICU admission", omit = "sepsis_offset_hours"),
  icu_type_group = list(label = "ICU type", omit = "icu_type_cov"),
  lactate_group = list(label = "Baseline lactate", omit = "lactate_first")
)

make_formula <- function(covs) {
  as.formula(paste("Surv(time_28, status) ~ sofa2",
                   if (length(covs) > 0) paste("+", paste(covs, collapse = " + ")) else ""))
}

make_interaction_formula <- function(sg, covs) {
  as.formula(paste("Surv(time_28, status) ~ sofa2 *", sg,
                   if (length(covs) > 0) paste("+", paste(covs, collapse = " + ")) else ""))
}

run_one_level <- function(dat, subgroup_var, subgroup_label, level_label, covs) {
  dd <- dat %>% filter(.data[[subgroup_var]] == level_label)
  vars <- unique(c("time_28", "status", "sofa2", covs))
  cc <- complete.cases(dd[, vars, drop = FALSE]) & dd$time_28 > 0
  dd_cc <- dd[cc, , drop = FALSE]
  n <- nrow(dd_cc)
  events <- sum(dd_cc$status == 1, na.rm = TRUE)
  if (n < 50 || events < 10 || length(unique(dd_cc$sofa2)) < 2) {
    return(tibble(
      subgroup = subgroup_label, level = as.character(level_label), n = n, events = events,
      hr = NA_real_, ci_low = NA_real_, ci_high = NA_real_, p_value = NA_real_,
      note = "Not estimated: sparse data"
    ))
  }
  fit <- coxph(make_formula(covs), data = dd_cc, ties = "efron")
  co <- summary(fit)$coefficients
  ci <- summary(fit)$conf.int
  tibble(
    subgroup = subgroup_label,
    level = as.character(level_label),
    n = n,
    events = events,
    hr = ci["sofa2", "exp(coef)"],
    ci_low = ci["sofa2", "lower .95"],
    ci_high = ci["sofa2", "upper .95"],
    p_value = co["sofa2", "Pr(>|z|)"],
    note = ""
  )
}

run_interaction <- function(dat, subgroup_var, covs) {
  vars <- unique(c("time_28", "status", "sofa2", subgroup_var, covs))
  dd <- dat[complete.cases(dat[, vars, drop = FALSE]) & dat$time_28 > 0, , drop = FALSE]
  dd[[subgroup_var]] <- droplevels(factor(dd[[subgroup_var]]))
  if (nlevels(dd[[subgroup_var]]) < 2) return(NA_real_)
  fit0 <- coxph(make_formula(c(covs, subgroup_var)), data = dd, ties = "efron")
  fit1 <- coxph(make_interaction_formula(subgroup_var, covs), data = dd, ties = "efron")
  an <- anova(fit0, fit1, test = "LRT")
  as.numeric(an$`Pr(>|Chi|)`[2])
}

results <- list()
interactions <- list()
counts <- list()

for (sg in names(subgroups)) {
  info <- subgroups[[sg]]
  covs <- setdiff(base_covariates, info$omit)
  lvls <- levels(droplevels(factor(d[[sg]])))
  counts[[sg]] <- d %>%
    mutate(level = as.character(.data[[sg]])) %>%
    group_by(level) %>%
    summarise(
      subgroup = info$label,
      source_n = n(),
      source_events = sum(status == 1, na.rm = TRUE),
      missing_subgroup = sum(is.na(level)),
      .groups = "drop"
    ) %>%
    select(subgroup, level, source_n, source_events, missing_subgroup)
  results[[sg]] <- bind_rows(lapply(lvls, function(lvl) run_one_level(d, sg, info$label, lvl, covs)))
  interactions[[sg]] <- tibble(
    subgroup = info$label,
    interaction_p = run_interaction(d, sg, covs)
  )
}

interaction_table <- bind_rows(interactions) %>%
  mutate(
    interaction_q = p.adjust(interaction_p, method = "BH"),
    interaction_p_formatted = fmt_p(interaction_p),
    interaction_q_formatted = fmt_p(interaction_q)
  )
write_csv(interaction_table, file.path(out_dir, "TableS12_prespecified_interactions_BH_FDR.csv"))

subgroup_results <- bind_rows(results) %>%
  left_join(interaction_table, by = "subgroup") %>%
  mutate(
    HR_95CI = ifelse(is.na(hr), NA_character_, sprintf("%.2f (%.2f-%.2f)", hr, ci_low, ci_high)),
    HR_95CI_to = ifelse(is.na(hr), NA_character_, sprintf("%.2f (%.2f to %.2f)", hr, ci_low, ci_high)),
    p_value_formatted = fmt_p(p_value)
  )

subgroup_counts <- bind_rows(counts)

full_vars <- unique(c("time_28", "status", "sofa2", base_covariates))
full_cc <- complete.cases(d[, full_vars, drop = FALSE]) & d$time_28 > 0
qc$value[qc$item == "Complete-case N for full adjusted subgroup model"] <- sum(full_cc)
qc$value[qc$item == "Complete-case ICU 28-day deaths"] <- sum(d$status[full_cc] == 1)

write_csv(qc, file.path(out_dir, "MIMIC_SOFA2_subgroup_QC.csv"))
write_csv(subgroup_counts, file.path(out_dir, "MIMIC_SOFA2_subgroup_counts.csv"))
write_csv(subgroup_results, file.path(out_dir, "TableS_MIMIC_SOFA2_subgroup_Cox_interaction.csv"))

overall_fit <- coxph(make_formula(base_covariates), data = d[full_cc, , drop = FALSE], ties = "efron")
overall_summary <- summary(overall_fit)
overall_row <- tibble(
  row_type = "data",
  subgroup = "Overall",
  level = "Overall",
  n = sum(full_cc),
  events = sum(d$status[full_cc] == 1),
  percent = 100,
  hr = overall_summary$conf.int["sofa2", "exp(coef)"],
  ci_low = overall_summary$conf.int["sofa2", "lower .95"],
  ci_high = overall_summary$conf.int["sofa2", "upper .95"],
  HR_95CI_to = sprintf("%.2f (%.2f to %.2f)",
                       overall_summary$conf.int["sofa2", "exp(coef)"],
                       overall_summary$conf.int["sofa2", "lower .95"],
                       overall_summary$conf.int["sofa2", "upper .95"]),
  p_value_formatted = fmt_p(overall_summary$coefficients["sofa2", "Pr(>|z|)"]),
  interaction_p_formatted = NA_character_
)

display_rows <- list(overall_row)
for (sg in unique(subgroup_results$subgroup)) {
  this <- subgroup_results %>% filter(subgroup == sg)
  display_rows[[length(display_rows) + 1]] <- tibble(
    row_type = "header", subgroup = sg, level = sg, n = NA_integer_, events = NA_integer_,
    percent = NA_real_, hr = NA_real_, ci_low = NA_real_, ci_high = NA_real_,
    HR_95CI_to = NA_character_, p_value_formatted = NA_character_,
    interaction_p_formatted = first(this$interaction_p_formatted)
  )
  display_rows[[length(display_rows) + 1]] <- this %>%
    mutate(row_type = "data", percent = 100 * n / nrow(d)) %>%
    select(row_type, subgroup, level, n, events, percent, hr, ci_low, ci_high,
           HR_95CI_to, p_value_formatted, interaction_p_formatted) %>%
    mutate(interaction_p_formatted = NA_character_)
}

plot_df <- bind_rows(display_rows) %>%
  mutate(
    row_id = rev(seq_len(n())),
    is_shaded = row_number() %% 2 == 1 | row_type == "header",
    label = ifelse(row_type == "header", subgroup, paste0("  ", level)),
    label = ifelse(subgroup == "Overall" & row_type == "data", "Overall", label),
    count_text = ifelse(row_type == "data", as.character(n), ""),
    percent_text = ifelse(row_type == "data", sprintf("%.1f", percent), ""),
    p_text = ifelse(row_type == "data", p_value_formatted, ""),
    pint_text = ifelse(row_type == "header", interaction_p_formatted, "")
  )

forest_min <- 0.8
forest_max <- 2.0
forest_left <- 0.56
forest_right <- 0.75
map_x <- function(x) forest_left + (log10(x) - log10(forest_min)) /
  (log10(forest_max) - log10(forest_min)) * (forest_right - forest_left)
plot_df <- plot_df %>%
  mutate(
    x_hr = map_x(hr),
    x_low = map_x(pmax(ci_low, forest_min)),
    x_high = map_x(pmin(ci_high, forest_max))
  )
tick_df <- tibble(
  tick = c(0.8, 1.0, 1.2, 1.5, 2.0),
  x = map_x(tick)
)

shade_df <- plot_df %>% filter(is_shaded)

p <- ggplot(plot_df, aes(y = row_id)) +
  geom_rect(data = shade_df, aes(xmin = 0, xmax = 1, ymin = row_id - 0.5, ymax = row_id + 0.5),
            inherit.aes = FALSE, fill = "#EEF3F1", color = NA) +
  annotate("segment", x = map_x(1), xend = map_x(1), y = 0.45, yend = max(plot_df$row_id) + 0.55,
           linetype = "dashed", linewidth = 0.35, color = "grey45") +
  geom_segment(data = plot_df %>% filter(row_type == "data" & !is.na(hr)),
               aes(x = x_low, xend = x_high, yend = row_id),
               linewidth = 0.45, color = "black") +
  geom_point(data = plot_df %>% filter(row_type == "data" & !is.na(hr)),
             aes(x = x_hr), shape = 15, size = 1.5, color = "black") +
  geom_text(aes(x = 0.01, label = label, fontface = ifelse(row_type == "header", "bold", "plain")),
            hjust = 0, size = 2.75, family = "sans") +
  geom_text(aes(x = 0.20, label = count_text), hjust = 0, size = 2.65, family = "sans") +
  geom_text(aes(x = 0.28, label = percent_text), hjust = 0, size = 2.65, family = "sans") +
  geom_text(aes(x = 0.39, label = HR_95CI_to), hjust = 0, size = 2.65, family = "sans", na.rm = TRUE) +
  geom_text(aes(x = 0.78, label = p_text), hjust = 0, size = 2.65, family = "sans") +
  geom_text(aes(x = 0.88, label = pint_text), hjust = 0, size = 2.65, family = "sans", fontface = "bold") +
  annotate("text", x = 0.01, y = max(plot_df$row_id) + 0.75, label = "Variable", hjust = 0, size = 3.0, fontface = "bold", family = "sans") +
  annotate("text", x = 0.20, y = max(plot_df$row_id) + 0.75, label = "Count", hjust = 0, size = 3.0, fontface = "bold", family = "sans") +
  annotate("text", x = 0.28, y = max(plot_df$row_id) + 0.75, label = "Percent", hjust = 0, size = 3.0, fontface = "bold", family = "sans") +
  annotate("text", x = 0.39, y = max(plot_df$row_id) + 0.75, label = "HR (95% CI)", hjust = 0, size = 3.0, fontface = "bold", family = "sans") +
  annotate("text", x = 0.78, y = max(plot_df$row_id) + 0.75, label = "P value", hjust = 0, size = 3.0, fontface = "bold", family = "sans") +
  annotate("text", x = 0.88, y = max(plot_df$row_id) + 0.75, label = "P for interaction", hjust = 0, size = 2.9, fontface = "bold", family = "sans") +
  geom_segment(data = tick_df, aes(x = x, xend = x, y = 0.25, yend = 0.40), inherit.aes = FALSE, linewidth = 0.35) +
  geom_text(data = tick_df, aes(x = x, y = 0.02, label = tick), inherit.aes = FALSE, size = 2.5, family = "sans", color = "grey35") +
  annotate("segment", x = forest_left, xend = forest_right, y = 0.40, yend = 0.40, linewidth = 0.45) +
  scale_x_continuous(limits = c(0, 1), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0, max(plot_df$row_id) + 1.2), expand = c(0, 0)) +
  coord_cartesian(clip = "off") +
  labs(x = NULL, y = NULL) +
  theme_void(base_family = "sans", base_size = 9) +
  theme(plot.margin = margin(6, 10, 10, 6))

ggsave(file.path(out_dir, "FigS_MIMIC_SOFA2_subgroup_forest.png"), p, width = 9.2, height = 8.8, dpi = 600, bg = "white")
ggsave(file.path(out_dir, "FigS_MIMIC_SOFA2_subgroup_forest.tiff"), p, width = 9.2, height = 8.8, dpi = 600, compression = "lzw", bg = "white")
ggsave(file.path(out_dir, "FigS_MIMIC_SOFA2_subgroup_forest.pdf"), p, width = 9.2, height = 8.8, bg = "white")

legend_text <- paste0(
  "Figure S. Subgroup analysis of the association between SOFA2 and ICU 28-day mortality in the MIMIC cohort. ",
  "Hazard ratios represent the relative increase in ICU 28-day mortality per 1-point increase in baseline 24-hour SOFA2. ",
  "Cox proportional hazards models were adjusted for the prespecified main covariates, excluding the stratification variable from the corresponding subgroup model. ",
  "P values for interaction were obtained by likelihood-ratio tests comparing models with and without the SOFA2-by-subgroup interaction term. ",
  "Horizontal lines indicate 95% confidence intervals."
)
writeLines(legend_text, file.path(out_dir, "FigS_MIMIC_SOFA2_subgroup_forest_legend.txt"))

sig_int <- subgroup_results %>%
  distinct(subgroup, interaction_p, interaction_p_formatted) %>%
  filter(!is.na(interaction_p)) %>%
  arrange(interaction_p)

summary_text <- c(
  sprintf("MIMIC subgroup Cox analysis used the current cleaned analysis master table (source N=%s). The full adjusted complete-case set contained N=%s patients and %s ICU 28-day deaths.",
          nrow(d), sum(full_cc), sum(d$status[full_cc] == 1)),
  "Across predefined strata, SOFA2 was modeled as a continuous exposure; HRs are reported per 1-point increase.",
  sprintf("The smallest interaction P value was observed for %s (P=%s). Benjamini-Hochberg FDR was applied jointly across the nine prespecified interaction tests; subgroup findings remain exploratory.",
          sig_int$subgroup[1], sig_int$interaction_p_formatted[1])
)
writeLines(summary_text, file.path(out_dir, "MIMIC_SOFA2_subgroup_results_summary.txt"))

cat("Done\n")
cat("Output directory:", out_dir, "\n")
print(qc)
print(subgroup_results %>% select(subgroup, level, n, events, HR_95CI, p_value_formatted, interaction_p_formatted))

