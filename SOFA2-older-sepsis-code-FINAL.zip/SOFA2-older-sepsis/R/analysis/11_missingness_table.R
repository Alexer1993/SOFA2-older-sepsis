project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)

required_packages <- c("dplyr", "readr")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

processed_dir <- file.path(project_root, "data", "processed")
table_dir <- file.path(project_root, "outputs", "tables")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

latest_path <- file.path(processed_dir, "SOFA2_latest_sofa_with_outcomes.rds")
decision_path <- file.path(table_dir, "SOFA2_cleaning_decision_report.csv")
sofa_source_path <- file.path(table_dir, "SOFA2_modeling_reference_sofa_score_sources.csv")

latest <- readRDS(latest_path)
decision <- readr::read_csv(decision_path, show_col_types = FALSE, locale = readr::locale(encoding = "UTF-8"))
sofa_source <- readr::read_csv(sofa_source_path, show_col_types = FALSE, locale = readr::locale(encoding = "UTF-8"))

missing_table <- data.frame(
  variable = names(latest),
  class = vapply(latest, function(x) paste(class(x), collapse = ";"), character(1)),
  missing_n = vapply(latest, function(x) sum(is.na(x)), integer(1)),
  missing_rate = vapply(latest, function(x) mean(is.na(x)), numeric(1)),
  nonmissing_n = vapply(latest, function(x) sum(!is.na(x)), integer(1)),
  stringsAsFactors = FALSE
) |>
  dplyr::mutate(
    missing_percent = round(.data$missing_rate * 100, 2),
    is_sofa_or_sofa2_exposure = .data$variable %in% sofa_source$variable
  ) |>
  dplyr::left_join(
    decision |>
      dplyr::select(
        variable,
        original_missing_n = missing_n,
        original_missing_rate = missing_rate,
        cleaning_decision = decision,
        cleaning_reason = reason
      ),
    by = "variable"
  ) |>
  dplyr::mutate(
    final_handling = dplyr::case_when(
      .data$is_sofa_or_sofa2_exposure ~ "SOFA/SOFA2 exposure or trajectory: raw non-imputed value retained",
      !is.na(.data$cleaning_decision) ~ .data$cleaning_decision,
      grepl("(_outcome$|_days_28$|_free_days_28$|^day3_|death_days_from_icu|icu_28d_death)", .data$variable) ~ "derived_outcome_variable",
      TRUE ~ "new_or_derived_variable"
    ),
    final_handling_cn = dplyr::case_when(
      .data$is_sofa_or_sofa2_exposure ~ "SOFA/SOFA2核心暴露或轨迹变量：保留原始未插补值",
      .data$final_handling == "kept_no_imputation" ~ "保留，未插补",
      .data$final_handling == "kept_structural_or_time_related" ~ "结构性/时间相关变量，保留且未插补",
      .data$final_handling == "deleted_high_missing" ~ "高缺失变量，已在清洗表中删除",
      .data$final_handling == "simple_imputed" ~ "简单插补",
      .data$final_handling == "missforest_imputed" ~ "MissForest插补",
      .data$final_handling == "missing_category_imputed" ~ "分类/文本变量缺失填为Missing",
      .data$final_handling == "derived_outcome_variable" ~ "派生结局变量",
      TRUE ~ "新增或派生变量"
    )
  ) |>
  dplyr::select(
    variable, class, missing_n, nonmissing_n, missing_rate, missing_percent,
    final_handling_cn, final_handling, cleaning_reason
  ) |>
  dplyr::arrange(dplyr::desc(.data$missing_rate), .data$variable)

summary_by_handling <- missing_table |>
  dplyr::count(.data$final_handling_cn, .data$final_handling, name = "variable_n") |>
  dplyr::arrange(dplyr::desc(.data$variable_n))

out_csv <- file.path(table_dir, "SOFA2_latest_missingness_table.csv")
out_xlsx_note <- file.path(table_dir, "SOFA2_latest_missingness_table_README.txt")
summary_csv <- file.path(table_dir, "SOFA2_latest_missingness_summary_by_handling.csv")

readr::write_csv(missing_table, out_csv)
readr::write_csv(summary_by_handling, summary_csv)

readLinesText <- c(
  "SOFA2 latest missingness table",
  "",
  "Source dataset: data/processed/SOFA2_latest_sofa_with_outcomes.rds",
  "Core rule: SOFA/SOFA2 exposure and trajectory variables retain raw non-imputed values; covariates follow the cleaned table strategy.",
  "",
  paste0("Rows in source dataset: ", nrow(latest)),
  paste0("Variables in source dataset: ", ncol(latest)),
  "",
  paste0("Main table: ", out_csv),
  paste0("Summary by handling: ", summary_csv)
)
writeLines(readLinesText, out_xlsx_note, useBytes = TRUE)

cat("Missingness table completed.\n")
cat("Rows in dataset: ", nrow(latest), "\n", sep = "")
cat("Variables: ", ncol(latest), "\n", sep = "")
cat("Output: ", out_csv, "\n", sep = "")


