project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
out_dir <- file.path(project_root, "outputs", "manuscript_figure5_trajectory_km")
source_dir <- out_dir
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

required_packages <- c("ggplot2", "dplyr", "readr", "stringr")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

infile <- file.path(source_dir, "TableS3_Cox_SOFA2_trajectory_groups.csv")
tab <- readr::read_csv(infile, show_col_types = FALSE)

trajectory_levels <- c("Moderate-stable", "High-stable", "Persistent-high/worsening")
model_levels <- c("Crude", "Full primary covariates")
model_labels <- c(
  "Crude" = "Crude model",
  "Full primary covariates" = "Full primary-covariate model"
)
model_colors <- c(
  "Crude" = "#0072B2",
  "Full primary covariates" = "#D55E00"
)

plot_df <- tab |>
  dplyr::filter(Model %in% model_levels) |>
  dplyr::mutate(
    `Trajectory group` = factor(`Trajectory group`, levels = trajectory_levels),
    Model = factor(Model, levels = model_levels),
    model_label = model_labels[as.character(Model)],
    p_label = dplyr::if_else(is.na(`P value`) | `P value` == "", "", paste0("P ", `P value`)),
    hr_label = `HR (95% CI)`,
    y = dplyr::case_when(
      `Trajectory group` == "Persistent-high/worsening" & Model == "Crude" ~ 6.15,
      `Trajectory group` == "Persistent-high/worsening" & Model == "Full primary covariates" ~ 5.75,
      `Trajectory group` == "High-stable" & Model == "Crude" ~ 4.15,
      `Trajectory group` == "High-stable" & Model == "Full primary covariates" ~ 3.75,
      `Trajectory group` == "Moderate-stable" & Model == "Crude" ~ 2.15,
      `Trajectory group` == "Moderate-stable" & Model == "Full primary covariates" ~ 1.75,
      TRUE ~ NA_real_
    ),
    group_y = dplyr::case_when(
      `Trajectory group` == "Persistent-high/worsening" ~ 6.65,
      `Trajectory group` == "High-stable" ~ 4.65,
      `Trajectory group` == "Moderate-stable" ~ 2.65,
      TRUE ~ NA_real_
    )
  )

group_df <- plot_df |>
  dplyr::distinct(`Trajectory group`, group_y) |>
  dplyr::mutate(
    group_label = as.character(`Trajectory group`),
    ref_label = "Reference: Low-stable"
  )

x_min <- 0.35
x_max <- 12.5

forest <- ggplot2::ggplot(plot_df, ggplot2::aes(x = HR, y = y, color = Model)) +
  ggplot2::geom_vline(xintercept = 1, linetype = "dashed", linewidth = 0.35, color = "grey45") +
  ggplot2::geom_errorbarh(
    ggplot2::aes(xmin = `Lower 95% CI`, xmax = `Upper 95% CI`),
    height = 0.12,
    linewidth = 0.65
  ) +
  ggplot2::geom_point(size = 2.25) +
  ggplot2::geom_text(
    data = group_df,
    ggplot2::aes(x = x_min, y = group_y, label = group_label),
    inherit.aes = FALSE,
    hjust = 0,
    size = 3.05,
    fontface = "bold",
    color = "black"
  ) +
  ggplot2::geom_text(
    ggplot2::aes(x = 0.55, y = y, label = model_label),
    inherit.aes = FALSE,
    hjust = 0,
    size = 2.65,
    color = "black"
  ) +
  ggplot2::geom_text(
    ggplot2::aes(x = 6.70, y = y, label = hr_label),
    inherit.aes = FALSE,
    hjust = 0,
    size = 2.65,
    color = "black"
  ) +
  ggplot2::geom_text(
    ggplot2::aes(x = 10.35, y = y, label = p_label),
    inherit.aes = FALSE,
    hjust = 0,
    size = 2.65,
    color = "black"
  ) +
  ggplot2::annotate("text", x = 0.55, y = 7.15, label = "Model", hjust = 0, size = 2.9, fontface = "bold") +
  ggplot2::annotate("text", x = 6.70, y = 7.15, label = "HR (95% CI)", hjust = 0, size = 2.9, fontface = "bold") +
  ggplot2::annotate("text", x = 10.35, y = 7.15, label = "P value", hjust = 0, size = 2.9, fontface = "bold") +
  ggplot2::annotate("text", x = 1.0, y = 0.75, label = "Lower risk", hjust = 1.05, size = 2.45, color = "grey35") +
  ggplot2::annotate("text", x = 1.0, y = 0.75, label = "Higher risk", hjust = -0.05, size = 2.45, color = "grey35") +
  ggplot2::scale_x_log10(
    limits = c(x_min, x_max),
    breaks = c(0.5, 1, 2, 4, 8),
    labels = c("0.5", "1", "2", "4", "8"),
    expand = ggplot2::expansion(mult = c(0, 0))
  ) +
  ggplot2::scale_y_continuous(limits = c(0.45, 7.35), breaks = NULL, expand = c(0, 0)) +
  ggplot2::scale_color_manual(values = model_colors, guide = "none") +
  ggplot2::coord_cartesian(clip = "off") +
  ggplot2::labs(x = "Hazard ratio for ICU 28-day mortality", y = NULL) +
  ggplot2::theme_classic(base_family = "sans", base_size = 9) +
  ggplot2::theme(
    axis.line.y = ggplot2::element_blank(),
    axis.ticks.y = ggplot2::element_blank(),
    axis.title.x = ggplot2::element_text(size = 9.5, margin = ggplot2::margin(t = 6)),
    axis.text.x = ggplot2::element_text(size = 8.5, color = "black"),
    plot.margin = ggplot2::margin(t = 8, r = 8, b = 8, l = 8),
    panel.grid = ggplot2::element_blank()
  )

base <- file.path(out_dir, "TableS3_Cox_SOFA2_trajectory_forest")
ggplot2::ggsave(paste0(base, ".tiff"), forest, width = 210, height = 95, units = "mm", dpi = 600, compression = "lzw", bg = "white")
ggplot2::ggsave(paste0(base, ".png"), forest, width = 210, height = 95, units = "mm", dpi = 300, bg = "white")
ggplot2::ggsave(paste0(base, ".pdf"), forest, width = 210, height = 95, units = "mm", bg = "white")

legend_text <- paste0(
  "Forest plot of Cox regression analysis for ICU-admission-based 28-day mortality by SOFA2 trajectory group. ",
  "Low-stable was used as the reference group. The crude model included the SOFA2 trajectory group only; ",
  "the principal adjusted model used age, sex, Charlson Comorbidity Index, infection source, sepsis timing relative to ICU admission, ICU admission source, ICU type, lactate, and a lactate-missingness indicator. Points represent hazard ratios and horizontal lines represent 95% confidence intervals."
)
writeLines(legend_text, file.path(out_dir, "TableS3_Cox_SOFA2_trajectory_forest_legend.txt"), useBytes = TRUE)

cat("Outputs written to: ", out_dir, "\n", sep = "")


