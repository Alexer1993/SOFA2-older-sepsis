set.seed(2026)

project_root <- Sys.getenv("SOFA2_PROJECT_ROOT", unset = "")
if (!nzchar(project_root)) project_root <- "."
project_root <- gsub("\\\\", "/", project_root)
project_root <- normalizePath(project_root, winslash = "/", mustWork = TRUE)

out_dir <- Sys.getenv("SOFA2_FIG3A_OUT_DIR", unset = file.path(project_root, "outputs", "manuscript_figure3"))
out_dir <- gsub("\\\\", "/", out_dir)
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

required <- c("survival", "ggplot2", "officer", "flextable", "dplyr")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) stop("Missing packages: ", paste(missing, collapse = ", "))

data_path <- file.path(project_root, "data", "analysis_ready_current", "MIMIC_SOFA2_analysis_master_current.rds")
d0 <- readRDS(data_path)

to_num <- function(x) suppressWarnings(as.numeric(as.character(x)))
fmt <- function(x, digits = 3) sprintf(paste0("%.", digits, "f"), x)
fmt_p <- function(x) {
  if (is.na(x)) return("NA")
  if (x < 0.001) return("<0.001")
  sprintf("%.3f", x)
}
fmt_int <- function(x) formatC(as.integer(round(x)), format = "d", big.mark = ",")
parse_time <- function(x) {
  if (inherits(x, "POSIXct")) return(x)
  as.POSIXct(as.character(x), tz = "UTC", tryFormats = c(
    "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M",
    "%Y-%m-%d", "%Y/%m/%d"
  ))
}
collapse_source <- function(x) {
  z <- as.character(x)
  raw_levels <- names(sort(table(z), decreasing = TRUE))
  english_levels <- c(
    "Other/undetermined", "Pulmonary", "Urinary tract", "Abdominal/biliary/gastrointestinal",
    "Skin/soft tissue", "Bloodstream", "Bone/joint", "Central nervous system",
    "Endocardial/cardiovascular", "Catheter/device-related"
  )
  map <- stats::setNames(english_levels[seq_along(raw_levels)], raw_levels)
  out <- unname(map[z])
  out[is.na(out)] <- "Other/undetermined"
  factor(out, levels = c("Pulmonary", "Urinary tract", "Abdominal/biliary/gastrointestinal",
                         "Skin/soft tissue", "Bloodstream", "Bone/joint", "Central nervous system",
                         "Endocardial/cardiovascular", "Catheter/device-related", "Other/undetermined"))
}
admission_source <- function(x) {
  z <- as.character(x)
  out <- dplyr::case_when(
    z == "EMERGENCY ROOM" ~ "Emergency department",
    z %in% c("PROCEDURE SITE", "PACU") ~ "Operating theatre/procedure",
    z == "TRANSFER FROM HOSPITAL" ~ "Other hospital",
    z %in% c("PHYSICIAN REFERRAL", "WALK-IN/SELF REFERRAL", "CLINIC REFERRAL") ~ "Ward/clinic",
    TRUE ~ "Other/unknown"
  )
  factor(out, levels = c("Emergency department", "Operating theatre/procedure", "Other hospital", "Ward/clinic", "Other/unknown"))
}
icu_type <- function(x) {
  z <- as.character(x)
  out <- dplyr::case_when(
    z %in% c("Medical Intensive Care Unit (MICU)", "Medical/Surgical Intensive Care Unit (MICU/SICU)") ~ "Medical ICU",
    z %in% c("Cardiac Vascular Intensive Care Unit (CVICU)", "Coronary Care Unit (CCU)") ~ "Cardiovascular ICU",
    z %in% c("Surgical Intensive Care Unit (SICU)", "Trauma SICU (TSICU)", "Neuro Surgical Intensive Care Unit (Neuro SICU)", "Surgery/Vascular/Intermediate", "Surgery/Trauma") ~ "Surgical/trauma ICU",
    grepl("Neuro", z, ignore.case = TRUE) ~ "Neuro ICU/intermediate",
    TRUE ~ "Other ICU/intermediate"
  )
  factor(out, levels = c("Medical ICU", "Cardiovascular ICU", "Surgical/trauma ICU", "Neuro ICU/intermediate", "Other ICU/intermediate"))
}
auc_cd <- function(time, status, marker, t) {
  case <- status == 1 & time <= t
  control <- time > t | (status == 0 & time >= t)
  if (sum(case) == 0 || sum(control) == 0) return(NA_real_)
  m_case <- marker[case]
  m_control <- marker[control]
  r <- rank(c(m_case, m_control), ties.method = "average")
  n1 <- length(m_case)
  n0 <- length(m_control)
  u <- sum(r[seq_len(n1)]) - n1 * (n1 + 1) / 2
  as.numeric(u / (n1 * n0))
}
trapz_mean <- function(x, y) {
  ok <- !is.na(x) & !is.na(y)
  x <- x[ok]; y <- y[ok]
  if (length(x) < 2) return(NA_real_)
  sum(diff(x) * (head(y, -1) + tail(y, -1)) / 2) / (max(x) - min(x))
}

icu_in <- parse_time(d0$icu_intime)
sepsis_time <- parse_time(d0$sepsis_time)
event28 <- suppressWarnings(as.integer(d0$icu_28d_death == 1))
death_days <- to_num(d0$death_days_from_icu)
time_raw <- ifelse(event28 == 1, pmin(death_days, 28), 28)
time_analysis <- time_raw
time_analysis[is.na(time_analysis)] <- 28
time_analysis[time_analysis <= 0] <- 0.5

dat <- data.frame(
  time = to_num(time_analysis),
  time_raw = to_num(time_raw),
  status = event28,
  sofa2 = to_num(d0$sofa2_dynamic24_max),
  sofa = to_num(d0$sofa_dynamic24_max),
  age = to_num(d0$age),
  male = as.integer(d0$gender %in% c("M", "Male", "male", 1)),
  charlson = to_num(d0$charlson),
  infection_source = collapse_source(d0$infection_site_main_enriched),
  sepsis_onset_h = as.numeric(difftime(sepsis_time, icu_in, units = "hours")),
  icu_admission_source = admission_source(d0$admission_location),
  icu_type = icu_type(d0$careunit),
  lactate = to_num(d0$lactate_first),
  death_days_from_icu = death_days
)

vars_required <- c("time", "status", "sofa2", "sofa", "age", "male", "charlson",
                   "infection_source", "sepsis_onset_h", "icu_admission_source", "icu_type", "lactate")
missing_counts <- vapply(dat[vars_required], function(x) sum(is.na(x)), integer(1))
complete_idx <- stats::complete.cases(dat[, vars_required])
cc <- dat[complete_idx, ]
cc$status <- as.integer(cc$status == 1)
cc$time <- pmin(pmax(cc$time, 0.5), 28)
cc$infection_source <- droplevels(cc$infection_source)
cc$icu_admission_source <- droplevels(cc$icu_admission_source)
cc$icu_type <- droplevels(cc$icu_type)

fit_sofa2 <- survival::coxph(
  survival::Surv(time, status) ~ sofa2 + age + male + charlson + infection_source +
    sepsis_onset_h + icu_admission_source + icu_type + lactate,
  data = cc, ties = "efron", x = TRUE
)
fit_sofa <- survival::coxph(
  survival::Surv(time, status) ~ sofa + age + male + charlson + infection_source +
    sepsis_onset_h + icu_admission_source + icu_type + lactate,
  data = cc, ties = "efron", x = TRUE
)

cc$lp_sofa2 <- as.numeric(stats::predict(fit_sofa2, type = "lp"))
cc$lp_sofa <- as.numeric(stats::predict(fit_sofa, type = "lp"))

times <- 3:28
auc_table <- data.frame(
  time = times,
  AUC_SOFA2 = vapply(times, function(t) auc_cd(cc$time, cc$status, cc$lp_sofa2, t), numeric(1)),
  AUC_SOFA = vapply(times, function(t) auc_cd(cc$time, cc$status, cc$lp_sofa, t), numeric(1))
)
auc_table$delta_AUC <- auc_table$AUC_SOFA2 - auc_table$AUC_SOFA
key_times <- c(3, 7, 14, 21, 28)
key_auc <- auc_table[auc_table$time %in% key_times, ]
mean_sofa2 <- mean(auc_table$AUC_SOFA2, na.rm = TRUE)
mean_sofa <- mean(auc_table$AUC_SOFA, na.rm = TRUE)
mean_delta <- mean(auc_table$delta_AUC, na.rm = TRUE)
iauc_sofa2 <- trapz_mean(auc_table$time, auc_table$AUC_SOFA2)
iauc_sofa <- trapz_mean(auc_table$time, auc_table$AUC_SOFA)
iauc_delta <- iauc_sofa2 - iauc_sofa

coef_sofa2 <- summary(fit_sofa2)$coefficients["sofa2", "coef"]
coef_sofa <- summary(fit_sofa)$coefficients["sofa", "coef"]
direction_ok <- coef_sofa2 > 0 && coef_sofa > 0

qc <- data.frame(
  item = c(
    "source_data",
    "source_rows",
    "analysis_method",
    "model_marker",
    "missing_time",
    "missing_status",
    "missing_SOFA2",
    "missing_SOFA",
    "missing_age",
    "missing_sex",
    "missing_Charlson",
    "missing_infection_source",
    "missing_sepsis_onset_after_ICU_admission",
    "missing_ICU_admission_source",
    "missing_ICU_type",
    "missing_lactate",
    "complete_case_rows",
    "analysis_rows",
    "death_events",
    "censored_or_event_free",
    "followup_time_le_0_before_correction",
    "death_time_gt28_but_status1",
    "event_marked_death_with_time_gt_28_after_truncation",
    "SOFA2_adjusted_model_score_coefficient",
    "SOFA_adjusted_model_score_coefficient",
    "higher_score_higher_risk",
    "mean_AUC_SOFA2_days_3_28",
    "mean_AUC_SOFA_days_3_28",
    "mean_delta_AUC_days_3_28",
    "integrated_AUC_SOFA2_days_3_28",
    "integrated_AUC_SOFA_days_3_28",
    "integrated_delta_AUC_days_3_28"
  ),
  value = c(
    data_path,
    nrow(dat),
    "complete-case adjusted Cox linear predictor with cumulative/dynamic AUC",
    "linear predictor from score + age + sex + Charlson + infection source + sepsis onset after ICU admission + ICU admission source + ICU type + lactate",
    missing_counts[["time"]],
    missing_counts[["status"]],
    missing_counts[["sofa2"]],
    missing_counts[["sofa"]],
    missing_counts[["age"]],
    missing_counts[["male"]],
    missing_counts[["charlson"]],
    missing_counts[["infection_source"]],
    missing_counts[["sepsis_onset_h"]],
    missing_counts[["icu_admission_source"]],
    missing_counts[["icu_type"]],
    missing_counts[["lactate"]],
    sum(complete_idx),
    nrow(cc),
    sum(cc$status == 1),
    sum(cc$status == 0),
    sum(dat$time_raw <= 0, na.rm = TRUE),
    sum(dat$status == 1 & dat$death_days_from_icu > 28, na.rm = TRUE),
    sum(cc$status == 1 & cc$time > 28, na.rm = TRUE),
    coef_sofa2,
    coef_sofa,
    direction_ok,
    mean_sofa2,
    mean_sofa,
    mean_delta,
    iauc_sofa2,
    iauc_sofa,
    iauc_delta
  ),
  stringsAsFactors = FALSE
)

plot_df <- rbind(
  data.frame(time = auc_table$time, auc = auc_table$AUC_SOFA2, score = "SOFA2"),
  data.frame(time = auc_table$time, auc = auc_table$AUC_SOFA, score = "SOFA")
)
plot_df$score <- factor(plot_df$score, levels = c("SOFA2", "SOFA"))

ymin <- max(0.50, floor((min(plot_df$auc, na.rm = TRUE) - 0.015) * 100) / 100)
ymax <- min(0.85, ceiling((max(plot_df$auc, na.rm = TRUE) + 0.015) * 100) / 100)
if (ymax - ymin < 0.08) ymax <- ymin + 0.08

base_theme <- ggplot2::theme_classic(base_family = "Arial", base_size = 8.5) +
  ggplot2::theme(
    axis.title = ggplot2::element_text(size = 9),
    axis.text = ggplot2::element_text(size = 8, color = "black"),
    legend.title = ggplot2::element_blank(),
    legend.text = ggplot2::element_text(size = 8),
    legend.background = ggplot2::element_rect(fill = "white", color = "grey80", linewidth = 0.25),
    legend.key.width = grid::unit(0.55, "cm"),
    plot.tag = ggplot2::element_text(face = "bold", size = 13, hjust = 0, vjust = 1),
    plot.margin = ggplot2::margin(8, 8, 6, 8)
  )

p <- ggplot2::ggplot(plot_df, ggplot2::aes(x = time, y = auc, color = score)) +
  ggplot2::geom_line(linewidth = 0.85) +
  ggplot2::scale_color_manual(values = c("SOFA2" = "#1F4E79", "SOFA" = "#D95F02")) +
  ggplot2::scale_x_continuous(breaks = c(3, 7, 14, 21, 28), limits = c(3, 28), expand = c(0.01, 0)) +
  ggplot2::scale_y_continuous(limits = c(ymin, ymax), breaks = seq(0.50, 0.85, by = 0.05)) +
  ggplot2::labs(x = "Time after ICU admission, days", y = "Time-dependent AUC", tag = "A") +
  base_theme +
  ggplot2::theme(legend.position = "inside", legend.position.inside = c(0.82, 0.18))

pdf_path <- file.path(out_dir, "Fig3A_time_dependent_AUC_SOFA2_vs_SOFA.pdf")
png_path <- file.path(out_dir, "Fig3A_time_dependent_AUC_SOFA2_vs_SOFA.png")
tiff_path <- file.path(out_dir, "Fig3A_time_dependent_AUC_SOFA2_vs_SOFA.tiff")

ggplot2::ggsave(pdf_path, p, width = 90, height = 82, units = "mm", device = grDevices::cairo_pdf)
ggplot2::ggsave(png_path, p, width = 90, height = 82, units = "mm", dpi = 300, bg = "white")
ggplot2::ggsave(tiff_path, p, width = 90, height = 82, units = "mm", dpi = 600, compression = "lzw", bg = "white")

utils::write.csv(auc_table, file.path(out_dir, "Fig3A_time_dependent_AUC_SOFA2_vs_SOFA_results.csv"), row.names = FALSE)
utils::write.csv(key_auc, file.path(out_dir, "Fig3A_key_timepoint_AUC_summary.csv"), row.names = FALSE)
utils::write.csv(qc, file.path(out_dir, "Fig3A_quality_check.csv"), row.names = FALSE)

key_line <- paste(
  paste0("day ", key_auc$time, ": SOFA2 AUC ", fmt(key_auc$AUC_SOFA2),
         ", SOFA AUC ", fmt(key_auc$AUC_SOFA), ", delta ", fmt(key_auc$delta_AUC)),
  collapse = "; "
)
overall_direction <- "SOFA-2 and conventional SOFA showed similar adjusted discrimination; paired uncertainty is reported separately."
legend_text <- paste0(
  "Figure 3A. Time-dependent area under the receiver operating characteristic curve comparing SOFA2 and conventional SOFA for prediction of all-cause mortality within 28 days after ICU admission. ",
  "AUCs were estimated from Day 3 through Day 28 using the same complete-case analytic cohort; Day 1 is not interpreted because the >=48-h ICU-stay eligibility criterion creates a design-imposed event-free window. ",
  "Markers were linear predictors from Cox models adjusted for age, sex, Charlson Comorbidity Index, infection source, sepsis onset after ICU admission, ICU admission source, ICU type, and lactate."
)
results_text <- paste0(
  "In the complete-case analytic cohort (N = ", fmt_int(nrow(cc)), "), ",
  fmt_int(sum(cc$status == 1)), " patients died within 28 days after ICU admission and ",
  fmt_int(sum(cc$status == 0)), " were censored or event-free by day 28. ",
  "At key time points, the adjusted time-dependent AUCs were: ", key_line, ". ",
  "The mean AUC across evaluated days 3-28 was ", fmt(mean_sofa2), " for SOFA2 and ", fmt(mean_sofa),
  " for SOFA (mean delta, ", fmt(mean_delta), "). ",
  "The integrated AUC was ", fmt(iauc_sofa2), " for SOFA2 and ", fmt(iauc_sofa),
  " for SOFA (integrated delta, ", fmt(iauc_delta), "). ",
  overall_direction,
  " Paired SOFA-2-minus-SOFA differences and 95% percentile-bootstrap intervals are generated by R/reviewer_analyses/paired_prediction_bootstrap.R using 2,000 patient-level resamples of fixed fitted markers; these are not DeLong tests or model-refitting optimism correction."
)

writeLines(legend_text, file.path(out_dir, "Fig3A_legend.txt"), useBytes = TRUE)
writeLines(results_text, file.path(out_dir, "Fig3A_results_description.txt"), useBytes = TRUE)

doc <- officer::read_docx()
doc <- officer::body_add_par(doc, "Figure 3A Legend", style = "heading 1")
doc <- officer::body_add_par(doc, legend_text, style = "Normal")
doc <- officer::body_add_par(doc, "Results Description", style = "heading 1")
doc <- officer::body_add_par(doc, results_text, style = "Normal")
doc <- officer::body_add_par(doc, "Key AUC Values", style = "heading 1")
doc <- flextable::body_add_flextable(doc, flextable::autofit(flextable::flextable(key_auc)))
doc <- officer::body_add_par(doc, "Quality Control", style = "heading 1")
doc <- flextable::body_add_flextable(doc, flextable::autofit(flextable::flextable(qc)))
print(doc, target = file.path(out_dir, "Fig3A_legend_and_results.docx"))

script_target <- file.path(out_dir, "make_fig3a_time_dependent_auc_sofa2_vs_sofa.R")
this_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1])
if (!is.na(this_file) && nzchar(this_file) && file.exists(this_file)) {
  file.copy(this_file, script_target, overwrite = TRUE)
}

message("FIG3A completed: ", out_dir)

