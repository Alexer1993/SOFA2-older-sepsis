out_dir <- Sys.getenv("SOFA2_FIGURES8_OUT_DIR", unset = "figureS8_trajectory_forest")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

mimic_csv <- Sys.getenv("SOFA2_MIMIC_TRAJECTORY_COX_CSV", unset = "TableS3_Cox_SOFA2_trajectory_groups.csv")
eicu_csv <- Sys.getenv("SOFA2_EICU_TRAJECTORY_COX_CSV", unset = "TableS5_eICU_Cox_SOFA2_trajectory_groups.csv")

required <- c("ggplot2", "dplyr")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) stop("Missing packages: ", paste(missing, collapse = ", "))

fmt_p <- function(p) {
  p <- suppressWarnings(as.numeric(p))
  ifelse(is.na(p), "", ifelse(p < 0.001, "P <0.001", paste0("P = ", sprintf("%.3f", p))))
}

mimic <- utils::read.csv(mimic_csv, check.names = FALSE) |>
  dplyr::filter(Model %in% c("Crude", "Full primary covariates")) |>
  dplyr::mutate(Cohort = "MIMIC")
eicu <- utils::read.csv(eicu_csv, check.names = FALSE) |>
  dplyr::mutate(Cohort = "eICU")

dat <- dplyr::bind_rows(mimic, eicu) |>
  dplyr::mutate(
    HR = as.numeric(HR),
    lower = as.numeric(`Lower 95% CI`),
    upper = as.numeric(`Upper 95% CI`),
    p_raw = suppressWarnings(as.numeric(`P value`)),
    model_short = dplyr::if_else(grepl("^Crude", Model), "Crude", "Adjusted"),
    model_detail = dplyr::case_when(
      Cohort == "MIMIC" & model_short == "Adjusted" ~ "Full primary covariates",
      Cohort == "eICU" & model_short == "Adjusted" ~ "Adjusted for age, sex, and ethnicity/race",
      TRUE ~ "Crude"
    ),
    hr_label = `HR (95% CI)`,
    p_label = dplyr::case_when(
      !is.na(p_raw) ~ fmt_p(p_raw),
      !is.na(`P value`) & trimws(as.character(`P value`)) != "" ~ paste0("P ", trimws(as.character(`P value`))),
      TRUE ~ ""
    )
  )

trajectory_levels <- c("Persistent-high/worsening", "High-stable", "Moderate-stable")
dat$`Trajectory group` <- factor(dat$`Trajectory group`, levels = trajectory_levels)
dat$Cohort <- factor(dat$Cohort, levels = c("MIMIC", "eICU"))
dat$model_short <- factor(dat$model_short, levels = c("Crude", "Adjusted"))

row_template <- expand.grid(
  `Trajectory group` = trajectory_levels,
  Cohort = c("MIMIC", "eICU"),
  model_short = c("Crude", "Adjusted"),
  KEEP.OUT.ATTRS = FALSE,
  stringsAsFactors = FALSE
)
row_template <- row_template |>
  dplyr::mutate(
    group_index = match(`Trajectory group`, trajectory_levels),
    cohort_index = match(Cohort, c("MIMIC", "eICU")),
    model_index = match(model_short, c("Crude", "Adjusted")),
    y = dplyr::case_when(
      `Trajectory group` == "Persistent-high/worsening" ~ 10.8,
      `Trajectory group` == "High-stable" ~ 6.8,
      `Trajectory group` == "Moderate-stable" ~ 2.8
    ) - (cohort_index - 1) * 1.05 - (model_index - 1) * 0.38
  )

plot_df <- dat |>
  dplyr::left_join(row_template, by = c("Trajectory group", "Cohort", "model_short")) |>
  dplyr::mutate(
    row_label = paste0(as.character(Cohort), "  ", as.character(model_short))
  )

group_df <- data.frame(
  `Trajectory group` = trajectory_levels,
  y = c(11.42, 7.42, 3.42),
  label = trajectory_levels,
  check.names = FALSE
)

cohort_colors <- c("MIMIC" = "#1F4E79", "eICU" = "#D95F02")
x_min <- 0.50
x_max <- 12

forest <- ggplot2::ggplot(plot_df, ggplot2::aes(x = HR, y = y, color = Cohort, shape = model_short)) +
  ggplot2::geom_vline(xintercept = 1, linetype = "dashed", linewidth = 0.35, color = "grey45") +
  ggplot2::geom_errorbarh(
    ggplot2::aes(xmin = lower, xmax = upper),
    height = 0.12,
    linewidth = 0.55
  ) +
  ggplot2::geom_point(size = 2.15, stroke = 0.85) +
  ggplot2::geom_text(
    data = group_df,
    ggplot2::aes(x = x_min, y = y, label = label),
    inherit.aes = FALSE,
    hjust = 0,
    size = 3.0,
    fontface = "bold",
    color = "black"
  ) +
  ggplot2::geom_text(
    ggplot2::aes(x = 0.68, y = y, label = row_label),
    inherit.aes = FALSE,
    hjust = 0,
    size = 2.45,
    color = "black"
  ) +
  ggplot2::geom_text(
    ggplot2::aes(x = 7.20, y = y, label = hr_label),
    inherit.aes = FALSE,
    hjust = 0,
    size = 2.45,
    color = "black"
  ) +
  ggplot2::geom_text(
    ggplot2::aes(x = 10.05, y = y, label = p_label),
    inherit.aes = FALSE,
    hjust = 0,
    size = 2.45,
    color = "black"
  ) +
  ggplot2::annotate("text", x = 0.68, y = 12.05, label = "Cohort / model", hjust = 0, size = 2.75, fontface = "bold") +
  ggplot2::annotate("text", x = 7.20, y = 12.05, label = "HR (95% CI)", hjust = 0, size = 2.75, fontface = "bold") +
  ggplot2::annotate("text", x = 10.05, y = 12.05, label = "P value", hjust = 0, size = 2.75, fontface = "bold") +
  ggplot2::scale_x_log10(
    limits = c(x_min, x_max),
    breaks = c(0.5, 1, 2, 4, 8),
    labels = c("0.5", "1", "2", "4", "8"),
    expand = ggplot2::expansion(mult = c(0, 0))
  ) +
  ggplot2::scale_y_continuous(limits = c(0.75, 12.35), breaks = NULL, expand = c(0, 0)) +
  ggplot2::scale_color_manual(values = cohort_colors) +
  ggplot2::scale_shape_manual(values = c("Crude" = 16, "Adjusted" = 17)) +
  ggplot2::coord_cartesian(clip = "off") +
  ggplot2::labs(x = "Hazard ratio for ICU 28-day mortality", y = NULL, color = NULL, shape = NULL) +
  ggplot2::theme_classic(base_family = "sans", base_size = 8.5) +
  ggplot2::theme(
    axis.line.y = ggplot2::element_blank(),
    axis.ticks.y = ggplot2::element_blank(),
    axis.title.x = ggplot2::element_text(size = 9, margin = ggplot2::margin(t = 6)),
    axis.text.x = ggplot2::element_text(size = 8, color = "black"),
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.text = ggplot2::element_text(size = 7.5),
    legend.key.width = grid::unit(0.45, "cm"),
    plot.margin = ggplot2::margin(t = 6, r = 8, b = 6, l = 8),
    panel.grid = ggplot2::element_blank()
  )

base <- file.path(out_dir, "FigureS8_MIMIC_eICU_SOFA2_trajectory_Cox_forest")
ggplot2::ggsave(paste0(base, ".tiff"), forest, width = 205, height = 130, units = "mm", dpi = 600, compression = "lzw", bg = "white")
ggplot2::ggsave(paste0(base, ".png"), forest, width = 205, height = 130, units = "mm", dpi = 300, bg = "white")
ggplot2::ggsave(paste0(base, ".pdf"), forest, width = 205, height = 130, units = "mm", bg = "white")

out_csv <- file.path(out_dir, "FigureS8_MIMIC_eICU_SOFA2_trajectory_Cox_forest_data.csv")
utils::write.csv(
  plot_df |>
    dplyr::select(Cohort, Model, Reference, `Trajectory group`, N, Events, HR, lower, upper, hr_label, p_label, model_detail),
  out_csv,
  row.names = FALSE
)

legend_text <- paste(
  "Figure S8. Cox regression forest plot for the database-specific 28-day mortality endpoints according to SOFA2 trajectory group in the MIMIC and eICU cohorts.",
  "Low-stable trajectory was used as the reference group.",
  "For each cohort, crude and adjusted hazard ratios are shown for Moderate-stable, High-stable, and Persistent-high/worsening trajectories.",
  "The principal MIMIC adjusted model included age, sex, Charlson Comorbidity Index, infection source, sepsis timing relative to ICU admission, ICU admission source, ICU type, lactate, and a lactate-missingness indicator; the eICU adjusted model included age, sex, and ethnicity/race.",
  "MIMIC-IV uses all-cause death within 28 days after ICU admission; eICU uses in-hospital death within 28 days because post-discharge vital status is unavailable. Points represent hazard ratios and horizontal lines represent 95% confidence intervals."
)
writeLines(legend_text, file.path(out_dir, "FigureS8_MIMIC_eICU_SOFA2_trajectory_Cox_forest_legend.txt"), useBytes = TRUE)

cat("Outputs written to: ", out_dir, "\n", sep = "")


