set.seed(2026)

project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
out_dir <- file.path(project_root, "outputs", "manuscript_figure5_trajectory_km")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

required_packages <- c("dplyr", "tidyr", "ggplot2", "survival", "broom", "patchwork", "officer", "flextable")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

fmt_p <- function(p) {
  ifelse(is.na(p), "", ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
}
fmt_ci <- function(est, lo, hi) sprintf("%.2f (%.2f-%.2f)", est, lo, hi)
fmt_pct <- function(x) sprintf("%.1f", 100 * x)
fmt_int <- function(x) formatC(as.integer(round(x)), format = "d", big.mark = ",")
to_num <- function(x) suppressWarnings(as.numeric(as.character(x)))
to_bin <- function(x) {
  if (is.null(x)) return(rep(NA_integer_, 0))
  if (is.numeric(x) || is.integer(x)) return(as.integer(x > 0))
  z <- tolower(trimws(as.character(x)))
  as.integer(z %in% c("1", "yes", "y", "true", "t"))
}
collapse_race <- function(x) {
  z <- toupper(as.character(x))
  out <- rep("Other/Unknown", length(z))
  out[grepl("WHITE", z)] <- "White"
  out[grepl("BLACK|AFRICAN", z)] <- "Black"
  out[grepl("ASIAN", z)] <- "Asian"
  out[grepl("HISPANIC|LATINO|SOUTH AMERICAN", z)] <- "Hispanic/Latino"
  factor(out, levels = c("White", "Black", "Asian", "Hispanic/Latino", "Other/Unknown"))
}

parse_time <- function(x) {
  if (inherits(x, "POSIXct")) return(x)
  as.POSIXct(as.character(x), tz = "UTC", tryFormats = c("%Y-%m-%d %H:%M:%S","%Y-%m-%d %H:%M","%Y-%m-%d"))
}
collapse_source <- function(x) {
  z <- tolower(trimws(as.character(x))); out <- rep("Other/undetermined", length(z))
  out[grepl("pulmonary|lung|respir|pneumonia",z)] <- "Pulmonary"
  out[grepl("urinary|urine|uti|renal|kidney",z)] <- "Urinary"
  out[grepl("abdominal|abdomen|biliary|gastro|periton",z)] <- "Abdominal"
  factor(out)
}
collapse_admission_source <- function(x) factor(ifelse(is.na(x)|trimws(as.character(x))=="","Other/unknown",as.character(x)))
collapse_icu_type <- function(x) factor(ifelse(is.na(x)|trimws(as.character(x))=="","Other ICU",as.character(x)))
fmt_event <- function(x) {
  ok <- !is.na(x)
  if (!sum(ok)) return("")
  n <- sum(x[ok] == 1)
  paste0(fmt_int(n), " (", fmt_pct(n / sum(ok)), ")")
}
fmt_eligible <- function(x) {
  ok <- !is.na(x)
  if (!sum(ok)) return("")
  n <- sum(x[ok] == 1)
  paste0(fmt_int(n), "/", fmt_int(sum(ok)), " (", fmt_pct(n / sum(ok)), ")")
}
p_cat <- function(x, g) {
  ok <- !is.na(x) & !is.na(g)
  if (sum(ok) < 3 || length(unique(g[ok])) < 2 || length(unique(x[ok])) < 2) return(NA_real_)
  tab <- table(droplevels(factor(x[ok])), droplevels(g[ok]))
  suppressWarnings({
    chi <- tryCatch(stats::chisq.test(tab), error = function(e) NULL)
    if (is.null(chi)) return(NA_real_)
    if (any(chi$expected < 5)) {
      tryCatch(stats::fisher.test(tab, simulate.p.value = any(dim(tab) > 2), B = 20000)$p.value, error = function(e) chi$p.value)
    } else {
      chi$p.value
    }
  })
}
new_after_day3 <- function(new_var, pre_var) {
  newx <- to_bin(new_var)
  pre <- to_bin(pre_var)
  out <- newx
  out[pre == 1] <- NA_integer_
  out[is.na(out) & !(pre == 1)] <- 0L
  out
}

current <- readRDS(file.path(project_root, "data", "analysis_ready_current", "MIMIC_SOFA2_analysis_master_current.rds"))
part4_obj <- readRDS(file.path(project_root, "outputs", "internal_part4_cutoff_trajectory_subgroup_sensitivity", "models", "Part4_cutoff_trajectory_subgroup_sensitivity_objects.rds"))
traj <- part4_obj$trajectory_data

trajectory_levels <- c("Low-stable", "Moderate-stable", "High-stable", "Persistent-high/worsening")
palette <- c(
  "Low-stable" = "#0072B2",
  "Moderate-stable" = "#009E73",
  "High-stable" = "#D55E00",
  "Persistent-high/worsening" = "#CC79A7"
)

analysis <- traj |>
  dplyr::left_join(
    current |>
      dplyr::transmute(
        stay_id,
        race_group = collapse_race(race),
        charlson_m = to_num(charlson),
        infection_source_m = collapse_source(infection_site_main_enriched),
        sepsis_onset_h = as.numeric(difftime(parse_time(sepsis_time), parse_time(icu_intime), units = "hours")),
        icu_admission_source_m = collapse_admission_source(admission_location),
        icu_type_m = collapse_icu_type(careunit),
        lactate_m = to_num(lactate_first),
        icu_mort = to_bin(icu_expire_flag_outcome),
        hosp_mort = to_bin(hospital_expire_flag_outcome),
        mort90 = to_bin(mortality_90_outcome),
        mort365 = to_bin(mortality_365_outcome),
        day3_new_invasive_vent = new_after_day3(day3_new_invasive_vent, day3_preexisting_invasive_vent),
        day3_new_septic_shock = new_after_day3(day3_new_septic_shock, day3_preexisting_septic_shock),
        day3_new_aki = new_after_day3(day3_new_aki, day3_preexisting_aki),
        day3_new_rrt = new_after_day3(day3_new_rrt, day3_preexisting_rrt)
      ),
    by = "stay_id"
  ) |>
  dplyr::mutate(
    lactate_missing_m = as.integer(is.na(lactate_m)),
    lactate_imp_m = dplyr::if_else(is.na(lactate_m), stats::median(lactate_m, na.rm = TRUE), lactate_m),
    trajectory_class = factor(as.character(trajectory_class), levels = trajectory_levels),
    trajectory_label = factor(
      paste0(as.character(trajectory_class), " (n=", as.integer(table(trajectory_class))[as.character(trajectory_class)], ")"),
      levels = paste0(trajectory_levels, " (n=", as.integer(table(trajectory_class)[trajectory_levels]), ")")
    )
  )

trajectory_summary <- analysis |>
  dplyr::group_by(trajectory_class) |>
  dplyr::summarise(
    n = dplyr::n(),
    deaths_28d = sum(event28 == 1),
    mortality_28d = deaths_28d / n,
    mean_day1 = mean(sofa2_d1),
    mean_day2 = mean(sofa2_d2),
    mean_day3 = mean(sofa2_d3),
    .groups = "drop"
  )
utils::write.csv(trajectory_summary, file.path(out_dir, "Fig5_trajectory_group_summary.csv"), row.names = FALSE)

traj_long <- trajectory_summary |>
  dplyr::select(trajectory_class, n, mean_day1, mean_day2, mean_day3) |>
  tidyr::pivot_longer(dplyr::starts_with("mean_day"), names_to = "day", values_to = "mean_sofa2") |>
  dplyr::mutate(
    day = as.integer(gsub("mean_day", "", day)),
    trajectory_label = factor(paste0(as.character(trajectory_class), " (n=", n, ")"),
                              levels = paste0(trajectory_levels, " (n=", trajectory_summary$n[match(trajectory_levels, trajectory_summary$trajectory_class)], ")")),
    trajectory_direct_label = dplyr::case_when(
      trajectory_class == "Persistent-high/worsening" ~ "Persistent-high/\nworsening",
      TRUE ~ as.character(trajectory_class)
    )
  )

fit_km <- survival::survfit(survival::Surv(time28, event28) ~ trajectory_class, data = analysis)
km_sum <- summary(fit_km, times = seq(0, 28, by = 0.25))
km_df <- data.frame(
  time = km_sum$time,
  surv = km_sum$surv,
  strata = sub("^trajectory_class=", "", km_sum$strata)
) |>
  dplyr::mutate(
    trajectory_class = factor(strata, levels = trajectory_levels),
    trajectory_label = factor(paste0(strata, " (n=", trajectory_summary$n[match(strata, trajectory_summary$trajectory_class)], ")"),
                              levels = levels(traj_long$trajectory_label))
  )
logrank <- survival::survdiff(survival::Surv(time28, event28) ~ trajectory_class, data = analysis)
logrank_p <- stats::pchisq(logrank$chisq, df = length(logrank$n) - 1, lower.tail = FALSE)

risk_times <- c(0, 7, 14, 21, 28)
risk_table <- do.call(rbind, lapply(trajectory_levels, function(cl) {
  sub <- analysis[analysis$trajectory_class == cl, ]
  data.frame(
    trajectory_class = cl,
    trajectory_label = paste0(cl, " (n=", nrow(sub), ")"),
    time = risk_times,
    n_risk = vapply(risk_times, function(t) sum(sub$time28 >= t), integer(1))
  )
})) |>
  dplyr::mutate(
    trajectory_label = factor(trajectory_label, levels = rev(levels(traj_long$trajectory_label))),
    time_label = factor(time, levels = risk_times)
  )
utils::write.csv(risk_table, file.path(out_dir, "Fig5_KM_risk_table.csv"), row.names = FALSE)

theme_pub <- ggplot2::theme_classic(base_size = 10.5) +
  ggplot2::theme(
    plot.title = ggplot2::element_text(face = "bold", size = 12, hjust = 0),
    axis.title = ggplot2::element_text(size = 10),
    axis.text = ggplot2::element_text(size = 9, color = "black"),
    legend.position = "none",
    legend.title = ggplot2::element_blank(),
    legend.text = ggplot2::element_text(size = 8.5),
    legend.key.width = grid::unit(1.0, "cm")
  )

p_a <- ggplot2::ggplot(traj_long, ggplot2::aes(x = day, y = mean_sofa2, color = trajectory_class, group = trajectory_class)) +
  ggplot2::geom_line(linewidth = 1.05) +
  ggplot2::geom_point(size = 2.4) +
  ggplot2::geom_text(
    data = traj_long[traj_long$day == 3, ],
    ggplot2::aes(label = trajectory_direct_label),
    hjust = 0, nudge_x = 0.08, size = 2.45, lineheight = 0.92, show.legend = FALSE
  ) +
  ggplot2::scale_color_manual(values = palette, breaks = trajectory_levels, labels = levels(traj_long$trajectory_label)) +
  ggplot2::scale_x_continuous(breaks = 1:3, labels = c("Day 1", "Day 2", "Day 3"), limits = c(1, 4.75), expand = ggplot2::expansion(mult = c(0.02, 0.02))) +
  ggplot2::scale_y_continuous(limits = c(0, 14), breaks = seq(0, 14, 2), expand = ggplot2::expansion(mult = c(0, 0.03))) +
  ggplot2::labs(title = "A", x = NULL, y = "Mean SOFA2") +
  theme_pub

p_b <- ggplot2::ggplot(km_df, ggplot2::aes(x = time, y = surv, color = trajectory_class, group = trajectory_class)) +
  ggplot2::geom_step(linewidth = 0.95) +
  ggplot2::scale_color_manual(values = palette, breaks = trajectory_levels, labels = levels(km_df$trajectory_label)) +
  ggplot2::coord_cartesian(xlim = c(0, 28), ylim = c(0.45, 1.00)) +
  ggplot2::scale_x_continuous(breaks = risk_times) +
  ggplot2::scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  ggplot2::labs(title = "B", x = "Days after ICU admission", y = "Survival probability") +
  theme_pub

p_risk <- ggplot2::ggplot(risk_table, ggplot2::aes(x = time_label, y = trajectory_label, label = fmt_int(n_risk), color = trajectory_class)) +
  ggplot2::geom_text(size = 2.7, show.legend = FALSE) +
  ggplot2::scale_color_manual(values = palette) +
  ggplot2::labs(x = "Days after ICU admission", y = "No. at risk") +
  ggplot2::theme_classic(base_size = 8.5) +
  ggplot2::theme(
    axis.line = ggplot2::element_blank(),
    axis.ticks = ggplot2::element_blank(),
    axis.text.y = ggplot2::element_text(size = 7.2, color = "black"),
    axis.text.x = ggplot2::element_text(size = 8, color = "black"),
    axis.title = ggplot2::element_text(size = 8),
    plot.margin = ggplot2::margin(t = 0, r = 4, b = 2, l = 4)
  )

combined <- p_a + (p_b / p_risk + patchwork::plot_layout(heights = c(3.4, 1.25))) +
  patchwork::plot_layout(widths = c(1.08, 1.18))

ggplot2::ggsave(file.path(out_dir, "Fig5_MIMIC_SOFA2_trajectory_KM.tiff"), combined, width = 190, height = 115, units = "mm", dpi = 600, compression = "lzw")
ggplot2::ggsave(file.path(out_dir, "Fig5_MIMIC_SOFA2_trajectory_KM.png"), combined, width = 190, height = 115, units = "mm", dpi = 300)
ggplot2::ggsave(file.path(out_dir, "Fig5_MIMIC_SOFA2_trajectory_KM.pdf"), combined, width = 190, height = 115, units = "mm")

outcome_specs <- list(
  list(section = "Mortality outcomes"),
  list(name = "ICU-admission-based 28-day all-cause mortality, n (%)", var = "event28", type = "binary"),
  list(name = "ICU mortality, n (%)", var = "icu_mort", type = "binary"),
  list(name = "In-hospital mortality, n (%)", var = "hosp_mort", type = "binary"),
  list(name = "90-day mortality, n (%)", var = "mort90", type = "binary"),
  list(name = "365-day mortality, n (%)", var = "mort365", type = "binary"),
  list(section = "Incident outcomes after day 3"),
  list(name = "New invasive ventilation after day 3, n/N eligible (%)", var = "day3_new_invasive_vent", type = "eligible"),
  list(name = "New AKI after day 3, n/N eligible (%)", var = "day3_new_aki", type = "eligible"),
  list(name = "New RRT after day 3, n/N eligible (%)", var = "day3_new_rrt", type = "eligible")
)
out_rows <- list()
for (sp in outcome_specs) {
  if (!is.null(sp$section)) {
    out_rows[[length(out_rows) + 1]] <- data.frame(
      Outcome = sp$section, Overall = "", `Low-stable` = "", `Moderate-stable` = "",
      `High-stable` = "", `Persistent-high/worsening` = "", `P value` = "",
      check.names = FALSE
    )
    next
  }
  x <- analysis[[sp$var]]
  formatter <- if (sp$type == "eligible") fmt_eligible else fmt_event
  row <- data.frame(
    Outcome = sp$name,
    Overall = formatter(x),
    `Low-stable` = formatter(x[analysis$trajectory_class == "Low-stable"]),
    `Moderate-stable` = formatter(x[analysis$trajectory_class == "Moderate-stable"]),
    `High-stable` = formatter(x[analysis$trajectory_class == "High-stable"]),
    `Persistent-high/worsening` = formatter(x[analysis$trajectory_class == "Persistent-high/worsening"]),
    `P value` = fmt_p(p_cat(x, analysis$trajectory_class)),
    check.names = FALSE
  )
  out_rows[[length(out_rows) + 1]] <- row
}
table_s2 <- dplyr::bind_rows(out_rows)
utils::write.csv(table_s2, file.path(out_dir, "TableS2_MIMIC_outcomes_by_SOFA2_trajectory.csv"), row.names = FALSE, fileEncoding = "UTF-8")

# Principal trajectory Cox models: crude, parsimonious, and full primary covariates.
analysis$trajectory_class <- stats::relevel(analysis$trajectory_class, ref = "Low-stable")
prep_cox <- function(vars) {
  z <- analysis[complete.cases(analysis[, unique(c("time28","event28","trajectory_class","subject_id",vars)), drop=FALSE]), , drop=FALSE]
  for (nm in vars) if (is.factor(z[[nm]])) z[[nm]] <- droplevels(z[[nm]])
  z
}
fit_traj <- function(vars) {
  z <- prep_cox(vars)
  f <- as.formula(paste("survival::Surv(time28,event28) ~ trajectory_class", if(length(vars)) paste("+",paste(vars,collapse=" + ")) else "", "+ cluster(subject_id)"))
  list(fit=survival::coxph(f,data=z,ties="efron"), data=z)
}
mods <- list(
  "Crude" = fit_traj(character(0)),
  "Parsimonious: age, sex, race" = fit_traj(c("age_m","male","race_group")),
  "Full primary covariates" = fit_traj(c("age_m","male","charlson_m","infection_source_m","sepsis_onset_h","icu_admission_source_m","icu_type_m","lactate_imp_m","lactate_missing_m"))
)
tidy_model <- function(obj, model) {
  broom::tidy(obj$fit, exponentiate=TRUE, conf.int=TRUE) |>
    dplyr::filter(grepl("^trajectory_class",term)) |>
    dplyr::transmute(Analysis="SOFA2 trajectory group", Model=model, Reference="Low-stable",
      `Trajectory group`=sub("^trajectory_class","",term), N=nrow(obj$data), Events=sum(obj$data$event28==1),
      HR=estimate, `Lower 95% CI`=conf.low, `Upper 95% CI`=conf.high,
      `HR (95% CI)`=fmt_ci(estimate,conf.low,conf.high), `P value`=fmt_p(p.value))
}
table_s3 <- dplyr::bind_rows(lapply(names(mods), function(nm) tidy_model(mods[[nm]],nm)))
utils::write.csv(table_s3, file.path(out_dir,"TableS3_Cox_SOFA2_trajectory_groups.csv"),row.names=FALSE,fileEncoding="UTF-8")

qc <- data.frame(
  item = c(
    "source_data",
    "trajectory_source_object",
    "current_master_rows",
    "trajectory_analysis_rows",
    "trajectory_missing_day1_3_excluded",
    "death_28d_events_in_trajectory",
    "logrank_p",
    "cox_crude_n",
    "cox_adjusted_n"
  ),
  value = c(
    file.path(project_root, "data", "analysis_ready_current", "MIMIC_SOFA2_analysis_master_current.rds"),
    file.path(project_root, "outputs", "internal_part4_cutoff_trajectory_subgroup_sensitivity", "models", "Part4_cutoff_trajectory_subgroup_sensitivity_objects.rds"),
    nrow(current),
    nrow(analysis),
    nrow(current) - nrow(analysis),
    sum(analysis$event28 == 1),
    signif(logrank_p, 6),
    nrow(mods[["Crude"]]$data),
    nrow(mods[["Full primary covariates"]]$data)
  )
)
utils::write.csv(qc, file.path(out_dir, "Fig5_TableS2_TableS3_QC_summary.csv"), row.names = FALSE)

legend_text <- paste0(
  "Figure 5. SOFA2 trajectories during the first three ICU days and 28-day survival in the MIMIC cohort.\n",
  "Panel A shows the mean SOFA2 values on ICU days 1, 2, and 3 for four K-means trajectory groups. ",
  "Panel B shows Kaplan-Meier survival curves for ICU-admission-based 28-day all-cause mortality according to trajectory group. ",
  "The risk table reports numbers at risk at 0, 7, 14, 21, and 28 days. ",
  "Trajectory analysis included ", fmt_int(nrow(analysis)), " admissions with complete day 1-3 SOFA2 values; ",
  fmt_int(nrow(current) - nrow(analysis)), " admissions were excluded from the trajectory analysis because Day-3 SOFA2 was unavailable; seven of these also lacked Day-2 SOFA2. ",
  "The log-rank P value was ", fmt_p(logrank_p), ". Detailed outcome and Cox regression results are provided in Tables S2 and S3."
)
results_text <- paste0(
  "Results. Four day 1-3 SOFA2 trajectory groups were identified: Low-stable (n=", fmt_int(trajectory_summary$n[1]),
  "), Moderate-stable (n=", fmt_int(trajectory_summary$n[2]),
  "), High-stable (n=", fmt_int(trajectory_summary$n[3]),
  "), and Persistent-high/worsening (n=", fmt_int(trajectory_summary$n[4]), "). ",
  "ICU 28-day mortality increased across trajectory groups from ",
  fmt_pct(trajectory_summary$mortality_28d[1]), "% in the Low-stable group to ",
  fmt_pct(trajectory_summary$mortality_28d[4]), "% in the Persistent-high/worsening group. ",
  "In Cox regression using Low-stable as the reference, the adjusted HRs were ",
  table_s3$`HR (95% CI)`[table_s3$Model == "Full primary covariates" & table_s3$`Trajectory group` == "Moderate-stable"], " for Moderate-stable, ",
  table_s3$`HR (95% CI)`[table_s3$Model == "Full primary covariates" & table_s3$`Trajectory group` == "High-stable"], " for High-stable, and ",
  table_s3$`HR (95% CI)`[table_s3$Model == "Full primary covariates" & table_s3$`Trajectory group` == "Persistent-high/worsening"], " for Persistent-high/worsening; all P values were <0.001."
)
writeLines(c(legend_text, "", results_text), file.path(out_dir, "Fig5_legend_and_results.txt"), useBytes = TRUE)

doc <- officer::read_docx()
doc <- officer::body_add_par(doc, "Figure 5 Legend and Results", style = "heading 1")
doc <- officer::body_add_par(doc, legend_text, style = "Normal")
doc <- officer::body_add_par(doc, "Results", style = "heading 1")
doc <- officer::body_add_par(doc, results_text, style = "Normal")
doc <- officer::body_add_par(doc, "Table S2. Clinical outcomes according to SOFA2 trajectory group", style = "heading 1")
doc <- flextable::body_add_flextable(doc, flextable::autofit(flextable::flextable(table_s2)))
doc <- officer::body_add_par(doc, "Table S3. Cox regression analysis for ICU-admission-based 28-day mortality by SOFA2 trajectory group", style = "heading 1")
doc <- flextable::body_add_flextable(doc, flextable::autofit(flextable::flextable(table_s3)))
print(doc, target = file.path(out_dir, "Fig5_legend_and_results.docx"))

cat("Outputs written to: ", out_dir, "\n", sep = "")


