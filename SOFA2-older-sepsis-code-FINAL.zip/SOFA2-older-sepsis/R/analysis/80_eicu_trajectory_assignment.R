trajectory_levels <- c(
  "Low-stable",
  "Moderate-stable",
  "High-stable",
  "Persistent-high/worsening"
)

load_mimic_trajectory_model <- function(model_rds) {
  model_object <- readRDS(model_rds)
  train <- model_object$trajectory_data
  fit <- model_object$kmeans_k4
  score_cols <- c("sofa2_d1", "sofa2_d2", "sofa2_d3")

  if (is.null(train) || is.null(fit)) {
    stop("The MIMIC model object lacks trajectory_data or kmeans_k4.")
  }
  if (!all(score_cols %in% names(train))) {
    stop("The MIMIC trajectory data lack one or more day 1-3 SOFA2 columns.")
  }

  train_matrix <- as.matrix(train[, score_cols])
  center <- colMeans(train_matrix)
  scale <- apply(train_matrix, 2, stats::sd)
  if (any(!is.finite(scale) | scale <= 0)) stop("Invalid MIMIC scaling SD.")

  mapping <- unique(data.frame(
    cluster = as.integer(train$trajectory_raw),
    trajectory_class = as.character(train$trajectory_class),
    stringsAsFactors = FALSE
  ))
  mapping <- mapping[!is.na(mapping$cluster) & !is.na(mapping$trajectory_class), ]
  if (nrow(mapping) != nrow(fit$centers) || anyDuplicated(mapping$cluster)) {
    stop("MIMIC cluster-to-label mapping is not one-to-one.")
  }

  center_order <- as.integer(rownames(fit$centers))
  labels <- mapping$trajectory_class[match(center_order, mapping$cluster)]
  if (anyNA(labels)) stop("Could not map every MIMIC K-means center to a label.")

  standardized_centers <- as.matrix(fit$centers)
  rownames(standardized_centers) <- labels
  standardized_centers <- standardized_centers[trajectory_levels, , drop = FALSE]

  raw_centers <- sweep(standardized_centers, 2, scale, "*")
  raw_centers <- sweep(raw_centers, 2, center, "+")

  list(
    score_cols = score_cols,
    training_mean = center,
    training_sd = scale,
    standardized_centers = standardized_centers,
    raw_centers = raw_centers,
    k = nrow(standardized_centers),
    distance = "squared Euclidean distance in MIMIC-standardized day 1-3 SOFA2 space",
    tie_rule = "first center in the prespecified trajectory order"
  )
}

assign_eicu_to_mimic_trajectory <- function(data, model, id = NULL) {
  if (!all(model$score_cols %in% names(data))) {
    stop("The external data lack one or more day 1-3 SOFA2 columns.")
  }

  complete <- stats::complete.cases(data[, model$score_cols, drop = FALSE])
  observed <- as.matrix(data[complete, model$score_cols, drop = FALSE])
  standardized <- sweep(observed, 2, model$training_mean, "-")
  standardized <- sweep(standardized, 2, model$training_sd, "/")

  distances <- vapply(seq_len(nrow(model$standardized_centers)), function(j) {
    rowSums((sweep(standardized, 2, model$standardized_centers[j, ], "-"))^2)
  }, numeric(nrow(standardized)))
  colnames(distances) <- rownames(model$standardized_centers)

  nearest_index <- max.col(-distances, ties.method = "first")
  sorted_distances <- t(apply(distances, 1, sort, partial = 1:2))
  assigned <- colnames(distances)[nearest_index]

  result <- data.frame(
    source_row = which(complete),
    trajectory_class = factor(assigned, levels = trajectory_levels),
    distance_nearest = distances[cbind(seq_len(nrow(distances)), nearest_index)],
    distance_margin = sorted_distances[, 2] - sorted_distances[, 1],
    stringsAsFactors = FALSE
  )
  if (!is.null(id)) result <- cbind(id = id[complete], result)
  distance_frame <- as.data.frame(distances, check.names = FALSE)
  names(distance_frame) <- paste0("distance_", make.names(names(distance_frame)))
  cbind(result, distance_frame)
}

trajectory_model_parameters <- function(model) {
  data.frame(
    trajectory_class = trajectory_levels,
    mean_day1_mimic = unname(model$training_mean[1]),
    sd_day1_mimic = unname(model$training_sd[1]),
    mean_day2_mimic = unname(model$training_mean[2]),
    sd_day2_mimic = unname(model$training_sd[2]),
    mean_day3_mimic = unname(model$training_mean[3]),
    sd_day3_mimic = unname(model$training_sd[3]),
    center_z_day1 = model$standardized_centers[, 1],
    center_z_day2 = model$standardized_centers[, 2],
    center_z_day3 = model$standardized_centers[, 3],
    center_raw_day1 = model$raw_centers[, 1],
    center_raw_day2 = model$raw_centers[, 2],
    center_raw_day3 = model$raw_centers[, 3],
    row.names = NULL,
    check.names = FALSE
  )
}


