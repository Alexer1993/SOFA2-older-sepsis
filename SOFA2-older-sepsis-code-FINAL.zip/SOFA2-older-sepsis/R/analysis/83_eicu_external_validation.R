set.seed(2026)

project_root <- Sys.getenv("SOFA2_PROJECT_ROOT", unset = ".")
project_root <- gsub("\\\\", "/", project_root)
project_root <- normalizePath(project_root, winslash = "/", mustWork = TRUE)
out_dir <- Sys.getenv(
  "SOFA2_FIG7_OUT_DIR",
  unset = file.path(project_root, "outputs", "manuscript_figure7_eicu_external_validation")
)
out_dir <- gsub("\\\\", "/", out_dir)
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

trajectory_helper <- Sys.getenv(
  "SOFA2_TRAJECTORY_HELPER",
  unset = file.path(project_root, "R", "analysis", "80_eicu_trajectory_assignment.R")
)
source(trajectory_helper)

required <- c("dplyr", "tidyr", "ggplot2", "survival", "broom", "gridExtra", "officer")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) stop("Missing packages: ", paste(missing, collapse = ", "))

fmt_p <- function(p) ifelse(is.na(p), "", ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
fmt_int <- function(x) formatC(as.integer(round(x)), format = "d", big.mark = ",")
fmt_ci <- function(est, lo, hi) sprintf("%.2f (%.2f-%.2f)", est, lo, hi)
to_num <- function(x) suppressWarnings(as.numeric(as.character(x)))
to_binary <- function(x) {
  if (is.numeric(x) || is.integer(x)) return(as.integer(x > 0))
  z <- tolower(trimws(as.character(x)))
  out <- rep(NA_integer_, length(z))
  out[z %in% c("1", "yes", "y", "true", "t", "male", "m")] <- 1L
  out[z %in% c("0", "no", "n", "false", "f", "female", "f")] <- 0L
  out
}
mode_value <- function(x) {
  x <- x[!is.na(x)]
  if (!length(x)) return(NA)
  names(sort(table(x), decreasing = TRUE))[1]
}
make_factor <- function(x, levels = NULL) {
  x <- as.character(x)
  x[is.na(x) | trimws(x) == ""] <- "Missing"
  if (is.null(levels)) return(droplevels(factor(x)))
  factor(x, levels = levels)
}
collapse_source <- function(x) {
  z <- tolower(trimws(enc2utf8(as.character(x))))
  out <- rep("Other/undetermined", length(z))
  out[grepl("pulmonary|lung|respir|pneumonia", z)] <- "Pulmonary"
  out[grepl("urinary|urine|uti|renal|kidney", z)] <- "Urinary"
  out[grepl("abdominal|abdomen|biliary|gastro|gi|intra|periton", z)] <- "Abdominal"
  out[grepl("bloodstream|blood stream|bacteremia|catheter|blood", z)] <- "Bloodstream"
  out[grepl("skin|soft tissue", z)] <- "Skin/soft tissue"
  out[is.na(z) | z == ""] <- "Other/undetermined"
  factor(out, levels = c("Pulmonary", "Urinary", "Abdominal", "Bloodstream", "Skin/soft tissue", "Other/undetermined"))
}
collapse_icu_admission_source_eicu <- function(unit_source, hosp_source) {
  z <- tolower(paste(unit_source, hosp_source))
  out <- rep("Other_unknown", length(z))
  out[grepl("emergency|ed", z)] <- "Emergency_department"
  out[grepl("operating|or|recovery|pacu|procedure", z)] <- "Procedure_or_OR"
  out[grepl("transfer|other hospital|floor|ward", z)] <- "Other_hospital_or_ward"
  out[grepl("direct|clinic|home|office", z)] <- "Ward_or_clinic"
  factor(out, levels = c("Emergency_department", "Procedure_or_OR", "Other_hospital_or_ward", "Ward_or_clinic", "Other_unknown"))
}
collapse_icu_type_eicu <- function(x) {
  z <- tolower(as.character(x))
  out <- rep("Other_ICU", length(z))
  out[grepl("med|micu", z)] <- "Medical_ICU"
  out[grepl("card|ccu|cv", z)] <- "Cardiovascular_ICU"
  out[grepl("surg|trauma|neuro", z)] <- "Surgical_trauma_ICU"
  factor(out, levels = c("Medical_ICU", "Cardiovascular_ICU", "Surgical_trauma_ICU", "Other_ICU"))
}
dynamic_auc <- function(time, status, marker, times) {
  out <- vapply(times, function(tt) {
    cases <- status == 1 & time <= tt
    controls <- time > tt
    ok <- is.finite(marker) & !is.na(cases) & !is.na(controls) & (cases | controls)
    if (sum(cases & ok) == 0 || sum(controls & ok) == 0) return(NA_real_)
    ranks <- rank(marker[ok], ties.method = "average")
    y <- cases[ok]
    n1 <- sum(y)
    n0 <- sum(!y)
    (sum(ranks[y]) - n1 * (n1 + 1) / 2) / (n1 * n0)
  }, numeric(1))
  data.frame(time = times, auc = out)
}
trapz_mean <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  x <- x[ok]; y <- y[ok]
  if (length(x) < 2) return(NA_real_)
  sum(diff(x) * (head(y, -1) + tail(y, -1)) / 2) / (max(x) - min(x))
}
prep_complete <- function(data, vars) {
  z <- data[, vars, drop = FALSE]
  z <- z[complete.cases(z), , drop = FALSE]
  for (nm in names(z)) if (is.factor(z[[nm]])) z[[nm]] <- droplevels(z[[nm]])
  z
}
drop_bad <- function(data, vars) {
  keep <- vars
  for (v in vars) {
    if (!v %in% names(data)) keep <- setdiff(keep, v)
    else if (is.factor(data[[v]]) && nlevels(data[[v]]) < 2) keep <- setdiff(keep, v)
    else if (!is.factor(data[[v]]) && length(unique(data[[v]])) < 2) keep <- setdiff(keep, v)
  }
  keep
}

eicu_raw <- readRDS(file.path(project_root, "data", "analysis_ready_current", "eICU_SOFA2_external_validation_master_current.rds"))
event28 <- suppressWarnings(as.integer(eicu_raw$mortality_28))
hospital_discharge_days <- to_num(eicu_raw$hospitaldischargeoffset) / 1440
unit_discharge_days <- to_num(eicu_raw$unitdischargeoffset) / 1440
event_time <- ifelse(!is.na(hospital_discharge_days), hospital_discharge_days, unit_discharge_days)
time28 <- ifelse(event28 == 1, pmax(pmin(event_time, 28), 0.5), 28.001)
male <- to_binary(eicu_raw$gender)
male[is.na(male)] <- as.integer(as.numeric(mode_value(male)))

eicu <- data.frame(
  id = eicu_raw$patientunitstayid,
  time28 = time28,
  event28 = event28,
  sofa2 = to_num(eicu_raw$sofa2_dynamic_24h_max),
  sofa = to_num(eicu_raw$sofa_dynamic_24h_max),
  sofa2_d1 = to_num(eicu_raw$sofa2_dynamic_24h_max),
  sofa2_d2 = to_num(eicu_raw$sofa2_dynamic_48h_max),
  sofa2_d3 = to_num(eicu_raw$sofa2_dynamic_72h_max),
  age = to_num(eicu_raw$age),
  male = male,
  charlson = to_num(eicu_raw$charlson),
  infection_source = collapse_source(if ("infection_site_collapsed_final_eicu" %in% names(eicu_raw)) eicu_raw$infection_site_collapsed_final_eicu else eicu_raw$infection_site_main_final_eicu),
  sepsis_onset_h = if ("sepsis3_hr_for_window" %in% names(eicu_raw)) to_num(eicu_raw$sepsis3_hr_for_window) else to_num(eicu_raw$sepsis3_hr),
  icu_admission_source = collapse_icu_admission_source_eicu(eicu_raw$unitadmitsource, eicu_raw$hospitaladmitsource),
  icu_type = collapse_icu_type_eicu(eicu_raw$unittype),
  lactate = to_num(eicu_raw$lactate_first)
)

covars <- c("age", "male", "charlson", "infection_source", "sepsis_onset_h", "icu_admission_source", "icu_type", "lactate")
auc_vars <- c("time28", "event28", "sofa2", "sofa", covars)
auc_data <- prep_complete(eicu, auc_vars)
auc_covars <- drop_bad(auc_data, covars)
fit_sofa2 <- survival::coxph(as.formula(paste("survival::Surv(time28, event28) ~", paste(c("sofa2", auc_covars), collapse = " + "))), data = auc_data, ties = "efron", x = TRUE, y = TRUE)
fit_sofa <- survival::coxph(as.formula(paste("survival::Surv(time28, event28) ~", paste(c("sofa", auc_covars), collapse = " + "))), data = auc_data, ties = "efron", x = TRUE, y = TRUE)
lp_sofa2 <- stats::predict(fit_sofa2, type = "lp")
lp_sofa <- stats::predict(fit_sofa, type = "lp")
times <- 3:28
auc_sofa2 <- dynamic_auc(auc_data$time28, auc_data$event28, lp_sofa2, times)
auc_sofa <- dynamic_auc(auc_data$time28, auc_data$event28, lp_sofa, times)
auc_tbl <- data.frame(time = times, AUC_SOFA2 = auc_sofa2$auc, AUC_SOFA = auc_sofa$auc)
auc_tbl$delta_AUC <- auc_tbl$AUC_SOFA2 - auc_tbl$AUC_SOFA
auc_key <- auc_tbl[auc_tbl$time %in% c(3, 7, 14, 21, 28), , drop = FALSE]
utils::write.csv(auc_tbl, file.path(out_dir, "Fig7A_eICU_time_dependent_AUC_results.csv"), row.names = FALSE)
utils::write.csv(auc_key, file.path(out_dir, "Fig7A_eICU_key_timepoint_AUC_summary.csv"), row.names = FALSE)

km_data <- prep_complete(eicu, c("time28", "event28", "sofa2"))
km_data$sofa2_cutoff_group <- factor(ifelse(km_data$sofa2 > 8, "High SOFA2 >8", "Low SOFA2 <=8"), levels = c("Low SOFA2 <=8", "High SOFA2 >8"))
km_fit <- survival::survfit(survival::Surv(time28, event28) ~ sofa2_cutoff_group, data = km_data)
km_sum <- summary(km_fit, times = seq(0, 28, by = 0.25))
km_df <- data.frame(time = km_sum$time, surv = km_sum$surv, strata = sub("^sofa2_cutoff_group=", "", km_sum$strata))
km_logrank <- survival::survdiff(survival::Surv(time28, event28) ~ sofa2_cutoff_group, data = km_data)
km_p <- stats::pchisq(km_logrank$chisq, df = length(km_logrank$n) - 1, lower.tail = FALSE)
km_summary <- km_data |>
  dplyr::group_by(sofa2_cutoff_group) |>
  dplyr::summarise(n = dplyr::n(), deaths_28d = sum(event28 == 1), mortality_28d = deaths_28d / n, .groups = "drop")
utils::write.csv(km_summary, file.path(out_dir, "Fig7B_eICU_SOFA2_cutoff_KM_summary.csv"), row.names = FALSE)

traj_data <- prep_complete(eicu, c("id", "time28", "event28", "sofa2_d1", "sofa2_d2", "sofa2_d3", "age", "male"))
mimic_model <- load_mimic_trajectory_model(file.path(
  project_root, "outputs", "internal_part4_cutoff_trajectory_subgroup_sensitivity",
  "models", "Part4_cutoff_trajectory_subgroup_sensitivity_objects.rds"
))
trajectory_assignment <- assign_eicu_to_mimic_trajectory(traj_data, mimic_model, id = traj_data$id)
stopifnot(nrow(trajectory_assignment) == nrow(traj_data))
traj_data$trajectory_class <- trajectory_assignment$trajectory_class
utils::write.csv(trajectory_model_parameters(mimic_model), file.path(out_dir, "Fig7C_MIMIC_trajectory_model_parameters.csv"), row.names = FALSE)
utils::write.csv(trajectory_assignment, file.path(out_dir, "Fig7C_eICU_patient_trajectory_assignments.csv"), row.names = FALSE)
traj_summary <- traj_data |>
  dplyr::group_by(trajectory_class) |>
  dplyr::summarise(
    n = dplyr::n(),
    deaths_28d = sum(event28 == 1),
    mortality_28d = deaths_28d / n,
    mean_day1 = mean(sofa2_d1),
    mean_day2 = mean(sofa2_d2),
    mean_day3 = mean(sofa2_d3),
    .groups = "drop"
  )
utils::write.csv(traj_summary, file.path(out_dir, "Fig7C_eICU_trajectory_validation_summary.csv"), row.names = FALSE)
traj_cox_data <- prep_complete(traj_data, c("time28", "event28", "trajectory_class", "age", "male"))
traj_cox_data$trajectory_class <- stats::relevel(traj_cox_data$trajectory_class, ref = "Low-stable")
fit_traj <- survival::coxph(survival::Surv(time28, event28) ~ trajectory_class + age + male, data = traj_cox_data, ties = "efron")
traj_cox <- broom::tidy(fit_traj, exponentiate = TRUE, conf.int = TRUE) |>
  dplyr::filter(grepl("^trajectory_class", term)) |>
  dplyr::transmute(
    reference = "Low-stable",
    trajectory_group = sub("^trajectory_class", "", term),
    n = nrow(traj_cox_data),
    events = sum(traj_cox_data$event28 == 1),
    HR = estimate,
    lower95 = conf.low,
    upper95 = conf.high,
    p = p.value,
    HR_95CI = fmt_ci(estimate, conf.low, conf.high),
    p_text = fmt_p(p.value)
  )
utils::write.csv(traj_cox, file.path(out_dir, "Fig7C_eICU_trajectory_Cox_results.csv"), row.names = FALSE)
traj_logrank <- survival::survdiff(survival::Surv(time28, event28) ~ trajectory_class, data = traj_data)
traj_logrank_p <- stats::pchisq(traj_logrank$chisq, df = length(traj_logrank$n) - 1, lower.tail = FALSE)

pal <- c(
  "SOFA2" = "#1F4E79", "SOFA" = "#D95F02",
  "Low SOFA2 <=8" = "#1F4E79", "High SOFA2 >8" = "#D95F02",
  "Low-stable" = "#0072B2", "Moderate-stable" = "#009E73",
  "High-stable" = "#D55E00", "Persistent-high/worsening" = "#CC79A7"
)
theme_pub <- ggplot2::theme_classic(base_family = "sans", base_size = 8.5) +
  ggplot2::theme(
    axis.title = ggplot2::element_text(size = 8.5),
    axis.text = ggplot2::element_text(size = 7.5, color = "black"),
    legend.title = ggplot2::element_blank(),
    legend.text = ggplot2::element_text(size = 7.2),
    legend.background = ggplot2::element_blank(),
    plot.margin = ggplot2::margin(3, 7, 5, 7)
  )

plot_auc <- rbind(
  data.frame(time = auc_tbl$time, value = auc_tbl$AUC_SOFA2, model = "SOFA2"),
  data.frame(time = auc_tbl$time, value = auc_tbl$AUC_SOFA, model = "SOFA")
)
plot_auc$model <- factor(plot_auc$model, levels = c("SOFA2", "SOFA"))
ymin_auc <- max(0.50, floor((min(plot_auc$value, na.rm = TRUE) - 0.015) * 100) / 100)
ymax_auc <- ceiling((max(plot_auc$value, na.rm = TRUE) + 0.015) * 100) / 100
p_a <- ggplot2::ggplot(plot_auc, ggplot2::aes(x = time, y = value, color = model)) +
  ggplot2::geom_line(linewidth = 0.7) +
  ggplot2::geom_point(data = plot_auc[plot_auc$time %in% c(3, 7, 14, 21, 28), ], size = 1.05) +
  ggplot2::scale_color_manual(values = pal[c("SOFA2", "SOFA")]) +
  ggplot2::scale_x_continuous(breaks = c(3, 7, 14, 21, 28), limits = c(3, 28), expand = c(0.01, 0)) +
  ggplot2::scale_y_continuous(limits = c(ymin_auc, ymax_auc), breaks = seq(0.50, 0.85, by = 0.05)) +
  ggplot2::labs(x = "Time after ICU admission, days", y = "Time-dependent AUC") +
  theme_pub +
  ggplot2::theme(legend.position = "top", legend.direction = "horizontal", legend.box.margin = ggplot2::margin(8, 0, 2, 0))

p_b <- ggplot2::ggplot(km_df, ggplot2::aes(x = time, y = surv, color = strata)) +
  ggplot2::geom_step(linewidth = 0.75) +
  ggplot2::scale_color_manual(
    values = pal[c("Low SOFA2 <=8", "High SOFA2 >8")],
    breaks = c("Low SOFA2 <=8", "High SOFA2 >8"),
    labels = c("Low <=8", "High >8")
  ) +
  ggplot2::coord_cartesian(xlim = c(0, 28), ylim = c(0.55, 1.00)) +
  ggplot2::scale_x_continuous(breaks = c(0, 7, 14, 21, 28)) +
  ggplot2::scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  ggplot2::labs(x = "Days after ICU admission", y = "Survival probability") +
  theme_pub +
  ggplot2::theme(legend.position = "top", legend.direction = "horizontal", legend.box.margin = ggplot2::margin(8, 0, 2, 0))

traj_long <- traj_summary |>
  dplyr::select(trajectory_class, n, mean_day1, mean_day2, mean_day3) |>
  tidyr::pivot_longer(dplyr::starts_with("mean_day"), names_to = "day", values_to = "mean_sofa2") |>
  dplyr::mutate(day = as.integer(gsub("mean_day", "", day)))
p_c <- ggplot2::ggplot(traj_long, ggplot2::aes(x = day, y = mean_sofa2, color = trajectory_class, group = trajectory_class)) +
  ggplot2::geom_line(linewidth = 0.75) +
  ggplot2::geom_point(size = 1.6) +
  ggplot2::scale_color_manual(values = pal[trajectory_levels]) +
  ggplot2::scale_x_continuous(breaks = 1:3, labels = c("Day 1", "Day 2", "Day 3"), limits = c(1, 3), expand = ggplot2::expansion(mult = c(0.04, 0.06))) +
  ggplot2::scale_y_continuous(limits = c(0, max(traj_long$mean_sofa2, na.rm = TRUE) + 1.2), breaks = seq(0, 16, by = 2)) +
  ggplot2::labs(x = NULL, y = "Mean SOFA2") +
  theme_pub +
  ggplot2::theme(
    legend.position = "top",
    legend.direction = "horizontal",
    legend.text = ggplot2::element_text(size = 6.5),
    legend.key.width = grid::unit(0.45, "cm"),
    legend.spacing.x = grid::unit(0.08, "cm"),
    legend.box.margin = ggplot2::margin(6, 0, 2, 0)
  ) +
  ggplot2::guides(color = ggplot2::guide_legend(nrow = 2, byrow = TRUE))

panel_labels <- gridExtra::arrangeGrob(
  grid::textGrob("A", x = 0.01, y = 0.25, hjust = 0, vjust = 0.5, gp = grid::gpar(fontface = "bold", fontsize = 13)),
  grid::textGrob("B", x = 0.01, y = 0.25, hjust = 0, vjust = 0.5, gp = grid::gpar(fontface = "bold", fontsize = 13)),
  grid::textGrob("C", x = 0.01, y = 0.25, hjust = 0, vjust = 0.5, gp = grid::gpar(fontface = "bold", fontsize = 13)),
  ncol = 3,
  widths = c(1, 1, 1.08)
)
panel_plots <- gridExtra::arrangeGrob(p_a, p_b, p_c, ncol = 3, widths = c(1, 1, 1.08))
fig <- gridExtra::arrangeGrob(panel_labels, panel_plots, ncol = 1, heights = grid::unit.c(grid::unit(0.48, "cm"), grid::unit(1, "null")))

ggplot2::ggsave(file.path(out_dir, "Fig7_eICU_external_validation_ABC.tiff"), fig, width = 190, height = 88, units = "mm", dpi = 600, compression = "lzw", bg = "white")
ggplot2::ggsave(file.path(out_dir, "Fig7_eICU_external_validation_ABC.png"), fig, width = 190, height = 88, units = "mm", dpi = 300, bg = "white")
ggplot2::ggsave(file.path(out_dir, "Fig7_eICU_external_validation_ABC.pdf"), fig, width = 190, height = 88, units = "mm", bg = "white")

qc <- data.frame(
  item = c(
    "source_data", "source_n", "source_events_28d", "auc_complete_case_n", "auc_complete_case_events",
    "km_cutoff_n", "km_cutoff_events", "sofa2_missing", "sofa_missing", "lactate_missing",
    "followup_time_le_0", "death_time_gt_28_with_status1", "sofa2_coefficient_positive", "sofa_coefficient_positive",
    "trajectory_validation_n", "trajectory_validation_events", "trajectory_assignment_method", "km_logrank_p", "trajectory_logrank_p"
  ),
  value = c(
    file.path(project_root, "data", "analysis_ready_current", "eICU_SOFA2_external_validation_master_current.rds"),
    nrow(eicu), sum(eicu$event28 == 1, na.rm = TRUE), nrow(auc_data), sum(auc_data$event28 == 1),
    nrow(km_data), sum(km_data$event28 == 1), sum(is.na(eicu$sofa2)), sum(is.na(eicu$sofa)), sum(is.na(eicu$lactate)),
    sum(eicu$time28 <= 0, na.rm = TRUE), sum(eicu$event28 == 1 & eicu$time28 > 28, na.rm = TRUE),
    unname(coef(fit_sofa2)["sofa2"] > 0), unname(coef(fit_sofa)["sofa"] > 0),
    nrow(traj_data), sum(traj_data$event28 == 1), "Nearest frozen MIMIC K-means center by squared Euclidean distance after MIMIC-based day-specific standardization",
    signif(km_p, 6), signif(traj_logrank_p, 6)
  )
)
utils::write.csv(qc, file.path(out_dir, "Fig7_eICU_external_validation_QC.csv"), row.names = FALSE)

mean_auc_sofa2 <- mean(auc_tbl$AUC_SOFA2, na.rm = TRUE)
mean_auc_sofa <- mean(auc_tbl$AUC_SOFA, na.rm = TRUE)
iauc_sofa2 <- trapz_mean(auc_tbl$time, auc_tbl$AUC_SOFA2)
iauc_sofa <- trapz_mean(auc_tbl$time, auc_tbl$AUC_SOFA)

legend_text <- paste(
  "Figure 7. External validation in the eICU cohort.",
  "(A) Time-dependent AUC curves comparing adjusted SOFA2- and SOFA-based Cox prediction models for in-hospital death within 28 days after ICU admission; Day 1 is not interpreted because the >=48-h ICU-stay eligibility criterion creates a design-imposed event-free window.",
  "Models were adjusted for age, sex, Charlson Comorbidity Index, infection source, sepsis onset after ICU admission, ICU admission source, ICU type, and lactate.",
  "(B) Kaplan-Meier survival curves according to the established MIMIC-derived SOFA2 cutoff (low, <=8; high, >8).",
  "(C) eICU validation of the MIMIC-derived day 1-3 SOFA2 trajectory phenotypes. Day-specific SOFA2 values were standardized using the MIMIC training means and standard deviations, and each eICU patient was assigned to the nearest frozen MIMIC K-means center by squared Euclidean distance; the trajectory model was not refitted in eICU."
)
results_text <- paste0(
  "The current eICU validation cohort included ", fmt_int(nrow(eicu)), " patients and ",
  fmt_int(sum(eicu$event28 == 1, na.rm = TRUE)), " in-hospital deaths within 28 days after ICU admission. For panel A, complete-case adjusted analysis included ",
  fmt_int(nrow(auc_data)), " patients and ", fmt_int(sum(auc_data$event28 == 1)), " deaths. ",
  "The adjusted time-dependent AUCs for SOFA2 versus SOFA were ",
  sprintf("%.3f", auc_key$AUC_SOFA2[auc_key$time == 3]), " versus ", sprintf("%.3f", auc_key$AUC_SOFA[auc_key$time == 3]), " at day 3, ",
  sprintf("%.3f", auc_key$AUC_SOFA2[auc_key$time == 7]), " versus ", sprintf("%.3f", auc_key$AUC_SOFA[auc_key$time == 7]), " at day 7, ",
  sprintf("%.3f", auc_key$AUC_SOFA2[auc_key$time == 14]), " versus ", sprintf("%.3f", auc_key$AUC_SOFA[auc_key$time == 14]), " at day 14, ",
  sprintf("%.3f", auc_key$AUC_SOFA2[auc_key$time == 21]), " versus ", sprintf("%.3f", auc_key$AUC_SOFA[auc_key$time == 21]), " at day 21, and ",
  sprintf("%.3f", auc_key$AUC_SOFA2[auc_key$time == 28]), " versus ", sprintf("%.3f", auc_key$AUC_SOFA[auc_key$time == 28]), " at day 28. ",
  "Mean AUCs across evaluated days 3-28 were ", sprintf("%.3f", mean_auc_sofa2), " and ", sprintf("%.3f", mean_auc_sofa),
  "; integrated AUCs were ", sprintf("%.3f", iauc_sofa2), " and ", sprintf("%.3f", iauc_sofa), ", respectively. ",
  "Using the established SOFA2 cutoff, the low and high groups included ",
  fmt_int(km_summary$n[km_summary$sofa2_cutoff_group == "Low SOFA2 <=8"]), " and ",
  fmt_int(km_summary$n[km_summary$sofa2_cutoff_group == "High SOFA2 >8"]), " patients, with in-hospital 28-day mortality rates of ",
  sprintf("%.1f%%", 100 * km_summary$mortality_28d[km_summary$sofa2_cutoff_group == "Low SOFA2 <=8"]), " and ",
  sprintf("%.1f%%", 100 * km_summary$mortality_28d[km_summary$sofa2_cutoff_group == "High SOFA2 >8"]), " (log-rank P ",
  fmt_p(km_p), "). In the trajectory validation analysis, in-hospital 28-day mortality increased across the four trajectory groups from ",
  sprintf("%.1f%%", 100 * traj_summary$mortality_28d[traj_summary$trajectory_class == "Low-stable"]), " in the Low-stable group to ",
  sprintf("%.1f%%", 100 * traj_summary$mortality_28d[traj_summary$trajectory_class == "Persistent-high/worsening"]),
  " in the Persistent-high/worsening group (log-rank P ", fmt_p(traj_logrank_p), ")."
)
writeLines(c(legend_text, "", results_text), file.path(out_dir, "Fig7_eICU_external_validation_legend_and_results.txt"), useBytes = TRUE)
doc <- officer::read_docx()
doc <- officer::body_add_par(doc, "Figure 7 Legend and Results", style = "heading 1")
doc <- officer::body_add_par(doc, legend_text, style = "Normal")
doc <- officer::body_add_par(doc, "Results", style = "heading 1")
doc <- officer::body_add_par(doc, results_text, style = "Normal")
print(doc, target = file.path(out_dir, "Fig7_eICU_external_validation_legend_and_results.docx"))

message("FIG7 eICU external validation completed: ", out_dir)


