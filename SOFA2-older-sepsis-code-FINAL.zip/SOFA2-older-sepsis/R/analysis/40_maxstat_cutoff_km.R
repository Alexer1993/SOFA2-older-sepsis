set.seed(2026)

project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
input_path <- file.path(project_root, "data", "analysis_ready_current", "MIMIC_SOFA2_analysis_master_current.rds")
out_dir <- file.path(project_root, "outputs", "manuscript_figure4_maxstat_km")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

required_packages <- c("dplyr", "ggplot2", "survival", "survminer", "patchwork", "officer")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing R packages: ", paste(missing_packages, collapse = ", "))
}

to_num <- function(x) suppressWarnings(as.numeric(as.character(x)))
fmt_p <- function(p) {
  if (is.na(p)) return(NA_character_)
  if (p < 0.001) return("<0.001")
  sprintf("%.3f", p)
}
fmt_num <- function(x, digits = 2) {
  formatC(x, format = "f", digits = digits)
}

save_plot_all <- function(plot, stem, width_mm, height_mm, dpi = 600) {
  pdf_path <- file.path(out_dir, paste0(stem, ".pdf"))
  png_path <- file.path(out_dir, paste0(stem, ".png"))
  tiff_path <- file.path(out_dir, paste0(stem, ".tiff"))
  ggplot2::ggsave(pdf_path, plot, width = width_mm, height = height_mm, units = "mm", device = cairo_pdf)
  ggplot2::ggsave(png_path, plot, width = width_mm, height = height_mm, units = "mm", dpi = 300, bg = "white")
  ggplot2::ggsave(tiff_path, plot, width = width_mm, height = height_mm, units = "mm", dpi = dpi, device = "tiff", compression = "lzw", bg = "white")
}

d0 <- readRDS(input_path)
main_n <- nrow(d0)

sofa2 <- to_num(d0$sofa2_dynamic24_max)
event28 <- suppressWarnings(as.integer(d0$icu_28d_death))
death_days <- to_num(d0$death_days_from_icu)

raw_time28 <- ifelse(event28 == 1 & !is.na(death_days), pmin(death_days, 28), 28)
time28 <- ifelse(event28 == 1, pmax(raw_time28, 0.5), 28)

ana <- data.frame(
  subject_id = d0$subject_id,
  sofa2 = sofa2,
  time28 = time28,
  raw_time28 = raw_time28,
  event28 = event28
)
ana <- ana[stats::complete.cases(ana[, c("sofa2", "time28", "event28")]), , drop = FALSE]
ana$event28 <- as.integer(ana$event28 == 1)

sofa2_missing <- sum(is.na(sofa2))
followup_nonpositive <- sum(!is.na(raw_time28) & raw_time28 <= 0)
death_after28_wrong <- sum(!is.na(death_days) & death_days > 28 & event28 == 1)

surv_cut <- survminer::surv_cutpoint(
  ana,
  time = "time28",
  event = "event28",
  variables = "sofa2",
  minprop = 0.10
)
maxstat_found_cutoff <- as.numeric(surv_cut$cutpoint["sofa2", "cutpoint"])
fixed_cutoff <- 8
final_cutoff <- fixed_cutoff

candidates <- sort(unique(ana$sofa2))
candidates <- candidates[candidates > min(candidates, na.rm = TRUE) & candidates < max(candidates, na.rm = TRUE)]
stat_rows <- lapply(candidates, function(cut) {
  group <- factor(ifelse(ana$sofa2 > cut, "High", "Low"), levels = c("Low", "High"))
  prop_low <- mean(group == "Low")
  prop_high <- mean(group == "High")
  if (min(prop_low, prop_high) < 0.10) return(NULL)
  sd <- survival::survdiff(survival::Surv(time28, event28) ~ group, data = ana)
  data.frame(
    variable = "SOFA2",
    cutoff = cut,
    statistic = sqrt(as.numeric(sd$chisq)),
    chisq = as.numeric(sd$chisq),
    p_value = stats::pchisq(as.numeric(sd$chisq), df = 1, lower.tail = FALSE),
    prop_low = prop_low,
    prop_high = prop_high
  )
})
stat_df <- dplyr::bind_rows(stat_rows)
best_row <- stat_df[which.max(stat_df$statistic), , drop = FALSE]
fixed_row <- stat_df[stat_df$cutoff == final_cutoff, , drop = FALSE]
if (nrow(fixed_row) == 0) fixed_row <- best_row

ana$sofa2_group <- factor(
  ifelse(ana$sofa2 > final_cutoff, paste0("SOFA2 > ", final_cutoff), paste0("SOFA2 <= ", final_cutoff)),
  levels = c(paste0("SOFA2 <= ", final_cutoff), paste0("SOFA2 > ", final_cutoff))
)

group_summary <- ana |>
  dplyr::group_by(.data$sofa2_group) |>
  dplyr::summarise(
    group = dplyr::first(as.character(.data$sofa2_group)),
    n = dplyr::n(),
    death_28d = sum(.data$event28 == 1),
    mortality_28d = death_28d / n,
    censored_or_alive_28d = sum(.data$event28 == 0),
    .groups = "drop"
  ) |>
  dplyr::select("group", "n", "death_28d", "mortality_28d", "censored_or_alive_28d")

cox_fit <- survival::coxph(
  survival::Surv(time28, event28) ~ sofa2_group + cluster(subject_id),
  data = ana,
  ties = "efron"
)
cox_sum <- summary(cox_fit)
cox_coef <- cox_sum$coefficients[1, , drop = FALSE]
cox_ci <- cox_sum$conf.int[1, , drop = FALSE]
cox_results <- data.frame(
  comparison = paste0("SOFA2 > ", final_cutoff, " vs SOFA2 <= ", final_cutoff),
  HR = unname(cox_ci[1, "exp(coef)"]),
  lower_95CI = unname(cox_ci[1, "lower .95"]),
  upper_95CI = unname(cox_ci[1, "upper .95"]),
  p_value = unname(cox_coef[1, "Pr(>|z|)"])
)

logrank <- survival::survdiff(survival::Surv(time28, event28) ~ sofa2_group, data = ana)
logrank_p <- stats::pchisq(as.numeric(logrank$chisq), df = 1, lower.tail = FALSE)

qc <- data.frame(
  item = c(
    "main_analysis_cohort_n",
    "fig4_analysis_n",
    "sofa2_missing_n",
    "death_28d_events_n",
    "censored_or_alive_28d_n",
    "sofa2_median",
    "sofa2_q1",
    "sofa2_q3",
    "sofa2_min",
    "sofa2_max",
    "maxstat_found_cutoff",
    "fixed_final_cutoff",
    "followup_time_leq0_n",
    "death_time_gt28_but_status1_n",
    "logrank_p"
  ),
  value = c(
    main_n,
    nrow(ana),
    sofa2_missing,
    sum(ana$event28 == 1),
    sum(ana$event28 == 0),
    unname(stats::median(ana$sofa2)),
    unname(stats::quantile(ana$sofa2, 0.25)),
    unname(stats::quantile(ana$sofa2, 0.75)),
    min(ana$sofa2),
    max(ana$sofa2),
    maxstat_found_cutoff,
    final_cutoff,
    followup_nonpositive,
    death_after28_wrong,
    logrank_p
  )
)

cutoff_results <- data.frame(
  variable = "SOFA2",
  cutoff = final_cutoff,
  maxstat_statistic = fixed_row$statistic[1],
  p_value = fixed_row$p_value[1],
  minprop = 0.10,
  analysis_sample_size = nrow(ana),
  maxstat_found_cutoff = maxstat_found_cutoff,
  fixed_cutoff_used = final_cutoff
)

utils::write.csv(qc, file.path(out_dir, "Fig4_QC_summary.csv"), row.names = FALSE)
utils::write.csv(cutoff_results, file.path(out_dir, "Fig4_MaxStat_cutoff_results.csv"), row.names = FALSE)
utils::write.csv(group_summary, file.path(out_dir, "Fig4_KM_group_summary.csv"), row.names = FALSE)
utils::write.csv(cox_results, file.path(out_dir, "Fig4_Cox_results.csv"), row.names = FALSE)
utils::write.csv(stat_df, file.path(out_dir, "Fig4_MaxStat_statistic_by_cutoff.csv"), row.names = FALSE)

base_theme <- ggplot2::theme_classic(base_size = 9, base_family = "Arial") +
  ggplot2::theme(
    axis.title = ggplot2::element_text(size = 9, colour = "black"),
    axis.text = ggplot2::element_text(size = 8, colour = "black"),
    legend.title = ggplot2::element_blank(),
    legend.text = ggplot2::element_text(size = 8),
    plot.tag = ggplot2::element_text(size = 14, face = "bold", colour = "black"),
    plot.tag.position = c(0, 1),
    plot.margin = ggplot2::margin(6, 8, 6, 8)
  )

panel_a <- ggplot2::ggplot(stat_df, ggplot2::aes(x = .data$cutoff, y = .data$statistic)) +
  ggplot2::geom_line(linewidth = 0.65, colour = "#2F5D8C") +
  ggplot2::geom_point(size = 1.6, colour = "#2F5D8C") +
  ggplot2::geom_vline(xintercept = final_cutoff, linetype = "dashed", linewidth = 0.45, colour = "#A33A3A") +
  ggplot2::annotate(
    "text",
    x = final_cutoff + 0.35,
    y = max(stat_df$statistic, na.rm = TRUE) * 0.96,
    label = paste0("cutoff = ", final_cutoff),
    hjust = 0,
    size = 3,
    family = "Arial",
    colour = "#A33A3A"
  ) +
  ggplot2::labs(x = "SOFA2 score", y = "Standardized log-rank statistic") +
  ggplot2::scale_x_continuous(breaks = sort(unique(stat_df$cutoff))) +
  ggplot2::coord_cartesian(clip = "off") +
  base_theme +
  ggplot2::annotate("text", x = -Inf, y = Inf, label = "A", hjust = -0.45, vjust = 1.15, fontface = "bold", size = 4.6, family = "Arial")

km_fit <- survival::survfit(survival::Surv(time28, event28) ~ sofa2_group, data = ana)
km_sum <- summary(km_fit, times = seq(0, 28, by = 0.25), extend = TRUE)
km_curve <- data.frame(
  time = km_sum$time,
  surv = km_sum$surv,
  strata = sub("^sofa2_group=", "", km_sum$strata)
)
time_breaks <- c(0, 7, 14, 21, 28)
risk_sum <- summary(km_fit, times = time_breaks, extend = TRUE)
risk_df <- data.frame(
  time = risk_sum$time,
  n_risk = risk_sum$n.risk,
  strata = sub("^sofa2_group=", "", risk_sum$strata)
)
risk_df$strata <- factor(risk_df$strata, levels = levels(ana$sofa2_group))
risk_df$x_plot <- pmin(pmax(risk_df$time, 1.0), 27.0)
utils::write.csv(risk_df, file.path(out_dir, "Fig4_KM_risk_table.csv"), row.names = FALSE)

km_palette <- c("#2F5D8C", "#B24745")
names(km_palette) <- levels(ana$sofa2_group)
y_min <- max(0.50, floor((min(km_curve$surv, na.rm = TRUE) - 0.03) * 10) / 10)
y_min <- min(y_min, 0.80)

km_label <- paste0("Log-rank P ", fmt_p(logrank_p))

panel_b_curve <- ggplot2::ggplot(km_curve, ggplot2::aes(x = .data$time, y = .data$surv, colour = .data$strata)) +
  ggplot2::geom_step(linewidth = 0.70) +
  ggplot2::scale_colour_manual(values = km_palette) +
  ggplot2::scale_x_continuous(limits = c(0, 28), breaks = time_breaks, expand = ggplot2::expansion(mult = c(0, 0.01))) +
  ggplot2::scale_y_continuous(limits = c(y_min, 1.00), breaks = seq(y_min, 1.00, by = 0.10)) +
  ggplot2::labs(x = NULL, y = "Survival probability", tag = "B") +
  ggplot2::coord_cartesian(clip = "off") +
  base_theme +
  ggplot2::theme(
    legend.position = "top",
    legend.direction = "horizontal",
    legend.justification = "right",
    legend.box.margin = ggplot2::margin(0, 0, 2, 0),
    axis.text.x = ggplot2::element_blank(),
    axis.ticks.x = ggplot2::element_blank(),
    plot.margin = ggplot2::margin(6, 8, 0, 14)
  )

risk_table_plot <- ggplot2::ggplot(risk_df, ggplot2::aes(x = .data$x_plot, y = .data$strata, label = .data$n_risk, colour = .data$strata)) +
  ggplot2::geom_text(size = 3.0, family = "Arial", show.legend = FALSE) +
  ggplot2::scale_colour_manual(values = km_palette) +
  ggplot2::scale_x_continuous(limits = c(0, 28), breaks = time_breaks, expand = ggplot2::expansion(mult = c(0, 0.01))) +
  ggplot2::labs(x = "Time after ICU admission, days", y = NULL) +
  ggplot2::theme_classic(base_size = 9, base_family = "Arial") +
  ggplot2::theme(
    axis.title.x = ggplot2::element_text(size = 9, colour = "black"),
    axis.title.y = ggplot2::element_blank(),
    axis.text.x = ggplot2::element_text(size = 8, colour = "black"),
    axis.text.y = ggplot2::element_text(size = 8, colour = "black"),
    axis.line.y = ggplot2::element_blank(),
    axis.ticks.y = ggplot2::element_blank(),
    plot.margin = ggplot2::margin(0, 8, 6, 8)
  )

panel_b <- panel_b_curve / risk_table_plot + patchwork::plot_layout(heights = c(3.7, 1.35))
combined <- panel_a | panel_b + patchwork::plot_layout(widths = c(0.95, 1.35))

save_plot_all(panel_a, "Fig4A_MaxStat_cutoff_SOFA2", width_mm = 90, height_mm = 75)
save_plot_all(panel_b, "Fig4B_KM_SOFA2_cutoff", width_mm = 145, height_mm = 105)
save_plot_all(combined, "Fig4_MaxStat_KM_SOFA2_cutoff", width_mm = 240, height_mm = 115)

legend_text <- paste0(
  "Figure 4. MaxStat-derived risk stratification based on SOFA2 for ICU 28-day mortality.\n",
  "(A) Maximally selected rank statistic analysis was used to evaluate candidate SOFA2 cutoffs for stratifying patients according to ICU 28-day mortality risk. The vertical dashed line indicates the prespecified final cutoff value of ",
  final_cutoff, ".\n",
  "(B) Kaplan-Meier survival curves for ICU 28-day survival according to the SOFA2 cutoff. Patients were classified as low risk (SOFA2 <= ",
  final_cutoff, ") or high risk (SOFA2 > ", final_cutoff,
  "). Differences between groups were assessed using the log-rank test, and the risk table shows the number of patients at risk at 0, 7, 14, 21, and 28 days after ICU admission."
)
writeLines(legend_text, file.path(out_dir, "Fig4_legend.txt"), useBytes = TRUE)

results_text <- paste0(
  "A total of ", nrow(ana), " patients were included in the Figure 4 analysis. ",
  "The MaxStat analysis supported a SOFA2 cutoff of ", maxstat_found_cutoff,
  "; consistent with the prespecified project cutoff, SOFA2 > ", final_cutoff,
  " was used to define the high-risk group and SOFA2 <= ", final_cutoff, " the low-risk group. ",
  "There were ", group_summary$n[group_summary$group == paste0("SOFA2 <= ", final_cutoff)], " patients in the low-risk group and ",
  group_summary$n[group_summary$group == paste0("SOFA2 > ", final_cutoff)], " patients in the high-risk group. ",
  "ICU 28-day mortality was ",
  group_summary$death_28d[group_summary$group == paste0("SOFA2 <= ", final_cutoff)], "/",
  group_summary$n[group_summary$group == paste0("SOFA2 <= ", final_cutoff)], " (",
  fmt_num(100 * group_summary$mortality_28d[group_summary$group == paste0("SOFA2 <= ", final_cutoff)], 1), "%) in the low-risk group and ",
  group_summary$death_28d[group_summary$group == paste0("SOFA2 > ", final_cutoff)], "/",
  group_summary$n[group_summary$group == paste0("SOFA2 > ", final_cutoff)], " (",
  fmt_num(100 * group_summary$mortality_28d[group_summary$group == paste0("SOFA2 > ", final_cutoff)], 1), "%) in the high-risk group. ",
  "Kaplan-Meier analysis showed different 28-day survival between groups (log-rank P ",
  fmt_p(logrank_p), "). In the crude Cox model, high-risk SOFA2 was associated with higher ICU 28-day mortality (HR ",
  fmt_num(cox_results$HR, 2), ", 95% CI ",
  fmt_num(cox_results$lower_95CI, 2), "-", fmt_num(cox_results$upper_95CI, 2),
  "; P ", fmt_p(cox_results$p_value), ")."
)
writeLines(results_text, file.path(out_dir, "Fig4_results_description.txt"), useBytes = TRUE)

doc <- officer::read_docx()
doc <- officer::body_add_par(doc, "Figure 4 Legend", style = "heading 1")
doc <- officer::body_add_par(doc, legend_text, style = "Normal")
doc <- officer::body_add_par(doc, "Results Description", style = "heading 1")
doc <- officer::body_add_par(doc, results_text, style = "Normal")
print(doc, target = file.path(out_dir, "Fig4_legend_and_results.docx"))

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
script_path <- if (length(file_arg)) sub("^--file=", "", file_arg[1]) else "make_fig4_maxstat_km_sofa2_cutoff.R"
file.copy(normalizePath(script_path, winslash = "/", mustWork = FALSE),
          file.path(out_dir, "Fig4_MaxStat_KM_SOFA2_cutoff.R"), overwrite = TRUE)

cat("Output directory:", out_dir, "\n")
cat("Analysis N:", nrow(ana), "\n")
cat("Cutoff:", final_cutoff, "\n")
cat("Log-rank P:", logrank_p, "\n")

