project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
source_dir <- file.path(project_root, "outputs", "manuscript_figure5_trajectory_km")
work_dir <- source_dir
dir.create(work_dir, recursive = TRUE, showWarnings = FALSE)

required_packages <- c("dplyr", "officer", "flextable")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

fmt_p <- function(p) {
  ifelse(is.na(p), "", ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
}
fmt_pct <- function(x) sprintf("%.1f", 100 * x)
fmt_int <- function(x) formatC(as.integer(round(x)), format = "d", big.mark = ",")
to_num <- function(x) suppressWarnings(as.numeric(as.character(x)))
to_bin <- function(x) {
  if (is.null(x)) return(rep(NA_integer_, 0))
  if (is.numeric(x) || is.integer(x)) return(as.integer(x > 0))
  z <- tolower(trimws(as.character(x)))
  as.integer(z %in% c("1", "yes", "y", "true", "t"))
}
fmt_event <- function(x) {
  ok <- !is.na(x)
  if (!sum(ok)) return("")
  n <- sum(x[ok] == 1)
  paste0(fmt_int(n), " (", fmt_pct(n / sum(ok)), ")")
}
fmt_eligible <- function(x) {
  ok <- !is.na(x)
  if (!sum(ok)) return("")
  n <- sum(x[ok] == 1)
  paste0(fmt_int(n), "/", fmt_int(sum(ok)), " (", fmt_pct(n / sum(ok)), ")")
}
fmt_cont <- function(x) {
  x <- to_num(x)
  ok <- !is.na(x)
  if (!sum(ok)) return("")
  q <- stats::quantile(x[ok], probs = c(0.25, 0.50, 0.75), names = FALSE, type = 2)
  sprintf("%.1f (%.1f-%.1f)", q[2], q[1], q[3])
}
p_cat <- function(x, g) {
  ok <- !is.na(x) & !is.na(g)
  if (sum(ok) < 3 || length(unique(g[ok])) < 2 || length(unique(x[ok])) < 2) return(NA_real_)
  tab <- table(droplevels(factor(x[ok])), droplevels(g[ok]))
  suppressWarnings({
    chi <- tryCatch(stats::chisq.test(tab), error = function(e) NULL)
    if (is.null(chi)) return(NA_real_)
    if (any(chi$expected < 5)) {
      tryCatch(stats::fisher.test(tab, simulate.p.value = any(dim(tab) > 2), B = 20000)$p.value, error = function(e) chi$p.value)
    } else {
      chi$p.value
    }
  })
}
p_cont <- function(x, g) {
  x <- to_num(x)
  ok <- !is.na(x) & !is.na(g)
  if (sum(ok) < 3 || length(unique(g[ok])) < 2) return(NA_real_)
  suppressWarnings(tryCatch(stats::kruskal.test(x[ok] ~ droplevels(factor(g[ok])))$p.value, error = function(e) NA_real_))
}
new_after_day3 <- function(new_var, pre_var) {
  newx <- to_bin(new_var)
  pre <- to_bin(pre_var)
  out <- newx
  out[pre == 1] <- NA_integer_
  out[is.na(out) & !(pre == 1)] <- 0L
  out
}

current <- readRDS(file.path(project_root, "data", "analysis_ready_current", "MIMIC_SOFA2_analysis_master_current.rds"))
part4_obj <- readRDS(file.path(project_root, "outputs", "internal_part4_cutoff_trajectory_subgroup_sensitivity", "models", "Part4_cutoff_trajectory_subgroup_sensitivity_objects.rds"))
traj <- part4_obj$trajectory_data

trajectory_levels <- c("Low-stable", "Moderate-stable", "High-stable", "Persistent-high/worsening")

analysis <- traj |>
  dplyr::left_join(
    current |>
      dplyr::transmute(
        stay_id,
        icu_mort = to_bin(icu_expire_flag_outcome),
        hosp_mort = to_bin(hospital_expire_flag_outcome),
        mort90 = to_bin(mortality_90_outcome),
        mort365 = to_bin(mortality_365_outcome),
        day3_new_invasive_vent = new_after_day3(day3_new_invasive_vent, day3_preexisting_invasive_vent),
        day3_new_septic_shock = new_after_day3(day3_new_septic_shock, day3_preexisting_septic_shock),
        day3_new_aki = new_after_day3(day3_new_aki, day3_preexisting_aki),
        day3_new_rrt = new_after_day3(day3_new_rrt, day3_preexisting_rrt),
        los_icu = to_num(los_icu),
        los_hospital = to_num(los_hospital),
        invasive_vent_free_days_28 = to_num(invasive_vent_free_days_28),
        vasopressor_free_days_28 = to_num(vasopressor_free_days_28),
        rrt_free_days_28 = to_num(rrt_free_days_28),
        icu_free_days_28 = to_num(icu_free_days_28)
      ),
    by = "stay_id"
  ) |>
  dplyr::mutate(trajectory_class = factor(as.character(trajectory_class), levels = trajectory_levels))

empty_row <- function(section) {
  data.frame(
    Outcome = section, Overall = "", `Low-stable` = "", `Moderate-stable` = "",
    `High-stable` = "", `Persistent-high/worsening` = "", `P value` = "",
    check.names = FALSE
  )
}

make_row <- function(name, var, type) {
  x <- analysis[[var]]
  formatter <- switch(type, eligible = fmt_eligible, binary = fmt_event, continuous = fmt_cont)
  p_value <- switch(type, eligible = p_cat(x, analysis$trajectory_class), binary = p_cat(x, analysis$trajectory_class), continuous = p_cont(x, analysis$trajectory_class))
  data.frame(
    Outcome = name,
    Overall = formatter(x),
    `Low-stable` = formatter(x[analysis$trajectory_class == "Low-stable"]),
    `Moderate-stable` = formatter(x[analysis$trajectory_class == "Moderate-stable"]),
    `High-stable` = formatter(x[analysis$trajectory_class == "High-stable"]),
    `Persistent-high/worsening` = formatter(x[analysis$trajectory_class == "Persistent-high/worsening"]),
    `P value` = fmt_p(p_value),
    check.names = FALSE
  )
}

table_s2 <- dplyr::bind_rows(
  empty_row("Mortality outcomes"),
  make_row("ICU-admission-based 28-day all-cause mortality, n (%)", "event28", "binary"),
  make_row("ICU mortality, n (%)", "icu_mort", "binary"),
  make_row("In-hospital mortality, n (%)", "hosp_mort", "binary"),
  make_row("90-day mortality, n (%)", "mort90", "binary"),
  make_row("365-day mortality, n (%)", "mort365", "binary"),
  empty_row("Incident outcomes after day 3"),
  make_row("New invasive ventilation after day 3, n/N eligible (%)", "day3_new_invasive_vent", "eligible"),
  make_row("New AKI after day 3, n/N eligible (%)", "day3_new_aki", "eligible"),
  make_row("New RRT after day 3, n/N eligible (%)", "day3_new_rrt", "eligible"),
  empty_row("Length of stay and organ-support-free days"),
  make_row("ICU length of stay, days, median (IQR)", "los_icu", "continuous"),
  make_row("Hospital length of stay, days, median (IQR)", "los_hospital", "continuous"),
  make_row("28-day ventilator-free days, median (IQR)", "invasive_vent_free_days_28", "continuous"),
  make_row("28-day vasopressor-free days, median (IQR)", "vasopressor_free_days_28", "continuous"),
  make_row("28-day RRT-free days, median (IQR)", "rrt_free_days_28", "continuous"),
  make_row("28-day ICU-free days, median (IQR)", "icu_free_days_28", "continuous")
)

csv_work <- file.path(work_dir, "TableS2_MIMIC_outcomes_by_SOFA2_trajectory.csv")
utils::write.csv(table_s2, csv_work, row.names = FALSE, fileEncoding = "UTF-8")

section_rows <- which(table_s2$Overall == "" & table_s2$`P value` == "")
ft <- flextable::flextable(table_s2)
ft <- flextable::theme_booktabs(ft)
ft <- flextable::font(ft, fontname = "Arial", part = "all")
ft <- flextable::fontsize(ft, size = 8, part = "all")
ft <- flextable::fontsize(ft, size = 8.5, part = "header")
ft <- flextable::bold(ft, part = "header")
ft <- flextable::bg(ft, bg = "#F2F4F7", part = "header")
ft <- flextable::align(ft, align = "center", part = "header")
ft <- flextable::align(ft, j = 1, align = "left", part = "body")
ft <- flextable::align(ft, j = 2:ncol(table_s2), align = "center", part = "body")
ft <- flextable::padding(ft, padding.top = 2, padding.bottom = 2, padding.left = 3, padding.right = 3, part = "all")
for (i in section_rows) {
  ft <- flextable::merge_at(ft, i = i, j = 1:ncol(table_s2), part = "body")
  ft <- flextable::bold(ft, i = i, bold = TRUE, part = "body")
  ft <- flextable::italic(ft, i = i, italic = TRUE, part = "body")
  ft <- flextable::bg(ft, i = i, bg = "#E8EEF5", part = "body")
  ft <- flextable::align(ft, i = i, align = "left", part = "body")
}
ft <- flextable::set_table_properties(ft, layout = "fixed", width = 1)
ft <- flextable::width(ft, j = 1, width = 2.25)
ft <- flextable::width(ft, j = 2, width = 1.15)
ft <- flextable::width(ft, j = 3, width = 1.15)
ft <- flextable::width(ft, j = 4, width = 1.20)
ft <- flextable::width(ft, j = 5, width = 1.20)
ft <- flextable::width(ft, j = 6, width = 1.55)
ft <- flextable::width(ft, j = 7, width = 0.70)
ft <- flextable::autofit(ft)

doc <- officer::read_docx()
doc <- officer::body_add_par(doc, "Table S2. Clinical outcomes according to SOFA2 trajectory group", style = "heading 1")
doc <- officer::body_add_par(
  doc,
  "Values are presented as n (%), n/N eligible (%), or median (IQR). P values were calculated using chi-square/Fisher exact tests for categorical variables and Kruskal-Wallis tests for continuous variables.",
  style = "Normal"
)
doc <- flextable::body_add_flextable(doc, ft)
doc <- officer::body_add_par(
  doc,
  "Abbreviations: AKI, acute kidney injury; ICU, intensive care unit; IQR, interquartile range; RRT, renal replacement therapy; SOFA2, Sequential Organ Failure Assessment 2.",
  style = "Normal"
)
doc <- officer::body_end_section_landscape(doc)
docx_work <- file.path(work_dir, "TableS2_MIMIC_outcomes_by_SOFA2_trajectory.docx")
print(doc, target = docx_work)

qc <- data.frame(
  item = c(
    "source_data",
    "trajectory_source_object",
    "analysis_rows",
    "missing_los_icu",
    "missing_los_hospital",
    "missing_ventilator_free_days_28",
    "missing_vasopressor_free_days_28",
    "missing_rrt_free_days_28",
    "missing_icu_free_days_28"
  ),
  value = c(
    file.path(project_root, "data", "analysis_ready_current", "MIMIC_SOFA2_analysis_master_current.rds"),
    file.path(project_root, "outputs", "internal_part4_cutoff_trajectory_subgroup_sensitivity", "models", "Part4_cutoff_trajectory_subgroup_sensitivity_objects.rds"),
    nrow(analysis),
    sum(is.na(analysis$los_icu)),
    sum(is.na(analysis$los_hospital)),
    sum(is.na(analysis$invasive_vent_free_days_28)),
    sum(is.na(analysis$vasopressor_free_days_28)),
    sum(is.na(analysis$rrt_free_days_28)),
    sum(is.na(analysis$icu_free_days_28))
  )
)
utils::write.csv(qc, file.path(work_dir, "TableS2_LOS_free_days_QC.csv"), row.names = FALSE, fileEncoding = "UTF-8")

cat("CSV:", csv_work, "\n")
cat("DOCX:", docx_work, "\n")
cat("QC:", file.path(work_dir, "TableS2_LOS_free_days_QC.csv"), "\n")


