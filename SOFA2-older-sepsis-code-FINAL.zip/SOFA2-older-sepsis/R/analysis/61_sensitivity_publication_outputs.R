suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(stringr)
  library(patchwork)
})

project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
src_dir <- file.path(project_root, "outputs", "manuscript_sensitivity_mimic")
out_dir <- file.path(src_dir, "publication")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

theme_pub <- function(base_size = 9) {
  theme_classic(base_size = base_size, base_family = "sans") +
    theme(
      axis.title = element_text(size = base_size),
      axis.text = element_text(size = base_size - 1, color = "black"),
      plot.title = element_blank(),
      plot.subtitle = element_blank(),
      legend.position = "bottom",
      legend.title = element_blank(),
      legend.text = element_text(size = base_size - 1),
      plot.margin = margin(6, 8, 6, 8),
      panel.grid = element_blank()
    )
}

fmt_p <- function(p) ifelse(is.na(p), "", ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
baseline <- read_csv(file.path(src_dir, "TableS_MIMIC_baseline_SOFA2_sensitivity_Cox.csv"), show_col_types = FALSE) %>%
  mutate(
    model_short = recode(model,
      "Primary adjusted model: project lactate imputation + missingness indicator" = "Primary adjusted",
      "Complete-case analysis using observed lactate" = "Complete-case",
      "MICE imputation of lactate covariate (m=5, predictive mean matching)" = "MICE",
      "Excluding sepsis onset 24-48 h after ICU admission" = "Exclude 24-48 h sepsis"
    ),
    model_short = factor(model_short, levels = rev(c("Primary adjusted", "Complete-case", "MICE", "Exclude 24-48 h sepsis")))
  )

p1 <- ggplot(baseline, aes(y = model_short, x = HR)) +
  geom_vline(xintercept = 1, linetype = "dashed", color = "grey50", linewidth = 0.35) +
  geom_errorbarh(aes(xmin = lower95, xmax = upper95), height = 0.18, linewidth = 0.55, color = "#1F4E79") +
  geom_point(size = 2.2, shape = 21, fill = "#1F4E79", color = "white", stroke = 0.25) +
  scale_x_continuous(limits = c(0.98, 1.15), breaks = c(1.00, 1.05, 1.10, 1.15)) +
  labs(x = "Hazard ratio per 1-point increase in SOFA2", y = NULL, tag = "A") +
  theme_pub() +
  theme(plot.tag = element_text(face = "bold", size = 13), plot.tag.position = c(0.02, 0.98))

kcmp <- read_csv(file.path(src_dir, "TableS_trajectory_kmeans_3_4_5_model_comparison.csv"), show_col_types = FALSE)
p2 <- ggplot(kcmp, aes(x = factor(k), y = between_total_ratio)) +
  geom_col(width = 0.58, fill = "#4B6F8C") +
  geom_text(aes(label = sprintf("%.3f", between_total_ratio)), vjust = -0.4, size = 2.8, family = "sans") +
  coord_cartesian(ylim = c(0.60, 0.82)) +
  labs(x = "Number of trajectory classes", y = "Between/total sum-of-squares ratio", tag = "B") +
  theme_pub() +
  theme(plot.tag = element_text(face = "bold", size = 13), plot.tag.position = c(0.02, 0.98))

landmark <- read_csv(file.path(src_dir, "TableS_72h_landmark_trajectory_Cox.csv"), show_col_types = FALSE) %>%
  mutate(analysis_label = "72 h landmark")
weighted <- read_csv(file.path(src_dir, "TableS_posterior_probability_weighted_trajectory_Cox.csv"), show_col_types = FALSE) %>%
  mutate(analysis_label = "Posterior probability weighted")
locf <- read_csv(file.path(src_dir, "TableS_LOCF_vs_zero_trajectory_Cox.csv"), show_col_types = FALSE) %>%
  mutate(analysis_label = case_when(
    str_detect(analysis, "LOCF") ~ "Post-ICU LOCF",
    TRUE ~ "Post-ICU set to 0"
  ))

clean_traj <- function(x) {
  x %>%
    mutate(
      group = case_when(
        str_detect(term, "Moderate|class 2|Class 2|LOCF class 2|Zero class 2") ~ "Class 2",
        str_detect(term, "High|class 3|Class 3|LOCF class 3|Zero class 3") ~ "Class 3",
        str_detect(term, "Persistent|class 4|Class 4|LOCF class 4|Zero class 4") ~ "Class 4",
        TRUE ~ term
      )
    )
}

traj_sens <- bind_rows(clean_traj(landmark), clean_traj(weighted), clean_traj(locf)) %>%
  mutate(
    analysis_label = factor(analysis_label, levels = c("72 h landmark", "Posterior probability weighted", "Post-ICU set to 0", "Post-ICU LOCF")),
    group = factor(group, levels = c("Class 2", "Class 3", "Class 4"))
  )

p3 <- ggplot(traj_sens, aes(x = HR, y = group, color = analysis_label, shape = analysis_label)) +
  geom_vline(xintercept = 1, linetype = "dashed", color = "grey50", linewidth = 0.35) +
  geom_errorbarh(aes(xmin = lower95, xmax = upper95), position = position_dodge(width = 0.55),
                 height = 0.18, linewidth = 0.45) +
  geom_point(position = position_dodge(width = 0.55), size = 2.0) +
  scale_color_manual(values = c("#1F4E79", "#7A5A00", "#6B7280", "#A23E48")) +
  scale_shape_manual(values = c(16, 17, 15, 18)) +
  scale_x_log10(limits = c(0.9, 4.2), breaks = c(1, 1.5, 2, 3, 4), labels = c("1", "1.5", "2", "3", "4")) +
  labs(x = "Hazard ratio for ICU 28-day mortality", y = NULL, tag = "C") +
  theme_pub() +
  theme(legend.position = "bottom", plot.tag = element_text(face = "bold", size = 13), plot.tag.position = c(0.02, 0.98))

inc <- read_csv(file.path(src_dir, "TableS_incremental_value_model_metrics.csv"), show_col_types = FALSE) %>%
  mutate(
    model_short = recode(model,
      "Clinical covariates only" = "Clinical",
      "Clinical covariates + baseline SOFA2" = "+ SOFA2",
      "Clinical covariates + trajectory class" = "+ trajectory",
      "Clinical covariates + baseline SOFA2 + trajectory class" = "+ SOFA2 + trajectory"
    ),
    model_short = factor(model_short, levels = c("Clinical", "+ SOFA2", "+ trajectory", "+ SOFA2 + trajectory"))
  )

p4 <- ggplot(inc, aes(x = model_short, y = concordance)) +
  geom_col(width = 0.62, fill = "#4B6F8C") +
  geom_errorbar(aes(ymin = concordance - 1.96 * concordance_se, ymax = concordance + 1.96 * concordance_se),
                width = 0.15, linewidth = 0.35) +
  geom_text(aes(label = sprintf("%.3f", concordance)), vjust = -0.45, size = 2.75, family = "sans") +
  coord_cartesian(ylim = c(0.66, 0.725)) +
  labs(x = NULL, y = "Harrell's C-index", tag = "D") +
  theme_pub() +
  theme(axis.text.x = element_text(angle = 20, hjust = 1),
        plot.tag = element_text(face = "bold", size = 13), plot.tag.position = c(0.02, 0.98))

fig <- (p1 | p2) / (p3 | p4) + plot_layout(heights = c(1, 1.12), guides = "collect") &
  theme(legend.position = "bottom")

ggsave(file.path(out_dir, "FigureS9_MIMIC_sensitivity_summary.png"), fig, width = 9.0, height = 7.2, dpi = 600, bg = "white")
ggsave(file.path(out_dir, "FigureS9_MIMIC_sensitivity_summary.tiff"), fig, width = 9.0, height = 7.2, dpi = 600, compression = "lzw", bg = "white")
ggsave(file.path(out_dir, "FigureS9_MIMIC_sensitivity_summary.pdf"), fig, width = 9.0, height = 7.2, bg = "white")

## Additional clean single-panel figures for manuscript flexibility.
ggsave(file.path(out_dir, "FigureS9A_baseline_sensitivity_forest.tiff"), p1, width = 6.2, height = 2.6, dpi = 600, compression = "lzw", bg = "white")
ggsave(file.path(out_dir, "FigureS9B_kmeans_class_comparison.tiff"), p2, width = 4.4, height = 3.0, dpi = 600, compression = "lzw", bg = "white")
ggsave(file.path(out_dir, "FigureS9C_trajectory_sensitivity_forest.tiff"), p3, width = 6.4, height = 3.8, dpi = 600, compression = "lzw", bg = "white")
ggsave(file.path(out_dir, "FigureS9D_incremental_value_cindex.tiff"), p4, width = 4.8, height = 3.2, dpi = 600, compression = "lzw", bg = "white")

legend <- paste0(
  "Figure S9. Sensitivity analyses in the MIMIC cohort. ",
  "(A) Adjusted Cox estimates for baseline SOFA2 under the primary covariate strategy, complete-case analysis, MICE imputation, and exclusion of patients with sepsis onset 24-48 h after ICU admission. ",
  "(B) K-means trajectory class comparison according to the between/total sum-of-squares ratio. ",
  "(C) Trajectory sensitivity Cox analyses including 72 h landmark analysis, distance-derived posterior probability weighting, and post-ICU SOFA2 handling by setting values to zero or last observation carried forward. ",
  "(D) Incremental predictive value assessed by Harrell's C-index across nested models. Points and bars represent hazard ratios or C-index estimates; horizontal or vertical lines indicate 95% confidence intervals where applicable."
)
writeLines(legend, file.path(out_dir, "FigureS9_MIMIC_sensitivity_legend.txt"))

results <- c(
  "In baseline SOFA2 sensitivity analyses, estimates were stable across complete-case analysis, MICE imputation, and exclusion of patients with sepsis onset 24-48 h after ICU admission, with adjusted HRs around 1.10-1.11 per 1-point increase.",
  "K-means trajectory comparison showed improved separation with increasing class number, with between/total ratios of 0.679, 0.744, and 0.778 for 3-, 4-, and 5-class solutions, respectively.",
  "Trajectory associations persisted in 72 h landmark and posterior probability weighted analyses, and were nearly unchanged when post-ICU SOFA2 values were handled by LOCF rather than setting them to zero.",
  "Trajectory class added incremental prognostic information beyond clinical covariates and baseline SOFA2 (likelihood-ratio test P < 0.001), while baseline SOFA2 also retained modest incremental information beyond trajectory class (P < 0.001)."
)
writeLines(results, file.path(out_dir, "FigureS9_MIMIC_sensitivity_results.txt"))

cat("Done\n")
cat(out_dir, "\n")

