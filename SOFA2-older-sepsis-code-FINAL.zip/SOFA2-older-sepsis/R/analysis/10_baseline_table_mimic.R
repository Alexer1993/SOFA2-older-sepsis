set.seed(2026)
invisible(try(Sys.setlocale("LC_CTYPE", "Chinese_China.936"), silent = TRUE))
invisible(try(Sys.setlocale("LC_COLLATE", "Chinese_China.936"), silent = TRUE))

project_root_env <- Sys.getenv("SOFA2_PROJECT_ROOT", unset = "")
if (nzchar(project_root_env)) {
  project_root <- gsub("\\\\", "/", project_root_env)
} else {
  args_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1])
  if (is.na(args_file) || !nzchar(args_file)) {
    project_root <- normalizePath(file.path(getwd(), ".."), winslash = "/", mustWork = TRUE)
  } else {
    project_root <- normalizePath(file.path(dirname(normalizePath(args_file, winslash = "/", mustWork = TRUE)), ".."), winslash = "/", mustWork = TRUE)
  }
}

out_dir <- file.path(project_root, "outputs", "mimic_baseline_table_updated")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

required <- c("dplyr", "openxlsx", "officer", "flextable")
missing_pkgs <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_pkgs) > 0) stop("Missing packages: ", paste(missing_pkgs, collapse = ", "))

data_path <- file.path(project_root, "data", "analysis_ready_current", "MIMIC_SOFA2_analysis_master_current.rds")
manifest_path <- file.path(project_root, "data", "analysis_ready_current", "analysis_ready_current_manifest.csv")

fmt_n <- function(x) formatC(as.integer(x), big.mark = ",", format = "d")
fmt_p <- function(p) {
  if (is.na(p)) return("")
  if (p < 0.001) return("<0.001")
  sprintf("%.3f", p)
}
fmt_num <- function(x, digits = 1) {
  if (is.na(x)) return("")
  formatC(x, format = "f", digits = digits, big.mark = ",")
}
fmt_missing <- function(x, n_total) {
  n <- sum(is.na(x))
  sprintf("%s (%.1f)", fmt_n(n), 100 * n / n_total)
}
fmt_cont <- function(x, digits = 1) {
  x <- suppressWarnings(as.numeric(x))
  x <- x[!is.na(x)]
  if (length(x) == 0) return("")
  qs <- stats::quantile(x, c(0.25, 0.5, 0.75), na.rm = TRUE, names = FALSE)
  sprintf("%s [%s-%s]", fmt_num(qs[2], digits), fmt_num(qs[1], digits), fmt_num(qs[3], digits))
}
fmt_cat <- function(x, level, denom) {
  n <- sum(x == level, na.rm = TRUE)
  if (denom == 0) return("")
  sprintf("%s (%.1f)", fmt_n(n), 100 * n / denom)
}
clean_chr <- function(x) {
  z <- as.character(x)
  z[trimws(z) %in% c("", "NA", "NaN", "NULL", "NaT")] <- NA_character_
  z
}
to_num <- function(x) suppressWarnings(as.numeric(x))
to_bin <- function(x) {
  if (is.null(x)) return(NULL)
  if (is.logical(x)) return(as.integer(x))
  if (is.numeric(x) || is.integer(x)) return(as.integer(x > 0))
  z <- tolower(trimws(as.character(x)))
  ifelse(z %in% c("1", "yes", "y", "true", "t", "male", "m"), 1L,
         ifelse(z %in% c("0", "no", "n", "false", "f", "female"), 0L, NA_integer_))
}
parse_time <- function(x) {
  if (inherits(x, "POSIXct")) return(x)
  x <- clean_chr(x)
  as.POSIXct(x, tz = "UTC", tryFormats = c(
    "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M",
    "%Y-%m-%dT%H:%M:%SZ", "%Y/%m/%d %H:%M:%S",
    "%Y/%m/%d %H:%M", "%Y-%m-%d", "%Y/%m/%d"
  ))
}
has_col <- function(d, nm) nm %in% names(d)
get_col <- function(d, nm) if (has_col(d, nm)) d[[nm]] else rep(NA, nrow(d))

collapse_infection <- function(x) {
  z0 <- enc2utf8(as.character(x))
  z <- tolower(trimws(z0))
  out <- rep("Other/undetermined", length(z))
  has_txt <- function(pat) grepl(pat, z, ignore.case = TRUE)
  has_fixed <- function(txt) grepl(intToUtf8(txt), z0, fixed = TRUE, useBytes = TRUE)
  out[has_txt("pulmonary|lung|respir|pneumonia") | has_fixed(c(32954))] <- "Pulmonary"
  out[has_txt("urinary|urine|uti|renal|kidney") | has_fixed(c(27852, 23615))] <- "Urinary"
  out[has_txt("abdominal|abdomen|biliary|gastro|gi|intra|periton|hepatobiliary") | has_fixed(c(33145, 33108)) | has_fixed(c(32966, 36947)) | has_fixed(c(32963, 32928))] <- "Abdominal"
  out[has_txt("bloodstream|blood stream|bacteremia|catheter") | has_fixed(c(34880, 27969))] <- "Bloodstream"
  out[has_txt("skin|soft tissue") | has_fixed(c(30382, 32932)) | has_fixed(c(36719, 32452, 32455))] <- "Skin/soft tissue"
  out[has_txt("bone|joint") | has_fixed(c(39592, 20851, 33410))] <- "Bone/joint"
  out[has_txt("central nervous|cns") | has_fixed(c(20013, 26530))] <- "Central nervous system"
  out[has_txt("endo|cardiovascular") | has_fixed(c(24515, 20869)) | has_fixed(c(24515, 34880, 31649))] <- "Endocardial/cardiovascular"
  out[has_txt("device|catheter") | has_fixed(c(23548, 31649)) | has_fixed(c(35013, 32622))] <- "Catheter/device-related"
  out[is.na(z) | z == ""] <- NA_character_
  factor(out, levels = c("Pulmonary", "Urinary", "Abdominal", "Bloodstream", "Skin/soft tissue",
                         "Bone/joint", "Central nervous system", "Endocardial/cardiovascular",
                         "Catheter/device-related", "Other/undetermined"))
}
collapse_icu_source_mimic <- function(x) {
  z <- as.character(x)
  out <- dplyr::case_when(
    z == "EMERGENCY ROOM" ~ "Emergency department",
    z %in% c("PROCEDURE SITE", "PACU") ~ "Operating theatre/procedure",
    z == "TRANSFER FROM HOSPITAL" ~ "Other hospital",
    z %in% c("PHYSICIAN REFERRAL", "WALK-IN/SELF REFERRAL", "CLINIC REFERRAL") ~ "Ward/clinic",
    TRUE ~ "Other/unknown"
  )
  factor(out, levels = c("Emergency department", "Operating theatre/procedure", "Other hospital", "Ward/clinic", "Other/unknown"))
}
collapse_icu_type_mimic <- function(x) {
  z <- as.character(x)
  out <- dplyr::case_when(
    z %in% c("Medical Intensive Care Unit (MICU)", "Medical/Surgical Intensive Care Unit (MICU/SICU)") ~ "Medical ICU",
    z %in% c("Cardiac Vascular Intensive Care Unit (CVICU)", "Coronary Care Unit (CCU)") ~ "Cardiovascular ICU",
    z %in% c("Surgical Intensive Care Unit (SICU)", "Trauma SICU (TSICU)") ~ "Surgical/trauma ICU",
    z %in% c("Neuro Surgical Intensive Care Unit (Neuro SICU)", "Surgery/Vascular/Intermediate", "Surgery/Trauma") ~ "Neuro ICU/intermediate",
    TRUE ~ "Other ICU/intermediate"
  )
  factor(out, levels = c("Medical ICU", "Cardiovascular ICU", "Surgical/trauma ICU", "Neuro ICU/intermediate", "Other ICU/intermediate"))
}
time_within_24h <- function(t, origin) {
  tt <- parse_time(t)
  h <- as.numeric(difftime(tt, origin, units = "hours"))
  ifelse(is.na(h), 0L, as.integer(h >= 0 & h <= 24))
}
event_after_24h_full <- function(t, origin) {
  tt <- parse_time(t)
  h <- as.numeric(difftime(tt, origin, units = "hours"))
  ifelse(is.na(h), 0L, as.integer(h > 24))
}
new_event_after_24h_excluding_pre24 <- function(t, origin) {
  tt <- parse_time(t)
  h <- as.numeric(difftime(tt, origin, units = "hours"))
  out <- ifelse(is.na(h), 0L, as.integer(h > 24))
  out[!is.na(h) & h <= 24] <- NA_integer_
  out
}

derive_mimic <- function(d) {
  icu_in <- parse_time(get_col(d, "icu_intime"))
  sepsis_time <- parse_time(get_col(d, "sepsis_time"))
  custom_cols <- grep("^custom_", names(d), value = TRUE)
  albumin_col <- if (length(custom_cols) >= 1) custom_cols[1] else NA_character_
  immuno_col <- if (length(custom_cols) >= 2) custom_cols[2] else NA_character_
  steroid_col <- if (length(custom_cols) >= 3) custom_cols[3] else NA_character_
  malnutrition_col <- if (length(custom_cols) >= 4) custom_cols[4] else NA_character_
  data.frame(
    id_subject = get_col(d, "subject_id"),
    id_hadm = get_col(d, "hadm_id"),
    id_stay = get_col(d, "stay_id"),
    sofa2 = to_num(get_col(d, "sofa2_dynamic24_max")),
    age = to_num(get_col(d, "age")),
    male = ifelse(as.character(get_col(d, "gender")) == "M", 1L, 0L),
    weight = to_num(get_col(d, "weight")),
    race = factor(clean_chr(get_col(d, "race"))),
    icu_admission_source = collapse_icu_source_mimic(get_col(d, "admission_location")),
    icu_type = collapse_icu_type_mimic(get_col(d, "careunit")),
    sepsis_onset_h = as.numeric(difftime(sepsis_time, icu_in, units = "hours")),
    infection_source = collapse_infection(get_col(d, "infection_site_main_enriched")),
    charlson = to_num(get_col(d, "charlson")),
    hypertension = to_bin(get_col(d, "hypertension")),
    diabetes = to_bin(get_col(d, "diabetes")),
    ckd = to_bin(get_col(d, "renal_disease")),
    chf = to_bin(get_col(d, "congestive_heart_failure")),
    myocardial_infarct = to_bin(get_col(d, "myocardial_infarct")),
    chronic_pulmonary_disease = to_bin(get_col(d, "chronic_pulmonary_disease")),
    liver_disease = as.integer(to_bin(get_col(d, "mild_liver_disease")) == 1 | to_bin(get_col(d, "severe_liver_disease")) == 1),
    cerebrovascular_disease = to_bin(get_col(d, "cerebrovascular_disease")),
    peripheral_vascular_disease = to_bin(get_col(d, "peripheral_vascular_disease")),
    dementia = to_bin(get_col(d, "dementia")),
    malignancy = as.integer(to_bin(get_col(d, "malignant_cancer")) == 1 | to_bin(get_col(d, "metastatic_solid_tumor")) == 1),
    malnutrition = if (!is.na(malnutrition_col)) to_bin(d[[malnutrition_col]]) else NA_integer_,
    immunosuppression = if (!is.na(immuno_col)) to_bin(d[[immuno_col]]) else NA_integer_,
    sofa = to_num(get_col(d, "sofa_dynamic24_max")),
    sofa2_resp = to_num(get_col(d, "sofa2_dynamic24_resp_max")),
    sofa2_cardio = to_num(get_col(d, "sofa2_dynamic24_cardio_max")),
    sofa2_renal = to_num(get_col(d, "sofa2_dynamic24_kidney_max")),
    sofa2_coag = to_num(get_col(d, "sofa2_dynamic24_hemo_max")),
    sofa2_liver = to_num(get_col(d, "sofa2_dynamic24_liver_max")),
    sofa2_neuro = to_num(get_col(d, "sofa2_dynamic24_brain_max")),
    gcs = to_num(get_col(d, "gcs")),
    sapsii = to_num(get_col(d, "sapsii")),
    apsiii = to_num(get_col(d, "apsiii")),
    heart_rate = to_num(get_col(d, "heart_rate_first")),
    mbp = to_num(get_col(d, "mbp_first")),
    sbp = to_num(get_col(d, "sbp_first")),
    resp_rate = to_num(get_col(d, "resp_rate_first")),
    temperature = to_num(get_col(d, "temperature_first")),
    spo2 = to_num(get_col(d, "spo2_first")),
    wbc = to_num(get_col(d, "wbc_first")),
    hemoglobin = to_num(get_col(d, "hemoglobin_first")),
    platelet = to_num(get_col(d, "platelet_first")),
    inr = to_num(get_col(d, "inr_first")),
    pt = to_num(get_col(d, "pt_first")),
    aptt = to_num(get_col(d, "ptt_first")),
    bun = to_num(get_col(d, "bun_first")),
    creatinine = to_num(get_col(d, "creatinine_first")),
    lactate = to_num(get_col(d, "lactate_first")),
    ph = to_num(get_col(d, "ph_first")),
    pao2 = to_num(get_col(d, "po2_first")),
    paco2 = to_num(get_col(d, "pco2_first")),
    hco3 = to_num(get_col(d, "bicarbonate_first")),
    anion_gap = to_num(get_col(d, "aniongap_first")),
    pao2fio2 = to_num(get_col(d, "pao2fio2ratio_first")),
    invasive_vent_24h = time_within_24h(get_col(d, "invasivevent_time_first_current"), icu_in),
    vasoactive_24h = time_within_24h(get_col(d, "vasoactive_first_time_current"), icu_in),
    rrt_24h = time_within_24h(get_col(d, "rrt_time_first_current"), icu_in),
    corticosteroid_24h = if (!is.na(steroid_col)) to_bin(d[[steroid_col]]) else NA_integer_,
    albumin_use_24h = if (!is.na(albumin_col)) to_bin(d[[albumin_col]]) else NA_integer_
  )
}

derive_outcomes <- function(d) {
  icu_in <- parse_time(get_col(d, "icu_intime"))
  data.frame(
    icu_28d_death = to_bin(get_col(d, "icu_28d_death")),
    icu_mortality = to_bin(get_col(d, "icu_expire_flag_outcome")),
    hospital_mortality = to_bin(get_col(d, "hospital_expire_flag_outcome")),
    mortality_90d = to_bin(get_col(d, "mortality_90_outcome")),
    mortality_365d = to_bin(get_col(d, "mortality_365_outcome")),
    new_invasive_vent_after24h = new_event_after_24h_excluding_pre24(get_col(d, "invasivevent_time_first_current"), icu_in),
    new_septic_shock_after24h = new_event_after_24h_excluding_pre24(get_col(d, "septic_shock_time_current"), icu_in),
    new_aki_after24h = new_event_after_24h_excluding_pre24(get_col(d, "aki_time_current"), icu_in),
    new_crrt_after24h = new_event_after_24h_excluding_pre24(get_col(d, "crrt_time_first_current"), icu_in),
    rrt_after24h = event_after_24h_full(get_col(d, "rrt_time_first_current"), icu_in),
    vasoactive_after24h = event_after_24h_full(get_col(d, "vasoactive_first_time_current"), icu_in)
  )
}

baseline_specs <- list(
  list(section = "Demographics and admission characteristics"),
  list(name = "Age, years", var = "age", type = "continuous", digits = 1),
  list(name = "Male sex, n (%)", var = "male", type = "binary"),
  list(name = "Body weight, kg", var = "weight", type = "continuous", digits = 1),
  list(name = "Race/ethnicity, n (%)", var = "race", type = "categorical"),
  list(name = "ICU admission source, n (%)", var = "icu_admission_source", type = "categorical"),
  list(name = "ICU type, n (%)", var = "icu_type", type = "categorical"),
  list(name = "Sepsis onset after ICU admission, h", var = "sepsis_onset_h", type = "continuous", digits = 1),
  list(name = "Infection source, n (%)", var = "infection_source", type = "categorical"),
  list(section = "Comorbidities"),
  list(name = "Charlson Comorbidity Index", var = "charlson", type = "continuous", digits = 0),
  list(name = "Hypertension, n (%)", var = "hypertension", type = "binary"),
  list(name = "Diabetes mellitus, n (%)", var = "diabetes", type = "binary"),
  list(name = "Chronic kidney disease, n (%)", var = "ckd", type = "binary"),
  list(name = "Congestive heart failure, n (%)", var = "chf", type = "binary"),
  list(name = "Myocardial infarction, n (%)", var = "myocardial_infarct", type = "binary"),
  list(name = "Chronic pulmonary disease, n (%)", var = "chronic_pulmonary_disease", type = "binary"),
  list(name = "Chronic liver disease, n (%)", var = "liver_disease", type = "binary"),
  list(name = "Cerebrovascular disease, n (%)", var = "cerebrovascular_disease", type = "binary"),
  list(name = "Peripheral vascular disease, n (%)", var = "peripheral_vascular_disease", type = "binary"),
  list(name = "Dementia, n (%)", var = "dementia", type = "binary"),
  list(name = "Malignancy, n (%)", var = "malignancy", type = "binary"),
  list(name = "Malnutrition, n (%)", var = "malnutrition", type = "binary"),
  list(name = "Immunosuppression, n (%)", var = "immunosuppression", type = "binary"),
  list(section = "Baseline severity"),
  list(name = "Traditional SOFA, 0-24 h", var = "sofa", type = "continuous", digits = 0),
  list(name = "SOFA-2, 0-24 h", var = "sofa2", type = "continuous", digits = 0),
  list(name = "SOFA-2 respiratory component", var = "sofa2_resp", type = "continuous", digits = 0),
  list(name = "SOFA-2 cardiovascular component", var = "sofa2_cardio", type = "continuous", digits = 0),
  list(name = "SOFA-2 renal component", var = "sofa2_renal", type = "continuous", digits = 0),
  list(name = "SOFA-2 coagulation component", var = "sofa2_coag", type = "continuous", digits = 0),
  list(name = "SOFA-2 liver component", var = "sofa2_liver", type = "continuous", digits = 0),
  list(name = "SOFA-2 neurological component", var = "sofa2_neuro", type = "continuous", digits = 0),
  list(name = "GCS", var = "gcs", type = "continuous", digits = 0),
  list(name = "SAPS II", var = "sapsii", type = "continuous", digits = 0),
  list(name = "APS III", var = "apsiii", type = "continuous", digits = 0),
  list(section = "Vital signs within baseline window"),
  list(name = "Heart rate, beats/min", var = "heart_rate", type = "continuous", digits = 0),
  list(name = "Mean arterial pressure, mmHg", var = "mbp", type = "continuous", digits = 0),
  list(name = "Systolic blood pressure, mmHg", var = "sbp", type = "continuous", digits = 0),
  list(name = "Respiratory rate, breaths/min", var = "resp_rate", type = "continuous", digits = 0),
  list(name = "Temperature, deg C", var = "temperature", type = "continuous", digits = 1),
  list(name = "SpO2, %", var = "spo2", type = "continuous", digits = 0),
  list(section = "Laboratory tests and blood gas"),
  list(name = "WBC, 10^9/L", var = "wbc", type = "continuous", digits = 1),
  list(name = "Hemoglobin, g/dL", var = "hemoglobin", type = "continuous", digits = 1),
  list(name = "Platelet, 10^9/L", var = "platelet", type = "continuous", digits = 0),
  list(name = "INR", var = "inr", type = "continuous", digits = 1),
  list(name = "PT, s", var = "pt", type = "continuous", digits = 1),
  list(name = "aPTT, s", var = "aptt", type = "continuous", digits = 1),
  list(name = "BUN, mg/dL", var = "bun", type = "continuous", digits = 0),
  list(name = "Creatinine, mg/dL", var = "creatinine", type = "continuous", digits = 1),
  list(name = "Lactate, mmol/L", var = "lactate", type = "continuous", digits = 1),
  list(name = "pH", var = "ph", type = "continuous", digits = 2),
  list(name = "PaO2, mmHg", var = "pao2", type = "continuous", digits = 0),
  list(name = "PaCO2, mmHg", var = "paco2", type = "continuous", digits = 0),
  list(name = "Anion gap, mmol/L", var = "anion_gap", type = "continuous", digits = 1),
  list(section = "Organ support and treatment within first 24 h"),
  list(name = "Invasive mechanical ventilation within 24 h, n (%)", var = "invasive_vent_24h", type = "binary"),
  list(name = "Vasoactive therapy within 24 h, n (%)", var = "vasoactive_24h", type = "binary"),
  list(name = "Renal replacement therapy within 24 h, n (%)", var = "rrt_24h", type = "binary"),
  list(name = "Corticosteroid use within 24 h, n (%)", var = "corticosteroid_24h", type = "binary"),
  list(name = "Albumin use within 24 h, n (%)", var = "albumin_use_24h", type = "binary")
)

outcome_specs <- list(
  list(section = "Mortality outcomes"),
  list(name = "ICU 28-day all-cause mortality, n (%)", var = "icu_28d_death", type = "binary"),
  list(name = "ICU mortality, n (%)", var = "icu_mortality", type = "binary"),
  list(name = "Hospital mortality, n (%)", var = "hospital_mortality", type = "binary"),
  list(name = "90-day mortality, n (%)", var = "mortality_90d", type = "binary"),
  list(name = "365-day mortality, n (%)", var = "mortality_365d", type = "binary"),
  list(section = "Outcomes after 24 h"),
  list(name = "New invasive ventilation after 24 h, n (%)", var = "new_invasive_vent_after24h", type = "binary"),
  list(name = "New septic shock after 24 h, n (%)", var = "new_septic_shock_after24h", type = "binary"),
  list(name = "New AKI after 24 h, n (%)", var = "new_aki_after24h", type = "binary"),
  list(name = "New CRRT after 24 h, n (%)", var = "new_crrt_after24h", type = "binary"),
  list(name = "RRT after 24 h, n (%)", var = "rrt_after24h", type = "binary"),
  list(name = "Vasoactive therapy after 24 h, n (%)", var = "vasoactive_after24h", type = "binary")
)

calc_pvalue <- function(x, g, type) {
  ok <- !is.na(x) & !is.na(g)
  if (sum(ok) == 0 || length(unique(g[ok])) < 2) return(NA_real_)
  if (type == "continuous") {
    z <- suppressWarnings(as.numeric(x[ok]))
    if (length(unique(z[!is.na(z)])) < 2) return(NA_real_)
    return(tryCatch(stats::kruskal.test(z ~ droplevels(g[ok]))$p.value, error = function(e) NA_real_))
  }
  tab <- table(x[ok], droplevels(g[ok]))
  if (nrow(tab) < 2 || ncol(tab) < 2) return(NA_real_)
  chi <- suppressWarnings(tryCatch(stats::chisq.test(tab), error = function(e) NULL))
  if (is.null(chi)) return(NA_real_)
  if (any(chi$expected < 5) && prod(dim(tab)) <= 40) {
    return(tryCatch(stats::fisher.test(tab)$p.value, error = function(e) chi$p.value))
  }
  chi$p.value
}
calc_effect <- function(x, g, type) {
  ok <- !is.na(x) & !is.na(g)
  if (sum(ok) == 0 || length(unique(g[ok])) < 2) return("")
  if (type == "continuous") {
    z <- suppressWarnings(as.numeric(x[ok]))
    kw <- tryCatch(stats::kruskal.test(z ~ droplevels(g[ok])), error = function(e) NULL)
    if (is.null(kw)) return("")
    n <- length(z)
    k <- length(unique(g[ok]))
    eps2 <- max(0, as.numeric((kw$statistic - k + 1) / (n - k)))
    return(sprintf("epsilon2=%.3f", eps2))
  }
  tab <- table(x[ok], droplevels(g[ok]))
  chi <- suppressWarnings(tryCatch(stats::chisq.test(tab, correct = FALSE), error = function(e) NULL))
  if (is.null(chi)) return("")
  n <- sum(tab)
  denom <- n * min(nrow(tab) - 1, ncol(tab) - 1)
  if (denom <= 0) return("")
  v <- sqrt(as.numeric(chi$statistic) / denom)
  sprintf("Cramer's V=%.3f", v)
}
fmt_cat_binary <- function(x, g, level = NA) {
  z <- x
  if (!is.na(level)) z <- x[g == level]
  denom <- sum(!is.na(z))
  fmt_cat(z, 1, denom)
}
fmt_cat_factor <- function(x, level) {
  denom <- sum(!is.na(x))
  fmt_cat(x, level, denom)
}
group_cont <- function(x, g, level, digits) fmt_cont(x[g == level], digits)

build_group <- function(sofa2) {
  grp <- dplyr::case_when(
    sofa2 >= 1 & sofa2 <= 5 ~ "Q1 (1-5)",
    sofa2 >= 6 & sofa2 <= 7 ~ "Q2 (6-7)",
    sofa2 >= 8 & sofa2 <= 9 ~ "Q3 (8-9)",
    sofa2 >= 10 ~ "Q4 (>=10)",
    TRUE ~ NA_character_
  )
  factor(grp, levels = c("Q1 (1-5)", "Q2 (6-7)", "Q3 (8-9)", "Q4 (>=10)"))
}

summarise_specs <- function(d, specs, title) {
  n_total <- nrow(d)
  d$sofa2_q <- build_group(d$sofa2)
  group_levels <- levels(d$sofa2_q)
  group_counts <- as.integer(table(d$sofa2_q)[group_levels])
  group_headers <- sprintf("%s\n(n=%s)", group_levels, fmt_n(group_counts))
  names(group_headers) <- group_levels
  rows <- list()
  variable_log <- list()
  for (spec in specs) {
    if (!is.null(spec$section)) {
      rows[[length(rows) + 1]] <- data.frame(
        Variable = spec$section, Missing = "", Overall = "", check.names = FALSE,
        setNames(as.list(rep("", length(group_levels))), group_levels),
        `P value` = "", `Effect size` = "", row_type = "section"
      )
      next
    }
    v <- spec$var
    if (!v %in% names(d) || all(is.na(d[[v]]))) {
      variable_log[[length(variable_log) + 1]] <- data.frame(table = title, variable = spec$name, derived_variable = v, status = "not included", reason = "missing column or complete missingness")
      next
    }
    x <- d[[v]]
    pval <- calc_pvalue(x, d$sofa2_q, spec$type)
    eff <- calc_effect(x, d$sofa2_q, spec$type)
    if (spec$type == "continuous") {
      row <- data.frame(
        Variable = spec$name,
        Missing = fmt_missing(x, n_total),
        Overall = fmt_cont(x, spec$digits),
        check.names = FALSE,
        setNames(as.list(vapply(group_levels, function(gg) group_cont(x, d$sofa2_q, gg, spec$digits), character(1))), group_levels),
        `P value` = fmt_p(pval),
        `Effect size` = eff,
        row_type = "data"
      )
      rows[[length(rows) + 1]] <- row
    } else if (spec$type == "binary") {
      row <- data.frame(
        Variable = spec$name,
        Missing = fmt_missing(x, n_total),
        Overall = fmt_cat_binary(x, d$sofa2_q, NA),
        check.names = FALSE,
        setNames(as.list(vapply(group_levels, function(gg) fmt_cat_binary(x, d$sofa2_q, gg), character(1))), group_levels),
        `P value` = fmt_p(pval),
        `Effect size` = eff,
        row_type = "data"
      )
      rows[[length(rows) + 1]] <- row
    } else if (spec$type == "categorical") {
      xf <- factor(x)
      header <- data.frame(
        Variable = spec$name,
        Missing = fmt_missing(x, n_total),
        Overall = "",
        check.names = FALSE,
        setNames(as.list(rep("", length(group_levels))), group_levels),
        `P value` = fmt_p(pval),
        `Effect size` = eff,
        row_type = "data"
      )
      rows[[length(rows) + 1]] <- header
      lvls <- names(sort(table(xf, useNA = "no"), decreasing = TRUE))
      for (lv in lvls) {
        level_row <- data.frame(
          Variable = paste0("  ", lv),
          Missing = "",
          Overall = fmt_cat_factor(xf, lv),
          check.names = FALSE,
          setNames(as.list(vapply(group_levels, function(gg) fmt_cat_factor(xf[d$sofa2_q == gg], lv), character(1))), group_levels),
          `P value` = "",
          `Effect size` = "",
          row_type = "level"
        )
        rows[[length(rows) + 1]] <- level_row
      }
    }
    variable_log[[length(variable_log) + 1]] <- data.frame(table = title, variable = spec$name, derived_variable = v, status = "included", reason = paste0("type=", spec$type))
  }
  tab <- dplyr::bind_rows(rows)
  for (gg in group_levels) names(tab)[names(tab) == gg] <- group_headers[[gg]]
  list(table = tab, variable_log = dplyr::bind_rows(variable_log), group_headers = group_headers)
}

make_ft <- function(tab, caption) {
  export_tab <- tab[, names(tab) != "row_type"]
  ft <- flextable::flextable(export_tab)
  ft <- flextable::theme_booktabs(ft)
  ft <- flextable::font(ft, fontname = "Arial", part = "all")
  ft <- flextable::fontsize(ft, size = 7.5, part = "all")
  ft <- flextable::bold(ft, i = which(tab$row_type == "section"), bold = TRUE, part = "body")
  ft <- flextable::bg(ft, i = which(tab$row_type == "section"), bg = "#D9EAF7", part = "body")
  ft <- flextable::align(ft, j = 2:ncol(export_tab), align = "center", part = "all")
  ft <- flextable::align(ft, j = 1, align = "left", part = "all")
  ft <- flextable::padding(ft, padding = 2, part = "all")
  ft <- flextable::width(ft, j = 1, width = 2.35)
  ft <- flextable::width(ft, j = 2, width = 0.85)
  ft <- flextable::width(ft, j = 3:7, width = 1.12)
  ft <- flextable::width(ft, j = 8, width = 0.68)
  ft <- flextable::width(ft, j = 9, width = 1.02)
  ft <- flextable::set_caption(ft, caption = caption)
  ft
}

write_template_files <- function(path_docx, path_yml) {
  yml <- c(
    "template_name: SOFA2_MIMIC_baseline_quartile_style",
    "data_source:",
    "  preferred: data/analysis_ready_current/MIMIC_SOFA2_analysis_master_current.rds",
    "  rationale: contains raw SOFA/SOFA-2 exposure variables, cleaned/imputed covariates, and prognosis/outcome variables",
    "grouping:",
    "  variable: sofa2_dynamic24_max",
    "  labels:",
    "    Q1: 1-5",
    "    Q2: 6-7",
    "    Q3: 8-9",
    "    Q4: '>=10'",
    "summary_format:",
    "  continuous: median [IQR]",
    "  categorical: n (%) among non-missing observations",
    "  missing: count (%) in the overall cohort",
    "statistical_tests:",
    "  continuous: Kruskal-Wallis test",
    "  categorical: Pearson chi-square or Fisher exact test when expected counts are small",
    "effect_size:",
    "  continuous: epsilon-squared from Kruskal-Wallis",
    "  categorical: Cramer's V",
    "document_style:",
    "  orientation: landscape",
    "  font: Arial",
    "  section_header_fill: '#D9EAF7'",
    "  table_theme: booktabs",
    "outcome_table:",
    "  placement: separate table after baseline characteristics",
    "  include: mortality outcomes plus protocol-defined outcomes after 24 h",
    "  new_events_after_24h: invasive ventilation, septic shock, AKI, and CRRT exclude patients with events occurring within the first 24 h",
    "  full_cohort_after_24h: RRT and vasoactive therapy are assessed after 24 h without excluding first-24-h users"
  )
  writeLines(yml, path_yml, useBytes = TRUE)
  dummy <- data.frame(
    Variable = c("Demographics and admission characteristics", "Age, years", "Male sex, n (%)"),
    Missing = c("", "0 (0.0)", "0 (0.0)"),
    Overall = c("", "76.9 [70.8-83.7]", "6,921 (54.7)"),
    `Q1 (1-5)\n(n=3,693)` = c("", "76.9 [70.7-84.0]", "1,897 (51.4)"),
    `Q2 (6-7)\n(n=3,603)` = c("", "77.1 [71.1-83.9]", "1,948 (54.1)"),
    `Q3 (8-9)\n(n=2,934)` = c("", "77.2 [71.0-84.2]", "1,672 (57.0)"),
    `Q4 (>=10)\n(n=2,413)` = c("", "76.2 [70.1-82.7]", "1,404 (58.1)"),
    `P value` = c("", "<0.001", "<0.001"),
    `Effect size` = c("", "epsilon2=0.002", "Cramer's V=0.052"),
    row_type = c("section", "data", "data"),
    check.names = FALSE
  )
  doc <- officer::read_docx()
  sec <- officer::prop_section(page_size = officer::page_size(orient = "landscape"), page_margins = officer::page_mar(top = 0.5, bottom = 0.5, left = 0.45, right = 0.45))
  doc <- officer::body_set_default_section(doc, value = sec)
  doc <- officer::body_add_par(doc, "Reusable table style template: SOFA-2 quartile baseline table", style = "heading 1")
  doc <- officer::body_add_par(doc, "Use this style for manuscript baseline and outcome summary tables. Replace example rows with analysis output; keep columns, notes, and statistical conventions unchanged unless the protocol is amended.", style = "Normal")
  doc <- flextable::body_add_flextable(doc, make_ft(dummy, "Template table. Baseline characteristics according to SOFA-2 quartiles"))
  doc <- officer::body_add_par(doc, "Notes. Values are median [interquartile range] or n (%). Continuous variables are compared using the Kruskal-Wallis test; categorical variables are compared using the chi-square or Fisher exact test. Effect sizes are epsilon-squared for continuous variables and Cramer's V for categorical variables.", style = "Normal")
  tmp <- file.path(tempdir(), basename(path_docx))
  print(doc, target = tmp)
  file.copy(tmp, path_docx, overwrite = TRUE)
}

raw <- readRDS(data_path)
baseline_dat <- derive_mimic(raw)
outcome_dat <- derive_outcomes(raw)
analysis_dat <- cbind(baseline_dat, outcome_dat)

baseline_res <- summarise_specs(analysis_dat, baseline_specs, "Baseline characteristics")
outcome_res <- summarise_specs(analysis_dat, outcome_specs, "Outcome summary")

baseline_tab <- baseline_res$table[, names(baseline_res$table) != "row_type"]
outcome_tab <- outcome_res$table[, names(outcome_res$table) != "row_type"]

csv_baseline <- file.path(out_dir, "Table1_MIMIC_baseline_characteristics_SOFA2_quartiles_updated.csv")
csv_outcome <- file.path(out_dir, "Table1B_MIMIC_outcomes_by_SOFA2_quartiles_updated.csv")
xlsx_path <- file.path(out_dir, "Table1_MIMIC_baseline_and_outcomes_SOFA2_quartiles_updated.xlsx")
docx_path <- file.path(out_dir, "Table1_MIMIC_baseline_and_outcomes_SOFA2_quartiles_updated.docx")
template_docx <- file.path(out_dir, "SOFA2_baseline_table_template_style.docx")
template_yml <- file.path(out_dir, "SOFA2_baseline_table_template_style.yml")

utils::write.csv(baseline_tab, csv_baseline, row.names = FALSE, fileEncoding = "UTF-8")
utils::write.csv(outcome_tab, csv_outcome, row.names = FALSE, fileEncoding = "UTF-8")
utils::write.csv(dplyr::bind_rows(baseline_res$variable_log, outcome_res$variable_log), file.path(out_dir, "Table1_MIMIC_variable_log_updated.csv"), row.names = FALSE, fileEncoding = "UTF-8")

q_counts <- as.data.frame(table(build_group(baseline_dat$sofa2)), stringsAsFactors = FALSE)
names(q_counts) <- c("SOFA2_quartile_group", "n")
quality <- data.frame(
  item = c("data_source", "source_rows", "analysis_rows", "sofa2_min", "sofa2_max", "sofa2_missing", "sofa2_zero", "grouping_rule", "outcome_table_rule"),
  value = c(data_path, nrow(raw), nrow(analysis_dat), min(baseline_dat$sofa2, na.rm = TRUE), max(baseline_dat$sofa2, na.rm = TRUE), sum(is.na(baseline_dat$sofa2)), sum(baseline_dat$sofa2 == 0, na.rm = TRUE), "MIMIC SOFA-2 quartiles: Q1 1-5, Q2 6-7, Q3 8-9, Q4 >=10", "Outcomes listed separately; new invasive ventilation, septic shock, AKI, and CRRT after 24 h exclude events occurring within 24 h; RRT and vasoactive therapy after 24 h use the full cohort."),
  stringsAsFactors = FALSE
)
utils::write.csv(quality, file.path(out_dir, "Table1_MIMIC_data_quality_log_updated.csv"), row.names = FALSE, fileEncoding = "UTF-8")
utils::write.csv(q_counts, file.path(out_dir, "Table1_MIMIC_SOFA2_quartile_counts_updated.csv"), row.names = FALSE, fileEncoding = "UTF-8")

wb <- openxlsx::createWorkbook()
openxlsx::addWorksheet(wb, "Baseline characteristics")
openxlsx::writeData(wb, "Baseline characteristics", baseline_tab)
openxlsx::addWorksheet(wb, "Outcomes")
openxlsx::writeData(wb, "Outcomes", outcome_tab)
openxlsx::addWorksheet(wb, "SOFA2 group counts")
openxlsx::writeData(wb, "SOFA2 group counts", q_counts)
openxlsx::addWorksheet(wb, "Data quality")
openxlsx::writeData(wb, "Data quality", quality)
openxlsx::addWorksheet(wb, "Variable log")
openxlsx::writeData(wb, "Variable log", dplyr::bind_rows(baseline_res$variable_log, outcome_res$variable_log))
for (sh in names(wb)) {
  openxlsx::freezePane(wb, sh, firstRow = TRUE)
  openxlsx::setColWidths(wb, sh, cols = 1:20, widths = "auto")
}
openxlsx::saveWorkbook(wb, xlsx_path, overwrite = TRUE)

ft_baseline <- make_ft(baseline_res$table, "Table 1A. Baseline characteristics according to quartiles of SOFA-2 score within the first 24 hours in MIMIC-IV")
ft_outcome <- make_ft(outcome_res$table, "Table 1B. Clinical outcomes according to quartiles of SOFA-2 score within the first 24 hours in MIMIC-IV")

doc <- officer::read_docx()
sec <- officer::prop_section(page_size = officer::page_size(orient = "landscape"), page_margins = officer::page_mar(top = 0.5, bottom = 0.5, left = 0.45, right = 0.45))
doc <- officer::body_set_default_section(doc, value = sec)
doc <- officer::body_add_par(doc, "Table 1. MIMIC-IV baseline characteristics and clinical outcomes by SOFA-2 quartiles", style = "heading 1")
doc <- officer::body_add_par(doc, "Data source: analysis-ready current MIMIC master table with raw SOFA/SOFA-2 exposure variables, cleaned/imputed covariates, and unchanged outcome definitions.", style = "Normal")
doc <- flextable::body_add_flextable(doc, ft_baseline)
doc <- officer::body_add_par(doc, "", style = "Normal")
doc <- flextable::body_add_flextable(doc, ft_outcome)
notes <- paste(
  "Notes. Values are median [interquartile range] or n (%). Missing indicates missing count and percentage in the overall cohort after applying the current analysis-ready table; for new events after 24 h, entries marked missing represent patients excluded from that specific risk set because the event had already occurred within the first 24 h. ",
  "Continuous variables were compared using the Kruskal-Wallis test and summarized with epsilon-squared effect size; categorical variables were compared using the chi-square or Fisher exact test when expected counts were small and summarized with Cramer's V. ",
  "SOFA-2 groups were the MIMIC cohort quartile groups used in the protocol: Q1 1-5, Q2 6-7, Q3 8-9, and Q4 >=10. Outcomes were summarized as a separate table. New invasive ventilation, septic shock, AKI, and CRRT after 24 h were calculated after excluding patients with the corresponding event within the first 24 h; RRT after 24 h and vasoactive therapy after 24 h were assessed in the full cohort."
)
doc <- officer::body_add_par(doc, notes, style = "Normal")
tmp_docx <- file.path(tempdir(), basename(docx_path))
print(doc, target = tmp_docx)
file.copy(tmp_docx, docx_path, overwrite = TRUE)

write_template_files(template_docx, template_yml)

if (file.exists(manifest_path)) {
  manifest <- utils::read.csv(manifest_path, stringsAsFactors = FALSE, check.names = FALSE)
  src_row <- manifest[manifest$cohort == "MIMIC" & manifest$file_type == "rds", , drop = FALSE]
  if (nrow(src_row) == 0) {
    src_row <- manifest[basename(manifest$path) == basename(data_path), , drop = FALSE]
  }
} else {
  src_row <- data.frame()
}
out_manifest <- data.frame(
  artifact = c("baseline_csv", "outcome_csv", "combined_xlsx", "combined_docx", "template_docx", "template_yml", "data_quality_log", "quartile_counts"),
  path = c(csv_baseline, csv_outcome, xlsx_path, docx_path, template_docx, template_yml, file.path(out_dir, "Table1_MIMIC_data_quality_log_updated.csv"), file.path(out_dir, "Table1_MIMIC_SOFA2_quartile_counts_updated.csv")),
  source_data = data_path,
  source_sha256 = if (nrow(src_row) > 0) src_row$sha256[1] else NA_character_,
  rows = c(nrow(baseline_tab), nrow(outcome_tab), NA, NA, NA, NA, nrow(quality), nrow(q_counts)),
  stringsAsFactors = FALSE
)
utils::write.csv(out_manifest, file.path(out_dir, "Table1_MIMIC_updated_output_manifest.csv"), row.names = FALSE, fileEncoding = "UTF-8")

message("Updated MIMIC baseline table completed: ", out_dir)

