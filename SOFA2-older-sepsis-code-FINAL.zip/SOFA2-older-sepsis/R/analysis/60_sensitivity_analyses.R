suppressPackageStartupMessages({
  library(survival)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(ggplot2)
  library(mice)
  library(lcmm)
})

set.seed(20260624)

project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
obj_file <- file.path(project_root, "outputs", "internal_part4_cutoff_trajectory_subgroup_sensitivity", "models", "Part4_cutoff_trajectory_subgroup_sensitivity_objects.rds")
master_file <- file.path(project_root, "data", "analysis_ready_current", "MIMIC_SOFA2_analysis_master_current.rds")
out_dir <- file.path(project_root, "outputs", "manuscript_sensitivity_mimic")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

obj <- readRDS(obj_file)
ana <- obj$ana
master <- readRDS(master_file)
td0 <- obj$trajectory_data

fmt_p <- function(p) {
  ifelse(is.na(p), NA_character_, ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
}

extract_sofa2 <- function(fit, model, n, events, term = "sofa2") {
  ss <- summary(fit)
  tibble(
    analysis = "Baseline SOFA2 sensitivity",
    model = model,
    term = term,
    n = n,
    events = events,
    HR = ss$conf.int[term, "exp(coef)"],
    lower95 = ss$conf.int[term, "lower .95"],
    upper95 = ss$conf.int[term, "upper .95"],
    p = ss$coefficients[term, "Pr(>|z|)"],
    HR_95CI = sprintf("%.2f (%.2f-%.2f)", HR, lower95, upper95),
    p_text = fmt_p(p)
  )
}

extract_terms <- function(fit, model, n, events, term_pattern = "^trajectory") {
  ss <- summary(fit)
  terms <- rownames(ss$coefficients)
  keep <- grep(term_pattern, terms, value = TRUE)
  if (length(keep) == 0) return(tibble())
  tibble(
    analysis = model,
    term = keep,
    n = n,
    events = events,
    HR = ss$conf.int[keep, "exp(coef)"],
    lower95 = ss$conf.int[keep, "lower .95"],
    upper95 = ss$conf.int[keep, "upper .95"],
    p = ss$coefficients[keep, "Pr(>|z|)"],
    HR_95CI = sprintf("%.2f (%.2f-%.2f)", HR, lower95, upper95),
    p_text = fmt_p(p)
  )
}

cox_primary <- Surv(time28, event28) ~ sofa2 + age_m + male + charlson_m +
  infection_source_m + sepsis_onset_h + icu_admission_source_m + icu_type_m +
  lactate_imp + lactate_missing

cox_complete <- Surv(time28, event28) ~ sofa2 + age_m + male + charlson_m +
  infection_source_m + sepsis_onset_h + icu_admission_source_m + icu_type_m +
  lactate

## 2-4. Baseline SOFA2 sensitivity analyses
baseline_rows <- list()

cc_primary <- complete.cases(ana[, all.vars(cox_primary)[-1], drop = FALSE]) & ana$time28 > 0
fit_primary <- coxph(cox_primary, data = ana[cc_primary, ], ties = "efron")
baseline_rows[["primary"]] <- extract_sofa2(fit_primary, "Primary adjusted model: project lactate imputation + missingness indicator",
                                            sum(cc_primary), sum(ana$event28[cc_primary] == 1))

cc_lactate <- complete.cases(ana[, c("time28", "event28", "sofa2", "age_m", "male", "charlson_m",
                                     "infection_source_m", "sepsis_onset_h", "icu_admission_source_m",
                                     "icu_type_m", "lactate"), drop = FALSE]) & ana$time28 > 0
fit_cc <- coxph(cox_complete, data = ana[cc_lactate, ], ties = "efron")
baseline_rows[["complete_case"]] <- extract_sofa2(fit_cc, "Complete-case analysis using observed lactate",
                                                  sum(cc_lactate), sum(ana$event28[cc_lactate] == 1))

mice_vars <- c("time28", "event28", "sofa2", "age_m", "male", "charlson_m",
               "infection_source_m", "sepsis_onset_h", "icu_admission_source_m", "icu_type_m", "lactate")
mice_data <- ana[, mice_vars]
mice_data$male <- factor(mice_data$male, levels = c(0, 1), labels = c("Female", "Male"))
pred <- make.predictorMatrix(mice_data)
pred[,] <- 0
pred["lactate", c("time28", "event28", "sofa2", "age_m", "male", "charlson_m",
                  "infection_source_m", "sepsis_onset_h", "icu_admission_source_m", "icu_type_m")] <- 1
meth <- make.method(mice_data)
meth[] <- ""
meth["lactate"] <- "pmm"
imp <- mice(mice_data, m = 5, maxit = 10, method = meth, predictorMatrix = pred,
            seed = 20260624, printFlag = FALSE)
mice_fit <- with(imp, coxph(Surv(time28, event28) ~ sofa2 + age_m + male + charlson_m +
                              infection_source_m + sepsis_onset_h + icu_admission_source_m +
                              icu_type_m + lactate, ties = "efron"))
mice_pool <- pool(mice_fit)
mice_sum <- summary(mice_pool, exponentiate = TRUE, conf.int = TRUE)
mice_sofa <- mice_sum[mice_sum$term == "sofa2", ]
baseline_rows[["mice"]] <- tibble(
  analysis = "Baseline SOFA2 sensitivity",
  model = "MICE imputation of lactate covariate (m=5, predictive mean matching)",
  term = "sofa2",
  n = nrow(mice_data),
  events = sum(mice_data$event28 == 1),
  HR = mice_sofa$estimate,
  lower95 = mice_sofa$`2.5 %`,
  upper95 = mice_sofa$`97.5 %`,
  p = mice_sofa$p.value,
  HR_95CI = sprintf("%.2f (%.2f-%.2f)", HR, lower95, upper95),
  p_text = fmt_p(p)
)

within24 <- cc_primary & ana$sepsis_onset_h <= 24
fit_24 <- coxph(cox_primary, data = ana[within24, ], ties = "efron")
baseline_rows[["within24"]] <- extract_sofa2(fit_24, "Excluding sepsis onset 24-48 h after ICU admission",
                                             sum(within24), sum(ana$event28[within24] == 1))

baseline_sensitivity <- bind_rows(baseline_rows)
write_csv(baseline_sensitivity, file.path(out_dir, "TableS_MIMIC_baseline_SOFA2_sensitivity_Cox.csv"))

mice_diag <- tibble(
  variable = names(mice_data),
  missing = sapply(mice_data, function(x) sum(is.na(x))),
  missing_percent = round(100 * missing / nrow(mice_data), 1)
)
write_csv(mice_diag, file.path(out_dir, "MICE_missingness_diagnostics.csv"))

## Helpers for trajectory analyses
traj_covars <- c("age_m", "male", "charlson_m", "infection_source_m", "sepsis_onset_h",
                 "icu_admission_source_m", "icu_type_m", "lactate_imp", "lactate_missing")
traj_formula <- as.formula(paste("Surv(time28, event28) ~ trajectory_class +",
                                 paste(traj_covars, collapse = " + ")))

order_kmeans_classes <- function(km, mat, prefix = "Class") {
  cl <- km$cluster
  raw_centers <- aggregate(mat, by = list(cluster = cl), FUN = mean)
  raw_centers$mean_sofa2 <- rowMeans(raw_centers[, colnames(mat), drop = FALSE])
  ord <- raw_centers$cluster[order(raw_centers$mean_sofa2)]
  labels <- setNames(paste(prefix, seq_along(ord)), ord)
  factor(labels[as.character(cl)], levels = paste(prefix, seq_along(ord)))
}

fit_traj_cox <- function(dat, label) {
  dat <- dat %>% mutate(trajectory_class = droplevels(factor(trajectory_class)))
  fit <- coxph(traj_formula, data = dat, ties = "efron")
  extract_terms(fit, label, nrow(dat), sum(dat$event28 == 1), "^trajectory_class")
}

## 5. K-means 3/4/5 comparison
mat_raw <- as.matrix(td0[, c("sofa2_d1", "sofa2_d2", "sofa2_d3")])
mat_scaled <- scale(mat_raw)
kmeans_models <- list()
kmeans_summary <- list()
kmeans_centers <- list()
kmeans_cox <- list()

for (k in 3:5) {
  km <- kmeans(mat_scaled, centers = k, nstart = 100, iter.max = 100)
  cls <- order_kmeans_classes(km, as.data.frame(mat_raw), prefix = paste0("K", k, " class"))
  dat_k <- td0 %>% mutate(trajectory_class = cls)
  kmeans_models[[as.character(k)]] <- km
  kmeans_summary[[as.character(k)]] <- dat_k %>%
    group_by(trajectory_class) %>%
    summarise(
      k = k,
      n = n(),
      events = sum(event28 == 1),
      mortality = events / n,
      mean_d1 = mean(sofa2_d1),
      mean_d2 = mean(sofa2_d2),
      mean_d3 = mean(sofa2_d3),
      .groups = "drop"
    )
  kmeans_centers[[as.character(k)]] <- dat_k %>%
    group_by(trajectory_class) %>%
    summarise(k = k, mean_d1 = mean(sofa2_d1), mean_d2 = mean(sofa2_d2), mean_d3 = mean(sofa2_d3), .groups = "drop")
  kmeans_cox[[as.character(k)]] <- fit_traj_cox(dat_k, paste0("K-means ", k, "-class trajectory"))
}

kmeans_model_compare <- bind_rows(lapply(3:5, function(k) {
  km <- kmeans_models[[as.character(k)]]
  tibble(
    method = "K-means",
    k = k,
    n = nrow(td0),
    total_withinss = km$tot.withinss,
    between_total_ratio = km$betweenss / km$totss,
    min_class_n = min(km$size),
    max_class_n = max(km$size)
  )
}))

write_csv(kmeans_model_compare, file.path(out_dir, "TableS_trajectory_kmeans_3_4_5_model_comparison.csv"))
write_csv(bind_rows(kmeans_summary), file.path(out_dir, "TableS_trajectory_kmeans_3_4_5_group_summary.csv"))
write_csv(bind_rows(kmeans_centers), file.path(out_dir, "TableS_trajectory_kmeans_3_4_5_centers.csv"))
write_csv(bind_rows(kmeans_cox), file.path(out_dir, "TableS_trajectory_kmeans_3_4_5_Cox.csv"))

## 6. LCMM repeated modeling
long_lcmm <- td0 %>%
  select(stay_id, sofa2_d1, sofa2_d2, sofa2_d3) %>%
  pivot_longer(cols = starts_with("sofa2_d"), names_to = "day", values_to = "sofa2_value") %>%
  mutate(day_num = as.numeric(gsub("sofa2_d", "", day)) - 1)
lcmm_sample_ids <- sample(unique(long_lcmm$stay_id), size = min(3000, length(unique(long_lcmm$stay_id))))
long_lcmm <- long_lcmm %>% filter(stay_id %in% lcmm_sample_ids)

lcmm_compare <- list()
lcmm_classes <- list()
lcmm_errors <- list()
m1 <- tryCatch(
  hlme(fixed = sofa2_value ~ day_num + I(day_num^2), random = ~ 1,
       subject = "stay_id", data = long_lcmm, ng = 1, verbose = FALSE),
  error = function(e) e
)

if (inherits(m1, "error")) {
  lcmm_errors[["ng1"]] <- tibble(ng = 1, error = conditionMessage(m1))
} else {
  lcmm_compare[["1"]] <- tibble(method = "LCMM hlme", ng = 1, loglik = m1$loglik, AIC = m1$AIC, BIC = m1$BIC, conv = m1$conv)
  for (ng in 3:5) {
    fit_ng <- tryCatch(
      hlme(fixed = sofa2_value ~ day_num + I(day_num^2),
           mixture = ~ day_num + I(day_num^2),
           random = ~ 1,
           subject = "stay_id", data = long_lcmm, ng = ng,
           nwg = TRUE, B = random(m1), maxiter = 30, verbose = FALSE),
      error = function(e) e
    )
    if (inherits(fit_ng, "error")) {
      lcmm_errors[[as.character(ng)]] <- tibble(ng = ng, error = conditionMessage(fit_ng))
    } else {
      pp <- fit_ng$pprob
      lcmm_compare[[as.character(ng)]] <- tibble(method = "LCMM hlme", ng = ng, loglik = fit_ng$loglik, AIC = fit_ng$AIC, BIC = fit_ng$BIC, conv = fit_ng$conv,
                                                 mean_max_posterior = mean(apply(pp[, grep("^prob", names(pp)), drop = FALSE], 1, max)))
      id_col <- intersect(c("id", "stay_id", "ID", "subject"), names(pp))[1]
      if (is.na(id_col)) id_col <- names(pp)[1]
      class_col <- intersect(c("class", "Class", "pred_class"), names(pp))[1]
      if (is.na(class_col)) class_col <- names(pp)[grep("class", names(pp), ignore.case = TRUE)[1]]
      tmp_pp <- pp
      names(tmp_pp)[names(tmp_pp) == id_col] <- "stay_id"
      names(tmp_pp)[names(tmp_pp) == class_col] <- "lcmm_class"
      lcmm_classes[[as.character(ng)]] <- tmp_pp %>%
        select(stay_id, lcmm_class, starts_with("prob"))
    }
  }
}
write_csv(bind_rows(lcmm_compare), file.path(out_dir, "TableS_LCMM_3_4_5_model_comparison.csv"))
write_csv(bind_rows(lcmm_errors), file.path(out_dir, "LCMM_errors_if_any.csv"))
if (length(lcmm_classes) > 0) {
  write_csv(bind_rows(lapply(names(lcmm_classes), function(ng) mutate(lcmm_classes[[ng]], ng = as.integer(ng)))),
            file.path(out_dir, "TableS_LCMM_posterior_classes.csv"))
}

## 7. 72 h landmark analysis
td_landmark <- td0 %>% filter(time28 > 3) %>%
  mutate(time_landmark = time28 - 3,
         event_landmark = event28)
fit_landmark <- coxph(Surv(time_landmark, event_landmark) ~ trajectory_class +
                        age_m + male + charlson_m + infection_source_m + sepsis_onset_h +
                        icu_admission_source_m + icu_type_m + lactate_imp + lactate_missing,
                      data = td_landmark, ties = "efron")
landmark_results <- extract_terms(fit_landmark, "72 h landmark trajectory Cox", nrow(td_landmark),
                                  sum(td_landmark$event_landmark == 1), "^trajectory_class")
write_csv(landmark_results, file.path(out_dir, "TableS_72h_landmark_trajectory_Cox.csv"))

## 8. Posterior probability weighted analysis from distance-derived soft posterior probabilities
centers_scaled <- obj$kmeans_k4$centers
dist2 <- sapply(seq_len(nrow(centers_scaled)), function(i) rowSums((sweep(mat_scaled, 2, centers_scaled[i, ], "-"))^2))
tau <- median(apply(dist2, 1, function(x) sort(x)[2] - sort(x)[1]))
tau <- ifelse(is.finite(tau) && tau > 0, tau, 1)
prob_raw <- exp(-dist2 / tau)
prob <- prob_raw / rowSums(prob_raw)
raw_to_label <- td0 %>% distinct(trajectory_raw, trajectory_class) %>% arrange(trajectory_raw)
colnames(prob) <- as.character(raw_to_label$trajectory_class[match(seq_len(ncol(prob)), raw_to_label$trajectory_raw)])
posterior_qc <- tibble(
  stay_id = td0$stay_id,
  assigned_class = as.character(td0$trajectory_class),
  max_distance_posterior = apply(prob, 1, max),
  assigned_distance_posterior = prob[cbind(seq_len(nrow(prob)), match(as.character(td0$trajectory_class), colnames(prob)))]
)
write_csv(posterior_qc, file.path(out_dir, "TableS_distance_derived_posterior_probability_QC.csv"))

pseudo <- bind_rows(lapply(colnames(prob), function(cls) {
  td0 %>%
    mutate(trajectory_class = factor(cls, levels = levels(td0$trajectory_class)),
           posterior_weight = prob[, cls])
})) %>% filter(posterior_weight > 1e-6)

fit_weighted <- coxph(Surv(time28, event28) ~ trajectory_class +
                        age_m + male + charlson_m + infection_source_m + sepsis_onset_h +
                        icu_admission_source_m + icu_type_m + lactate_imp + lactate_missing +
                        cluster(stay_id),
                      data = pseudo, weights = posterior_weight, ties = "efron")
weighted_results <- extract_terms(fit_weighted, "Posterior probability weighted trajectory Cox (distance-derived K-means probabilities)",
                                  nrow(td0), sum(td0$event28 == 1), "^trajectory_class")
write_csv(weighted_results, file.path(out_dir, "TableS_posterior_probability_weighted_trajectory_Cox.csv"))

## 9. Post-ICU LOCF vs zero comparison for day 1-3 trajectory values
td_locf <- td0 %>% left_join(master %>% select(stay_id, los_icu), by = "stay_id")
td_zero <- td_locf
td_locf <- td_locf %>%
  mutate(
    sofa2_d2_locf = ifelse(los_icu < 2 & sofa2_d2 == 0, sofa2_d1, sofa2_d2),
    sofa2_d3_locf = ifelse(los_icu < 3 & sofa2_d3 == 0, ifelse(los_icu < 2, sofa2_d1, sofa2_d2), sofa2_d3)
  )
mat_locf <- as.matrix(td_locf[, c("sofa2_d1", "sofa2_d2_locf", "sofa2_d3_locf")])
colnames(mat_locf) <- c("sofa2_d1", "sofa2_d2", "sofa2_d3")
km_locf <- kmeans(scale(mat_locf), centers = 4, nstart = 100, iter.max = 100)
td_locf$trajectory_class <- order_kmeans_classes(km_locf, as.data.frame(mat_locf), prefix = "LOCF class")
locf_results <- fit_traj_cox(td_locf, "K-means trajectory using post-ICU LOCF")

km_zero <- kmeans(scale(mat_raw), centers = 4, nstart = 100, iter.max = 100)
td_zero$trajectory_class <- order_kmeans_classes(km_zero, as.data.frame(mat_raw), prefix = "Zero class")
zero_results <- fit_traj_cox(td_zero, "K-means trajectory using post-ICU values set to 0")

locf_zero_compare <- bind_rows(
  td_zero %>% group_by(trajectory_class) %>% summarise(strategy = "Set post-ICU values to 0", n = n(), events = sum(event28 == 1), mortality = events / n,
                                                       mean_d1 = mean(sofa2_d1), mean_d2 = mean(sofa2_d2), mean_d3 = mean(sofa2_d3), .groups = "drop"),
  td_locf %>% group_by(trajectory_class) %>% summarise(strategy = "Post-ICU LOCF", n = n(), events = sum(event28 == 1), mortality = events / n,
                                                       mean_d1 = mean(sofa2_d1), mean_d2 = mean(sofa2_d2_locf), mean_d3 = mean(sofa2_d3_locf), .groups = "drop")
)
write_csv(locf_zero_compare, file.path(out_dir, "TableS_LOCF_vs_zero_trajectory_group_summary.csv"))
write_csv(bind_rows(zero_results, locf_results), file.path(out_dir, "TableS_LOCF_vs_zero_trajectory_Cox.csv"))

## 10. Incremental value of baseline SOFA2 vs trajectory classes
inc_data <- td0
fit_clinical <- coxph(Surv(time28, event28) ~ age_m + male + charlson_m + infection_source_m +
                        sepsis_onset_h + icu_admission_source_m + icu_type_m + lactate_imp + lactate_missing,
                      data = inc_data, ties = "efron")
fit_base_sofa2 <- update(fit_clinical, . ~ . + sofa2)
fit_traj_only <- update(fit_clinical, . ~ . + trajectory_class)
fit_combined <- update(fit_clinical, . ~ . + sofa2 + trajectory_class)

model_metric <- function(fit, model) {
  ss <- summary(fit)
  tibble(
    model = model,
    n = fit$n,
    events = fit$nevent,
    logLik = as.numeric(logLik(fit)),
    AIC = AIC(fit),
    concordance = unname(ss$concordance[1]),
    concordance_se = unname(ss$concordance[2])
  )
}

incremental_metrics <- bind_rows(
  model_metric(fit_clinical, "Clinical covariates only"),
  model_metric(fit_base_sofa2, "Clinical covariates + baseline SOFA2"),
  model_metric(fit_traj_only, "Clinical covariates + trajectory class"),
  model_metric(fit_combined, "Clinical covariates + baseline SOFA2 + trajectory class")
)
incremental_tests <- bind_rows(
  tibble(comparison = "Add baseline SOFA2 to clinical covariates", df = anova(fit_clinical, fit_base_sofa2, test = "LRT")$Df[2],
         chisq = anova(fit_clinical, fit_base_sofa2, test = "LRT")$Chisq[2],
         p = anova(fit_clinical, fit_base_sofa2, test = "LRT")$`Pr(>|Chi|)`[2]),
  tibble(comparison = "Add trajectory class to clinical covariates", df = anova(fit_clinical, fit_traj_only, test = "LRT")$Df[2],
         chisq = anova(fit_clinical, fit_traj_only, test = "LRT")$Chisq[2],
         p = anova(fit_clinical, fit_traj_only, test = "LRT")$`Pr(>|Chi|)`[2]),
  tibble(comparison = "Add trajectory class beyond clinical covariates + baseline SOFA2", df = anova(fit_base_sofa2, fit_combined, test = "LRT")$Df[2],
         chisq = anova(fit_base_sofa2, fit_combined, test = "LRT")$Chisq[2],
         p = anova(fit_base_sofa2, fit_combined, test = "LRT")$`Pr(>|Chi|)`[2]),
  tibble(comparison = "Add baseline SOFA2 beyond clinical covariates + trajectory class", df = anova(fit_traj_only, fit_combined, test = "LRT")$Df[2],
         chisq = anova(fit_traj_only, fit_combined, test = "LRT")$Chisq[2],
         p = anova(fit_traj_only, fit_combined, test = "LRT")$`Pr(>|Chi|)`[2])
) %>% mutate(p_text = fmt_p(p))

write_csv(incremental_metrics, file.path(out_dir, "TableS_incremental_value_model_metrics.csv"))
write_csv(incremental_tests, file.path(out_dir, "TableS_incremental_value_likelihood_ratio_tests.csv"))

qc <- tibble(
  item = c("MIMIC master N", "Part4 analysis N", "Trajectory complete day1-3 N", "Primary adjusted model N",
           "Complete-case observed lactate N", "Sepsis onset <=24 h N", "72 h landmark N",
           "MICE imputations", "MICE max iterations", "Distance posterior mean assigned probability",
           "LCMM random subsample N"),
  value = c(nrow(master), nrow(ana), nrow(td0), sum(cc_primary), sum(cc_lactate), sum(within24),
            nrow(td_landmark), 5, 10, round(mean(posterior_qc$assigned_distance_posterior), 3),
            length(lcmm_sample_ids))
)
write_csv(qc, file.path(out_dir, "MIMIC_sensitivity_QC.csv"))

summary_text <- c(
  "MIMIC sensitivity analyses were generated from the current cleaned MIMIC master and existing Part4 trajectory object.",
  "Baseline SOFA2 sensitivity analyses include complete-case observed lactate, MICE lactate imputation, and exclusion of sepsis onset 24-48 h after ICU admission.",
"Trajectory sensitivity analyses include K-means 3/4/5-class comparison, LCMM repeated modeling on a fixed random computational subsample, 72 h landmark analysis, distance-derived posterior probability weighting, post-ICU LOCF vs zero handling, and incremental value of baseline SOFA2 vs trajectory class.",
  "For K-means, posterior probabilities are distance-derived soft assignments rather than model-based latent-class posterior probabilities."
)
writeLines(summary_text, file.path(out_dir, "MIMIC_sensitivity_methods_results_notes.txt"))

cat("Done\n")
cat("Output directory:", out_dir, "\n")
print(qc)
print(baseline_sensitivity)
print(kmeans_model_compare)
print(incremental_metrics)
print(incremental_tests)

