set.seed(2026)

project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
input_path <- file.path(project_root, "data", "processed", "SOFA2_latest_sofa_with_outcomes.rds")
out_dir <- file.path(project_root, "outputs", "internal_part1_severity_logistic_rcs")
table_dir <- file.path(out_dir, "tables")
figure_dir <- file.path(out_dir, "figures")
model_dir <- file.path(out_dir, "models")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(model_dir, recursive = TRUE, showWarnings = FALSE)

required_packages <- c("dplyr", "ggplot2", "splines", "broom", "sandwich", "lmtest", "digest", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

d0 <- readRDS(input_path)

parse_time <- function(x) {
  if (inherits(x, "POSIXct")) return(x)
  x <- as.character(x)
  x[trimws(x) %in% c("", "NA", "NaN", "NULL", "NaT")] <- NA_character_
  as.POSIXct(x, tz = "UTC", tryFormats = c(
    "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M",
    "%Y-%m-%dT%H:%M:%SZ", "%Y/%m/%d %H:%M:%S",
    "%Y/%m/%d %H:%M", "%Y-%m-%d", "%Y/%m/%d"
  ))
}

to_binary <- function(x) {
  if (is.numeric(x) || is.integer(x)) return(as.integer(x > 0))
  z <- tolower(trimws(as.character(x)))
  as.integer(z %in% c("1", "yes", "y", "true", "t"))
}

mode_level <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) == 0) return(NA_character_)
  names(sort(table(x), decreasing = TRUE))[1]
}

collapse_source <- function(x) {
  z <- tolower(trimws(enc2utf8(as.character(x))))
  out <- rep("Other/undetermined", length(z))
  out[grepl("pulmonary|lung|respir|pneumonia|肺", z)] <- "Pulmonary"
  out[grepl("urinary|urine|uti|renal|kidney|泌尿", z)] <- "Urinary"
  out[grepl("abdominal|abdomen|biliary|gastro|gi|intra|periton|腹腔|胆道|胃肠", z)] <- "Abdominal"
  out[is.na(z) | z == ""] <- "Other/undetermined"
  factor(out, levels = c("Pulmonary", "Urinary", "Abdominal", "Other/undetermined"))
}

new_after_24 <- function(event_time, icu_time) {
  h <- as.numeric(difftime(event_time, icu_time, units = "hours"))
  eligible <- is.na(h) | h > 24
  outcome <- as.integer(!is.na(h) & h > 24)
  list(outcome = outcome, eligible = eligible, hours = h)
}

make_factor <- function(x) {
  f <- factor(x)
  if (anyNA(f)) {
    f <- addNA(f)
    levels(f)[is.na(levels(f))] <- "Missing"
  }
  droplevels(f)
}

malnutrition_col <- grep("malnutrition|营养不良|钀ュ吇", names(d0), ignore.case = TRUE, value = TRUE)
malnutrition_col <- if (length(malnutrition_col) > 0) malnutrition_col[1] else NA_character_

d <- d0 |>
  dplyr::mutate(
    icu_intime2 = parse_time(.data$icu_intime),
    sepsis_time2 = parse_time(.data$sepsis_time),
    sepsis_onset_h = as.numeric(difftime(.data$sepsis_time2, .data$icu_intime2, units = "hours")),
    sofa2 = as.numeric(.data$sofa2_dynamic24_max),
    sofa = as.numeric(.data$sofa_dynamic24_max),
    age_m = as.numeric(.data$age),
    male = as.integer(.data$gender %in% c("M", "Male", "male", 1)),
    charlson_m = as.numeric(.data$charlson),
    malnutrition_m = if (!is.na(malnutrition_col)) to_binary(.data[[malnutrition_col]]) else 0L,
    ckd_m = to_binary(.data$renal_disease),
    chf_m = to_binary(.data$congestive_heart_failure),
    diabetes_m = to_binary(.data$diabetes),
    hypertension_m = to_binary(.data$hypertension),
    chronic_pulm_m = to_binary(.data$chronic_pulmonary_disease),
    dementia_m = to_binary(.data$dementia),
    cerebro_m = to_binary(.data$cerebrovascular_disease),
    pvd_m = to_binary(.data$peripheral_vascular_disease),
    mi_m = to_binary(.data$myocardial_infarct),
    liver_m = as.integer(to_binary(.data$mild_liver_disease) == 1 | to_binary(.data$severe_liver_disease) == 1),
    malignancy_m = as.integer(to_binary(.data$malignant_cancer) == 1 | to_binary(.data$metastatic_solid_tumor) == 1),
    infection_source_m = collapse_source(.data$infection_site_main_enriched),
    collapsed_infection_source_m = collapse_source(.data$infection_site_main_enriched),
    icu_admission_source_m = make_factor(dplyr::case_when(
      .data$admission_location == "EMERGENCY ROOM" ~ "Emergency_department",
      .data$admission_location %in% c("PROCEDURE SITE", "PACU") ~ "Procedure_or_OR",
      .data$admission_location == "TRANSFER FROM HOSPITAL" ~ "Other_hospital",
      .data$admission_location %in% c("PHYSICIAN REFERRAL", "WALK-IN/SELF REFERRAL", "CLINIC REFERRAL") ~ "Ward_or_clinic",
      TRUE ~ "Other_unknown"
    )),
    icu_type_m = make_factor(dplyr::case_when(
      .data$careunit %in% c("Medical Intensive Care Unit (MICU)", "Medical/Surgical Intensive Care Unit (MICU/SICU)") ~ "Medical_ICU",
      .data$careunit %in% c("Cardiac Vascular Intensive Care Unit (CVICU)", "Coronary Care Unit (CCU)") ~ "Cardiovascular_ICU",
      .data$careunit %in% c("Surgical Intensive Care Unit (SICU)", "Trauma SICU (TSICU)", "Neuro Surgical Intensive Care Unit (Neuro SICU)", "Surgery/Vascular/Intermediate", "Surgery/Trauma") ~ "Surgical_trauma_ICU",
      TRUE ~ "Other_ICU"
    )),
    non_renal_sofa2 = .data$sofa2 - as.numeric(.data$sofa2_dynamic24_kidney_max),
    non_resp_sofa2 = .data$sofa2 - as.numeric(.data$sofa2_dynamic24_resp_max),
    sofa2_severity = dplyr::case_when(
      .data$sofa2 >= 1 & .data$sofa2 <= 5 ~ "Q1_1_5",
      .data$sofa2 >= 6 & .data$sofa2 <= 7 ~ "Q2_6_7",
      .data$sofa2 >= 8 & .data$sofa2 <= 9 ~ "Q3_8_9",
      .data$sofa2 >= 10 ~ "Q4_10_plus",
      TRUE ~ NA_character_
    ),
    sofa2_severity = factor(.data$sofa2_severity, levels = c("Q1_1_5", "Q2_6_7", "Q3_8_9", "Q4_10_plus")),
    sofa2_severity_num = as.numeric(.data$sofa2_severity)
  )

shock <- new_after_24(parse_time(d$septic_shock_time_current), d$icu_intime2)
aki <- new_after_24(parse_time(d$aki_time_current), d$icu_intime2)
vent <- new_after_24(parse_time(d$invasivevent_time_first_current), d$icu_intime2)
rrt <- new_after_24(parse_time(d$rrt_time_first_current), d$icu_intime2)
crrt <- new_after_24(parse_time(d$crrt_time_first_current), d$icu_intime2)
vaso <- new_after_24(parse_time(d$vasoactive_first_time_current), d$icu_intime2)

d <- d |>
  dplyr::mutate(
    new_shock_after24 = .env$shock$outcome,
    eligible_shock = .env$shock$eligible,
    new_aki_after24 = .env$aki$outcome,
    eligible_aki = .env$aki$eligible,
    new_vent_after24 = .env$vent$outcome,
    eligible_vent = .env$vent$eligible,
    rrt_after24 = .env$rrt$outcome,
    eligible_rrt = TRUE,
    crrt_after24 = .env$crrt$outcome,
    eligible_crrt = TRUE,
    new_vaso_after24 = .env$vaso$outcome,
    eligible_vaso = TRUE
  )

prep_model_data <- function(data, vars, outcome, require_severity = FALSE) {
  z <- data[, unique(vars), drop = FALSE]
  z <- z[complete.cases(z), , drop = FALSE]
  for (nm in names(z)) {
    if (is.character(z[[nm]])) z[[nm]] <- make_factor(z[[nm]])
    if (is.factor(z[[nm]])) z[[nm]] <- droplevels(z[[nm]])
  }
  z
}

drop_bad_covars <- function(data, covars) {
  keep <- covars
  for (cv in covars) {
    if (!cv %in% names(data)) {
      keep <- setdiff(keep, cv)
    } else if (is.factor(data[[cv]]) && nlevels(data[[cv]]) < 2) {
      keep <- setdiff(keep, cv)
    } else if (!is.factor(data[[cv]]) && length(unique(data[[cv]])) < 2) {
      keep <- setdiff(keep, cv)
    }
  }
  keep
}

p_trend_binary <- function(data, outcome) {
  fit <- glm(as.formula(paste0(outcome, " ~ sofa2_severity_num")), data = data, family = binomial())
  coef(summary(fit))["sofa2_severity_num", "Pr(>|z|)"]
}

trend_specs <- list(
  "New septic shock after 24 h" = c("new_shock_after24", "eligible_shock"),
  "New AKI after 24 h" = c("new_aki_after24", "eligible_aki"),
  "New invasive ventilation after 24 h" = c("new_vent_after24", "eligible_vent"),
  "RRT after 24 h" = c("rrt_after24", "eligible_rrt"),
  "CRRT after 24 h" = c("crrt_after24", "eligible_crrt"),
  "New vasoactive therapy after 24 h" = c("new_vaso_after24", "eligible_vaso")
)

trend_table <- dplyr::bind_rows(lapply(names(trend_specs), function(label) {
  y <- trend_specs[[label]][1]
  eligible <- trend_specs[[label]][2]
  tmp <- d |>
    dplyr::filter(.data[[eligible]], !is.na(.data$sofa2_severity), !is.na(.data[[y]]))
  if (nrow(tmp) == 0 || length(unique(tmp[[y]])) < 2) return(NULL)
  p_trend <- p_trend_binary(tmp, y)
  tmp |>
    dplyr::group_by(.data$sofa2_severity, .data$sofa2_severity_num) |>
    dplyr::summarise(
      n = dplyr::n(),
      events = sum(.data[[y]] == 1, na.rm = TRUE),
      rate = .data$events / .data$n,
      .groups = "drop"
    ) |>
    dplyr::mutate(outcome_label = label, p_trend = p_trend)
}))
read.csv(text = capture.output(write.csv(trend_table, row.names = FALSE)), stringsAsFactors = FALSE)
utils::write.csv(trend_table, file.path(table_dir, "Table1_SOFA2_severity_trend_after24h.csv"), row.names = FALSE)

fit_logistic_robust <- function(data, outcome, exposure, covars, label) {
  vars <- c(outcome, exposure, covars, "subject_id")
  z <- prep_model_data(data, vars, outcome)
  covars2 <- drop_bad_covars(z, covars)
  f <- as.formula(paste(outcome, "~", paste(c(exposure, covars2), collapse = " + ")))
  fit <- glm(f, data = z, family = binomial())
  vc <- tryCatch(sandwich::vcovCL(fit, cluster = z$subject_id), error = function(e) sandwich::vcovHC(fit, type = "HC0"))
  ct <- lmtest::coeftest(fit, vcov. = vc)
  if (!exposure %in% rownames(ct)) {
    stop("Exposure not found in model coefficients: ", exposure, " for ", label)
  }
  est <- ct[exposure, "Estimate"]
  se <- ct[exposure, "Std. Error"]
  p <- ct[exposure, "Pr(>|z|)"]
  data.frame(
    model = label,
    outcome = outcome,
    exposure = exposure,
    n = nrow(z),
    events = sum(z[[outcome]] == 1, na.rm = TRUE),
    OR = exp(est),
    lower95 = exp(est - 1.96 * se),
    upper95 = exp(est + 1.96 * se),
    p = p,
    formula = paste(deparse(f), collapse = " "),
    actual_covariates = paste(covars2, collapse = ";"),
    stringsAsFactors = FALSE
  )
}

common_aki_rrt_covars <- c("age_m", "male", "malnutrition_m", "charlson_m", "infection_source_m",
                           "sepsis_onset_h", "icu_admission_source_m", "icu_type_m", "ckd_m",
                           "diabetes_m", "hypertension_m", "chf_m", "liver_m")

model_specs <- list(
  shock_crude = list(y = "new_shock_after24", eligible = "eligible_shock", x = "sofa2", covars = c()),
  shock_adjusted = list(y = "new_shock_after24", eligible = "eligible_shock", x = "sofa2", covars = c("age_m", "male", "charlson_m", "sepsis_onset_h", "collapsed_infection_source_m")),
  aki_crude = list(y = "new_aki_after24", eligible = "eligible_aki", x = "sofa2", covars = c()),
  aki_adjusted = list(y = "new_aki_after24", eligible = "eligible_aki", x = "sofa2", covars = common_aki_rrt_covars),
  aki_nonrenal = list(y = "new_aki_after24", eligible = "eligible_aki", x = "non_renal_sofa2", covars = common_aki_rrt_covars),
  vent_crude = list(y = "new_vent_after24", eligible = "eligible_vent", x = "sofa2", covars = c()),
  vent_adjusted = list(y = "new_vent_after24", eligible = "eligible_vent", x = "sofa2", covars = c("age_m", "male", "malnutrition_m", "charlson_m", "infection_source_m", "sepsis_onset_h", "icu_admission_source_m", "chronic_pulm_m", "dementia_m", "cerebro_m")),
  vent_nonresp = list(y = "new_vent_after24", eligible = "eligible_vent", x = "non_resp_sofa2", covars = c("age_m", "male", "malnutrition_m", "charlson_m", "infection_source_m", "sepsis_onset_h", "icu_admission_source_m", "chronic_pulm_m", "dementia_m", "cerebro_m")),
  rrt_crude = list(y = "rrt_after24", eligible = "eligible_rrt", x = "sofa2", covars = c()),
  rrt_adjusted = list(y = "rrt_after24", eligible = "eligible_rrt", x = "sofa2", covars = common_aki_rrt_covars),
  rrt_nonrenal = list(y = "rrt_after24", eligible = "eligible_rrt", x = "non_renal_sofa2", covars = common_aki_rrt_covars),
  crrt_adjusted = list(y = "crrt_after24", eligible = "eligible_crrt", x = "sofa2", covars = common_aki_rrt_covars),
  vaso_adjusted = list(y = "new_vaso_after24", eligible = "eligible_vaso", x = "sofa2", covars = c("age_m", "male", "malnutrition_m", "charlson_m", "infection_source_m", "sepsis_onset_h", "icu_admission_source_m", "icu_type_m", "chf_m", "hypertension_m", "pvd_m", "mi_m", "liver_m", "ckd_m", "malignancy_m"))
)

logistic_results <- dplyr::bind_rows(lapply(names(model_specs), function(nm) {
  s <- model_specs[[nm]]
  fit_logistic_robust(
    data = d |> dplyr::filter(.data[[s$eligible]]),
    outcome = s$y,
    exposure = s$x,
    covars = s$covars,
    label = nm
  )
})) |>
  dplyr::mutate(
    OR_95CI = sprintf("%.2f (%.2f-%.2f)", .data$OR, .data$lower95, .data$upper95),
    p_text = ifelse(.data$p < 0.001, "<0.001", sprintf("%.3f", .data$p))
  )
utils::write.csv(logistic_results, file.path(table_dir, "Table2_logistic_linear_OR_after24h.csv"), row.names = FALSE)

fit_rcs_ns <- function(data, outcome, exposure, covars, label, xlab) {
  vars <- c(outcome, exposure, covars, "subject_id")
  z <- prep_model_data(data, vars, outcome)
  covars2 <- drop_bad_covars(z, covars)
  linear_formula <- as.formula(paste(outcome, "~", paste(c(exposure, covars2), collapse = " + ")))
  rcs_formula <- as.formula(paste(outcome, "~ splines::ns(", exposure, ", df = 4)", if (length(covars2) > 0) paste0(" + ", paste(covars2, collapse = " + ")) else ""))
  cov_formula <- if (length(covars2) > 0) {
    as.formula(paste(outcome, "~", paste(covars2, collapse = " + ")))
  } else {
    as.formula(paste(outcome, "~ 1"))
  }
  fit_linear <- glm(linear_formula, data = z, family = binomial())
  fit_rcs <- glm(rcs_formula, data = z, family = binomial())
  fit_cov <- glm(cov_formula, data = z, family = binomial())

  p_overall <- anova(fit_cov, fit_rcs, test = "Chisq")[2, "Pr(>Chi)"]
  p_nonlinear <- anova(fit_linear, fit_rcs, test = "Chisq")[2, "Pr(>Chi)"]

  x_seq <- seq(stats::quantile(z[[exposure]], 0.01, na.rm = TRUE), stats::quantile(z[[exposure]], 0.99, na.rm = TRUE), length.out = 120)
  ref_x <- stats::median(z[[exposure]], na.rm = TRUE)
  nd <- data.frame(x_seq)
  names(nd) <- exposure
  rd <- data.frame(ref_x)
  names(rd) <- exposure
  for (cv in covars2) {
    if (is.factor(z[[cv]])) {
      lv <- mode_level(z[[cv]])
      nd[[cv]] <- factor(lv, levels = levels(z[[cv]]))
      rd[[cv]] <- factor(lv, levels = levels(z[[cv]]))
    } else {
      nd[[cv]] <- stats::median(z[[cv]], na.rm = TRUE)
      rd[[cv]] <- stats::median(z[[cv]], na.rm = TRUE)
    }
  }
  pred <- predict(fit_rcs, newdata = nd, type = "link", se.fit = TRUE)
  ref <- as.numeric(predict(fit_rcs, newdata = rd, type = "link"))
  plot_data <- data.frame(
    exposure_value = x_seq,
    OR = exp(pred$fit - ref),
    lower95 = exp(pred$fit - ref - 1.96 * pred$se.fit),
    upper95 = exp(pred$fit - ref + 1.96 * pred$se.fit)
  )
  p_txt <- function(p) ifelse(is.na(p), "NA", ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
  g <- ggplot2::ggplot(plot_data, ggplot2::aes(x = .data$exposure_value, y = .data$OR)) +
    ggplot2::geom_ribbon(ggplot2::aes(ymin = .data$lower95, ymax = .data$upper95), fill = "#A7C7E7", alpha = 0.35) +
    ggplot2::geom_line(color = "#1F5FBF", linewidth = 1) +
    ggplot2::geom_hline(yintercept = 1, linetype = 2, color = "gray40") +
    ggplot2::labs(
      x = xlab,
      y = "Odds ratio",
      title = label,
      subtitle = paste0("P overall=", p_txt(p_overall), "; P nonlinear=", p_txt(p_nonlinear))
    ) +
    ggplot2::theme_classic(base_size = 12)
  ggplot2::ggsave(file.path(figure_dir, paste0("RCS_", label, ".png")), g, width = 6.5, height = 5, dpi = 300)
  ggplot2::ggsave(file.path(figure_dir, paste0("RCS_", label, ".pdf")), g, width = 6.5, height = 5)

  saveRDS(fit_rcs, file.path(model_dir, paste0("RCS_", label, ".rds")))
  utils::write.csv(plot_data, file.path(table_dir, paste0("RCS_curve_data_", label, ".csv")), row.names = FALSE)

  data.frame(
    model = label,
    outcome = outcome,
    exposure = exposure,
    n = nrow(z),
    events = sum(z[[outcome]] == 1, na.rm = TRUE),
    p_overall = p_overall,
    p_nonlinear = p_nonlinear,
    actual_covariates = paste(covars2, collapse = ";"),
    stringsAsFactors = FALSE
  )
}

rcs_specs <- model_specs[c(
  "shock_crude", "shock_adjusted", "aki_adjusted", "aki_nonrenal",
  "vent_adjusted", "vent_nonresp", "rrt_adjusted", "rrt_nonrenal",
  "crrt_adjusted", "vaso_adjusted"
)]

rcs_results <- dplyr::bind_rows(lapply(names(rcs_specs), function(nm) {
  s <- rcs_specs[[nm]]
  fit_rcs_ns(
    data = d |> dplyr::filter(.data[[s$eligible]]),
    outcome = s$y,
    exposure = s$x,
    covars = s$covars,
    label = nm,
    xlab = ifelse(s$x == "sofa2", "Baseline SOFA-2", ifelse(s$x == "non_renal_sofa2", "Non-renal SOFA-2", "Non-respiratory SOFA-2"))
  )
}))
utils::write.csv(rcs_results, file.path(table_dir, "Table3_RCS_pvalues_after24h.csv"), row.names = FALSE)

outcome_summary <- dplyr::bind_rows(lapply(names(trend_specs), function(label) {
  y <- trend_specs[[label]][1]
  eligible <- trend_specs[[label]][2]
  z <- d |> dplyr::filter(.data[[eligible]])
  data.frame(
    outcome_label = label,
    risk_set_n = nrow(z),
    events_after24 = sum(z[[y]] == 1, na.rm = TRUE),
    excluded_pre24_or_at24 = nrow(d) - nrow(z),
    event_rate = sum(z[[y]] == 1, na.rm = TRUE) / nrow(z)
  )
}))
utils::write.csv(outcome_summary, file.path(table_dir, "Table0_outcome_risk_sets_after24h.csv"), row.names = FALSE)

saveRDS(d, file.path(out_dir, "internal_part1_analytic_dataset.rds"))

manifest <- list(
  project = "SOFA2 older sepsis",
  analysis = "Internal Part 1: SOFA2 severity stratification plus logistic/RCS for outcomes after 24h",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  input = input_path,
  cohort_rows = nrow(d),
  exposure = "Baseline SOFA-2 from raw non-imputed sofa2_dynamic24_max",
  severity_groups = c("Q1_1_5", "Q2_6_7", "Q3_8_9", "Q4_10_plus"),
    outcome_rule = "Shock, AKI, and invasive ventilation are new events after 24 h: patients with the target event at or before 24 h are excluded. RRT, CRRT, and vasoactive therapy use the full cohort and classify first use after 24 h as the outcome, without excluding patients with use within 24 h.",
  files = list(
    outcome_summary = file.path(table_dir, "Table0_outcome_risk_sets_after24h.csv"),
    severity_trend = file.path(table_dir, "Table1_SOFA2_severity_trend_after24h.csv"),
    logistic = file.path(table_dir, "Table2_logistic_linear_OR_after24h.csv"),
    rcs_pvalues = file.path(table_dir, "Table3_RCS_pvalues_after24h.csv"),
    figures = figure_dir
  )
)
yaml::write_yaml(manifest, file.path(out_dir, "internal_part1_manifest.yml"))

message("Internal Part 1 analysis completed.")
message("Outputs: ", out_dir)

