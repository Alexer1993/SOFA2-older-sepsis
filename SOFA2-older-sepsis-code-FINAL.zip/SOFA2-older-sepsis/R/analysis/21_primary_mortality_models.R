set.seed(2026)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
input_path <- file.path(project_root, "data", "processed", "SOFA2_latest_sofa_with_outcomes.rds")
out_dir <- file.path(project_root, "outputs", "internal_part2_sofa2_icu28_mortality")
table_dir <- file.path(out_dir, "tables")
figure_dir <- file.path(out_dir, "figures")
model_dir <- file.path(out_dir, "models")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(model_dir, recursive = TRUE, showWarnings = FALSE)

required_packages <- c("dplyr", "ggplot2", "survival", "splines", "broom", "yaml")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
}

d0 <- readRDS(input_path)

parse_time <- function(x) {
  if (inherits(x, "POSIXct")) return(x)
  x <- as.character(x)
  x[trimws(x) %in% c("", "NA", "NaN", "NULL", "NaT")] <- NA_character_
  as.POSIXct(x, tz = "UTC", tryFormats = c(
    "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M",
    "%Y-%m-%dT%H:%M:%SZ", "%Y/%m/%d %H:%M:%S",
    "%Y/%m/%d %H:%M", "%Y-%m-%d", "%Y/%m/%d"
  ))
}

to_binary <- function(x) {
  if (is.numeric(x) || is.integer(x)) return(as.integer(x > 0))
  z <- tolower(trimws(as.character(x)))
  as.integer(z %in% c("1", "yes", "y", "true", "t"))
}

mode_level <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) == 0) return(NA_character_)
  names(sort(table(x), decreasing = TRUE))[1]
}

make_factor <- function(x) {
  f <- factor(x)
  if (anyNA(f)) {
    f <- addNA(f)
    levels(f)[is.na(levels(f))] <- "Missing"
  }
  droplevels(f)
}

collapse_source <- function(x) {
  z <- tolower(trimws(enc2utf8(as.character(x))))
  out <- rep("Other/undetermined", length(z))
  out[grepl("pulmonary|lung|respir|pneumonia|肺", z)] <- "Pulmonary"
  out[grepl("urinary|urine|uti|renal|kidney|泌尿", z)] <- "Urinary"
  out[grepl("abdominal|abdomen|biliary|gastro|gi|intra|periton|腹腔|胆道|胃肠", z)] <- "Abdominal"
  out[grepl("bloodstream|blood stream|bacteremia|血流", z)] <- "Bloodstream"
  out[grepl("skin|soft tissue|皮肤|软组织", z)] <- "Skin/soft tissue"
  out[is.na(z) | z == ""] <- "Other/undetermined"
  factor(out, levels = c("Pulmonary", "Urinary", "Abdominal", "Bloodstream", "Skin/soft tissue", "Other/undetermined"))
}

fmt_p <- function(p) {
  ifelse(is.na(p), NA_character_, ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
}

fmt_ci <- function(est, low, high) {
  sprintf("%.2f (%.2f-%.2f)", est, low, high)
}

malnutrition_col <- grep("malnutrition|营养不良", names(d0), ignore.case = TRUE, value = TRUE)
malnutrition_col <- if (length(malnutrition_col) > 0) malnutrition_col[1] else NA_character_

icu_intime <- parse_time(d0$icu_intime)
sepsis_time <- parse_time(d0$sepsis_time)
dod <- parse_time(d0$dod)
death_days_from_dates <- as.numeric(difftime(dod, icu_intime, units = "days"))

death_days_raw <- suppressWarnings(as.numeric(d0$death_days_from_icu))
event28_raw <- suppressWarnings(as.integer(d0$icu_28d_death))
event28_from_dates <- as.integer(!is.na(death_days_from_dates) & death_days_from_dates >= 0 & death_days_from_dates <= 28)
event28 <- ifelse(is.na(event28_raw), event28_from_dates, event28_raw)
death_days <- ifelse(!is.na(death_days_raw), death_days_raw, death_days_from_dates)
time28 <- ifelse(event28 == 1, pmax(pmin(death_days, 28), 0.5), 28)

lactate_raw <- suppressWarnings(as.numeric(d0$lactate_first))
lactate_missing <- as.integer(is.na(lactate_raw))
lactate_imp <- lactate_raw
lactate_imp[is.na(lactate_imp)] <- stats::median(lactate_imp, na.rm = TRUE)

d <- d0 |>
  dplyr::mutate(
    time28 = .env$time28,
    event28 = .env$event28,
    baseline_sofa2 = as.numeric(.data$sofa2_dynamic24_max),
    age_m = as.numeric(.data$age),
    male = as.integer(.data$gender %in% c("M", "Male", "male", 1)),
    charlson_m = as.numeric(.data$charlson),
    infection_source_m = collapse_source(.data$infection_site_main_enriched),
    sepsis_onset_h = as.numeric(difftime(.env$sepsis_time, .env$icu_intime, units = "hours")),
    icu_admission_source_m = make_factor(dplyr::case_when(
      .data$admission_location == "EMERGENCY ROOM" ~ "Emergency_department",
      .data$admission_location %in% c("PROCEDURE SITE", "PACU") ~ "Procedure_or_OR",
      .data$admission_location == "TRANSFER FROM HOSPITAL" ~ "Other_hospital",
      .data$admission_location %in% c("PHYSICIAN REFERRAL", "WALK-IN/SELF REFERRAL", "CLINIC REFERRAL") ~ "Ward_or_clinic",
      TRUE ~ "Other_unknown"
    )),
    icu_type_m = make_factor(dplyr::case_when(
      .data$careunit %in% c("Medical Intensive Care Unit (MICU)", "Medical/Surgical Intensive Care Unit (MICU/SICU)") ~ "Medical_ICU",
      .data$careunit %in% c("Cardiac Vascular Intensive Care Unit (CVICU)", "Coronary Care Unit (CCU)") ~ "Cardiovascular_ICU",
      .data$careunit %in% c("Surgical Intensive Care Unit (SICU)", "Trauma SICU (TSICU)", "Neuro Surgical Intensive Care Unit (Neuro SICU)", "Surgery/Vascular/Intermediate", "Surgery/Trauma") ~ "Surgical_trauma_ICU",
      TRUE ~ "Other_ICU"
    )),
    lactate_imp = .env$lactate_imp,
    lactate_missing = .env$lactate_missing,
    ckd_m = to_binary(.data$renal_disease),
    chf_m = to_binary(.data$congestive_heart_failure),
    chronic_pulm_m = to_binary(.data$chronic_pulmonary_disease),
    liver_m = as.integer(to_binary(.data$mild_liver_disease) == 1 | to_binary(.data$severe_liver_disease) == 1),
    malignancy_m = as.integer(to_binary(.data$malignant_cancer) == 1 | to_binary(.data$metastatic_solid_tumor) == 1),
    dementia_m = to_binary(.data$dementia),
    diabetes_m = to_binary(.data$diabetes),
    sofa2_q = dplyr::case_when(
      .data$baseline_sofa2 >= 1 & .data$baseline_sofa2 <= 5 ~ "Q1_1_5",
      .data$baseline_sofa2 >= 6 & .data$baseline_sofa2 <= 7 ~ "Q2_6_7",
      .data$baseline_sofa2 >= 8 & .data$baseline_sofa2 <= 9 ~ "Q3_8_9",
      .data$baseline_sofa2 >= 10 ~ "Q4_10_plus",
      TRUE ~ NA_character_
    ),
    sofa2_q = factor(.data$sofa2_q, levels = c("Q1_1_5", "Q2_6_7", "Q3_8_9", "Q4_10_plus")),
    sofa2_q_num = as.numeric(.data$sofa2_q)
  )

prep_model_data <- function(data, vars) {
  z <- data[, unique(vars), drop = FALSE]
  z <- z[complete.cases(z), , drop = FALSE]
  for (nm in names(z)) {
    if (is.character(z[[nm]])) z[[nm]] <- make_factor(z[[nm]])
    if (is.factor(z[[nm]])) z[[nm]] <- droplevels(z[[nm]])
  }
  z
}

drop_bad_covars <- function(data, covars) {
  keep <- covars
  for (cv in covars) {
    if (!cv %in% names(data)) {
      keep <- setdiff(keep, cv)
    } else if (is.factor(data[[cv]]) && nlevels(data[[cv]]) < 2) {
      keep <- setdiff(keep, cv)
    } else if (!is.factor(data[[cv]]) && length(unique(data[[cv]])) < 2) {
      keep <- setdiff(keep, cv)
    }
  }
  keep
}

cox_formula <- function(exposure, covars, cluster = TRUE, spline = FALSE) {
  x <- if (spline) paste0("splines::ns(", exposure, ", df = 4)") else exposure
  rhs <- c(x, covars)
  if (cluster) rhs <- c(rhs, "cluster(subject_id)")
  as.formula(paste("survival::Surv(time28, event28) ~", paste(rhs, collapse = " + ")))
}

cox_formula_covars <- function(covars, cluster = FALSE) {
  rhs <- covars
  if (cluster) rhs <- c(rhs, "cluster(subject_id)")
  if (length(rhs) == 0) return(survival::Surv(time28, event28) ~ 1)
  as.formula(paste("survival::Surv(time28, event28) ~", paste(rhs, collapse = " + ")))
}

extract_exposure_row <- function(fit, model_name, exposure_type, exposure_pattern = "^baseline_sofa2$") {
  tb <- broom::tidy(fit, exponentiate = TRUE, conf.int = TRUE)
  tb <- tb[grepl(exposure_pattern, tb$term), , drop = FALSE]
  if (nrow(tb) == 0) return(NULL)
  tb |>
    dplyr::transmute(
      model = model_name,
      exposure_type = exposure_type,
      term = .data$term,
      HR = .data$estimate,
      lower95 = .data$conf.low,
      upper95 = .data$conf.high,
      p = .data$p.value,
      HR_95CI = fmt_ci(.data$HR, .data$lower95, .data$upper95),
      p_text = fmt_p(.data$p)
    )
}

continuous_models <- list(
  Crude = c(),
  `Model 1` = c("age_m", "male"),
  `Model 2` = c("age_m", "male", "charlson_m"),
  `Model 3` = c("age_m", "male", "charlson_m", "infection_source_m", "sepsis_onset_h",
                "icu_admission_source_m", "icu_type_m", "lactate_imp", "lactate_missing"),
  `Model 4 sensitivity` = c("age_m", "male", "ckd_m", "chf_m", "chronic_pulm_m", "liver_m",
                            "malignancy_m", "dementia_m", "diabetes_m", "infection_source_m",
                            "sepsis_onset_h", "icu_admission_source_m", "icu_type_m", "lactate_imp")
)

fit_store <- list()
cont_rows <- list()
q_rows <- list()
trend_rows <- list()
ph_rows <- list()

for (model_name in names(continuous_models)) {
  covars <- continuous_models[[model_name]]
  z <- prep_model_data(d, c("time28", "event28", "subject_id", "baseline_sofa2", covars))
  covars2 <- drop_bad_covars(z, covars)
  fit <- survival::coxph(cox_formula("baseline_sofa2", covars2, cluster = TRUE), data = z, ties = "efron", x = TRUE, y = TRUE)
  fit_store[[paste0("continuous_", model_name)]] <- fit
  cont <- extract_exposure_row(fit, model_name, "Continuous SOFA-2")
  cont$n <- nrow(z)
  cont$events <- sum(z$event28 == 1)
  cont$actual_covariates <- paste(covars2, collapse = ";")
  cont_rows[[model_name]] <- cont

  zq <- prep_model_data(d, c("time28", "event28", "subject_id", "sofa2_q", "sofa2_q_num", covars))
  covarsq <- drop_bad_covars(zq, covars)
  fit_q <- survival::coxph(cox_formula("sofa2_q", covarsq, cluster = TRUE), data = zq, ties = "efron", x = TRUE, y = TRUE)
  fit_store[[paste0("quartile_", model_name)]] <- fit_q
  q <- extract_exposure_row(fit_q, model_name, "SOFA-2 groups", "^sofa2_q")
  q$n <- nrow(zq)
  q$events <- sum(zq$event28 == 1)
  q$actual_covariates <- paste(covarsq, collapse = ";")
  q_rows[[model_name]] <- q

  fit_trend <- survival::coxph(cox_formula("sofa2_q_num", covarsq, cluster = TRUE), data = zq, ties = "efron")
  tr <- broom::tidy(fit_trend)
  p_trend <- tr$p.value[tr$term == "sofa2_q_num"]
  trend_rows[[model_name]] <- data.frame(
    model = model_name,
    n = nrow(zq),
    events = sum(zq$event28 == 1),
    p_trend = p_trend,
    p_trend_text = fmt_p(p_trend),
    actual_covariates = paste(covarsq, collapse = ";")
  )

  ph_fit <- survival::coxph(cox_formula("baseline_sofa2", covars2, cluster = FALSE), data = z, ties = "efron", x = TRUE, y = TRUE)
  ph <- survival::cox.zph(ph_fit)
  ph_tb <- as.data.frame(ph$table)
  ph_tb$term <- rownames(ph_tb)
  ph_tb$model <- model_name
  ph_rows[[model_name]] <- ph_tb
  capture.output(ph, file = file.path(table_dir, paste0("PH_test_continuous_SOFA2_", gsub("[^A-Za-z0-9]+", "_", model_name), ".txt")))
}

continuous_table <- dplyr::bind_rows(cont_rows)
quartile_table <- dplyr::bind_rows(q_rows)
trend_table <- dplyr::bind_rows(trend_rows)
ph_table <- dplyr::bind_rows(ph_rows)

utils::write.csv(continuous_table, file.path(table_dir, "Table1_Cox_continuous_SOFA2_ICU28_mortality.csv"), row.names = FALSE)
utils::write.csv(quartile_table, file.path(table_dir, "Table2_Cox_SOFA2_groups_ICU28_mortality.csv"), row.names = FALSE)
utils::write.csv(trend_table, file.path(table_dir, "Table3_Cox_SOFA2_groups_Ptrend.csv"), row.names = FALSE)
utils::write.csv(ph_table, file.path(table_dir, "Table4_PH_assumption_tests.csv"), row.names = FALSE)

obs_mort <- d |>
  dplyr::filter(!is.na(.data$time28), !is.na(.data$event28), !is.na(.data$sofa2_q)) |>
  dplyr::group_by(.data$sofa2_q) |>
  dplyr::summarise(
    n = dplyr::n(),
    deaths_28d = sum(.data$event28 == 1, na.rm = TRUE),
    mortality_28d = .data$deaths_28d / .data$n,
    median_sofa2 = stats::median(.data$baseline_sofa2, na.rm = TRUE),
    .groups = "drop"
  )
utils::write.csv(obs_mort, file.path(table_dir, "Table0_observed_28d_mortality_by_SOFA2_group.csv"), row.names = FALSE)

cohort_summary <- data.frame(
  source_rows = nrow(d0),
  analytic_rows = sum(complete.cases(d[, c("time28", "event28", "baseline_sofa2", "sofa2_q")])),
  icu28_deaths = sum(d$event28 == 1, na.rm = TRUE),
  icu28_event_rate = mean(d$event28 == 1, na.rm = TRUE),
  lactate_missing_n = sum(lactate_missing == 1, na.rm = TRUE),
  lactate_missing_rate = mean(lactate_missing == 1, na.rm = TRUE),
  lactate_median_used_for_imputation = stats::median(lactate_raw, na.rm = TRUE)
)
utils::write.csv(cohort_summary, file.path(table_dir, "TableS0_analysis_cohort_summary.csv"), row.names = FALSE)

fit_rcs_curve <- function(model_name, covars) {
  z <- prep_model_data(d, c("time28", "event28", "subject_id", "baseline_sofa2", covars))
  covars2 <- drop_bad_covars(z, covars)
  fit_linear <- survival::coxph(cox_formula("baseline_sofa2", covars2, cluster = FALSE), data = z, ties = "efron", x = TRUE, y = TRUE)
  fit_spline <- survival::coxph(cox_formula("baseline_sofa2", covars2, cluster = FALSE, spline = TRUE), data = z, ties = "efron", x = TRUE, y = TRUE)
  fit_cov <- survival::coxph(cox_formula_covars(covars2, cluster = FALSE), data = z, ties = "efron", x = TRUE, y = TRUE)

  p_overall <- stats::anova(fit_cov, fit_spline, test = "Chisq")[2, "Pr(>|Chi|)"]
  p_nonlinear <- stats::anova(fit_linear, fit_spline, test = "Chisq")[2, "Pr(>|Chi|)"]

  x_seq <- seq(stats::quantile(z$baseline_sofa2, 0.01, na.rm = TRUE), stats::quantile(z$baseline_sofa2, 0.99, na.rm = TRUE), length.out = 120)
  ref_x <- stats::median(z$baseline_sofa2, na.rm = TRUE)
  nd <- data.frame(baseline_sofa2 = x_seq)
  rd <- data.frame(baseline_sofa2 = ref_x)
  for (cv in covars2) {
    if (is.factor(z[[cv]])) {
      lv <- mode_level(z[[cv]])
      nd[[cv]] <- factor(lv, levels = levels(z[[cv]]))
      rd[[cv]] <- factor(lv, levels = levels(z[[cv]]))
    } else {
      nd[[cv]] <- stats::median(z[[cv]], na.rm = TRUE)
      rd[[cv]] <- stats::median(z[[cv]], na.rm = TRUE)
    }
  }

  pred <- predict(fit_spline, newdata = nd, type = "lp", se.fit = TRUE)
  ref <- as.numeric(predict(fit_spline, newdata = rd, type = "lp"))
  curve <- data.frame(
    baseline_sofa2 = x_seq,
    HR = exp(pred$fit - ref),
    lower95 = exp(pred$fit - ref - 1.96 * pred$se.fit),
    upper95 = exp(pred$fit - ref + 1.96 * pred$se.fit)
  )
  utils::write.csv(curve, file.path(table_dir, paste0("RCS_curve_data_", gsub("[^A-Za-z0-9]+", "_", model_name), ".csv")), row.names = FALSE)

  g <- ggplot2::ggplot(curve, ggplot2::aes(x = .data$baseline_sofa2, y = .data$HR)) +
    ggplot2::geom_ribbon(ggplot2::aes(ymin = .data$lower95, ymax = .data$upper95), fill = "#A7C7E7", alpha = 0.35) +
    ggplot2::geom_line(color = "#1F5FBF", linewidth = 1) +
    ggplot2::geom_hline(yintercept = 1, linetype = 2, color = "gray40") +
    ggplot2::labs(
      x = "Baseline SOFA-2",
      y = "Hazard ratio for ICU 28-day mortality",
      title = paste0("RCS: baseline SOFA-2 and ICU 28-day mortality (", model_name, ")"),
      subtitle = paste0("P overall=", fmt_p(p_overall), "; P nonlinear=", fmt_p(p_nonlinear))
    ) +
    ggplot2::theme_classic(base_size = 12)
  base <- paste0("Figure_RCS_SOFA2_ICU28_", gsub("[^A-Za-z0-9]+", "_", model_name))
  ggplot2::ggsave(file.path(figure_dir, paste0(base, ".png")), g, width = 6.5, height = 5, dpi = 300)
  ggplot2::ggsave(file.path(figure_dir, paste0(base, ".pdf")), g, width = 6.5, height = 5)
  saveRDS(fit_spline, file.path(model_dir, paste0("RCS_SOFA2_ICU28_", gsub("[^A-Za-z0-9]+", "_", model_name), ".rds")))

  data.frame(
    model = model_name,
    n = nrow(z),
    events = sum(z$event28 == 1),
    p_overall = p_overall,
    p_nonlinear = p_nonlinear,
    p_overall_text = fmt_p(p_overall),
    p_nonlinear_text = fmt_p(p_nonlinear),
    actual_covariates = paste(covars2, collapse = ";")
  )
}

rcs_results <- dplyr::bind_rows(
  fit_rcs_curve("Crude", continuous_models[["Crude"]]),
  fit_rcs_curve("Model 3", continuous_models[["Model 3"]])
)
utils::write.csv(rcs_results, file.path(table_dir, "Table5_RCS_pvalues_SOFA2_ICU28_mortality.csv"), row.names = FALSE)

km_data <- prep_model_data(d, c("time28", "event28", "sofa2_q"))
km_fit <- survival::survfit(survival::Surv(time28, event28) ~ sofa2_q, data = km_data)
km_diff <- survival::survdiff(survival::Surv(time28, event28) ~ sofa2_q, data = km_data)
km_p <- 1 - stats::pchisq(km_diff$chisq, length(km_diff$n) - 1)
saveRDS(km_fit, file.path(model_dir, "KM_SOFA2_group_ICU28_mortality.rds"))

km_sum <- summary(km_fit, times = seq(0, 28, by = 1))
km_df <- data.frame(
  time = km_sum$time,
  surv = km_sum$surv,
  lower = km_sum$lower,
  upper = km_sum$upper,
  strata = sub("^sofa2_q=", "", km_sum$strata)
)
utils::write.csv(km_df, file.path(table_dir, "KM_curve_data_SOFA2_groups_ICU28_mortality.csv"), row.names = FALSE)

p_km <- ggplot2::ggplot(km_df, ggplot2::aes(x = .data$time, y = .data$surv, color = .data$strata)) +
  ggplot2::geom_step(linewidth = 0.9) +
  ggplot2::coord_cartesian(xlim = c(0, 28), ylim = c(0, 1)) +
  ggplot2::labs(
    x = "Days after ICU admission",
    y = "Survival probability",
    color = "SOFA-2 group",
    title = "ICU 28-day survival by baseline SOFA-2 group",
    subtitle = paste0("Log-rank P=", fmt_p(km_p))
  ) +
  ggplot2::theme_classic(base_size = 12)
ggplot2::ggsave(file.path(figure_dir, "Figure_KM_SOFA2_groups_ICU28_mortality.png"), p_km, width = 7, height = 5, dpi = 300)
ggplot2::ggsave(file.path(figure_dir, "Figure_KM_SOFA2_groups_ICU28_mortality.pdf"), p_km, width = 7, height = 5)

forest_df <- quartile_table |>
  dplyr::filter(.data$model == "Model 3") |>
  dplyr::mutate(
    term_clean = dplyr::case_when(
      grepl("Q2_6_7", .data$term) ~ "Q2: 6-7 vs Q1: 1-5",
      grepl("Q3_8_9", .data$term) ~ "Q3: 8-9 vs Q1: 1-5",
      grepl("Q4_10_plus", .data$term) ~ "Q4: >=10 vs Q1: 1-5",
      TRUE ~ .data$term
    ),
    term_clean = factor(.data$term_clean, levels = rev(c("Q2: 6-7 vs Q1: 1-5", "Q3: 8-9 vs Q1: 1-5", "Q4: >=10 vs Q1: 1-5")))
  )
p_forest <- ggplot2::ggplot(forest_df, ggplot2::aes(x = .data$HR, y = .data$term_clean)) +
  ggplot2::geom_vline(xintercept = 1, linetype = 2, color = "gray45") +
  ggplot2::geom_errorbarh(ggplot2::aes(xmin = .data$lower95, xmax = .data$upper95), height = 0.14, color = "#1F5FBF") +
  ggplot2::geom_point(size = 2.4, color = "#1F5FBF") +
  ggplot2::labs(
    x = "Hazard ratio",
    y = NULL,
    title = "Model 3: SOFA-2 groups and ICU 28-day mortality"
  ) +
  ggplot2::theme_classic(base_size = 12)
ggplot2::ggsave(file.path(figure_dir, "Figure_Forest_Model3_SOFA2_groups_ICU28_mortality.png"), p_forest, width = 6.5, height = 4, dpi = 300)
ggplot2::ggsave(file.path(figure_dir, "Figure_Forest_Model3_SOFA2_groups_ICU28_mortality.pdf"), p_forest, width = 6.5, height = 4)

saveRDS(fit_store, file.path(model_dir, "Part2_SOFA2_ICU28_mortality_cox_models.rds"))
saveRDS(d, file.path(out_dir, "internal_part2_analytic_dataset.rds"))

manifest <- list(
  project = "SOFA2 older sepsis",
  analysis = "Internal Part 2: baseline SOFA-2 and ICU 28-day mortality",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  input = input_path,
  cohort_rows = nrow(d0),
  analytic_rows = cohort_summary$analytic_rows,
  exposure = "Baseline SOFA-2 from raw non-imputed sofa2_dynamic24_max",
  outcome = "ICU 28-day mortality; time origin is ICU admission; censored at 28 days",
  covariates = "Cleaned/imputed covariates from the latest master table; lactate is median-imputed with a missingness indicator in Model 3.",
  models = names(continuous_models),
  files = list(
    cohort_summary = file.path(table_dir, "TableS0_analysis_cohort_summary.csv"),
    observed_mortality = file.path(table_dir, "Table0_observed_28d_mortality_by_SOFA2_group.csv"),
    continuous_cox = file.path(table_dir, "Table1_Cox_continuous_SOFA2_ICU28_mortality.csv"),
    grouped_cox = file.path(table_dir, "Table2_Cox_SOFA2_groups_ICU28_mortality.csv"),
    p_trend = file.path(table_dir, "Table3_Cox_SOFA2_groups_Ptrend.csv"),
    rcs = file.path(table_dir, "Table5_RCS_pvalues_SOFA2_ICU28_mortality.csv"),
    figures = figure_dir
  )
)
yaml::write_yaml(manifest, file.path(out_dir, "internal_part2_manifest.yml"))

message("Internal Part 2 analysis completed.")
message("Outputs: ", out_dir)

