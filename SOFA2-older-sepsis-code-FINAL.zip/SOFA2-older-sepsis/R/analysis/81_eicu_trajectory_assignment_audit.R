project_root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "analysis", "80_eicu_trajectory_assignment.R"))

out_dir <- file.path(project_root, "outputs", "trajectory_assignment_audit")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

model_path <- file.path(
  project_root, "outputs", "internal_part4_cutoff_trajectory_subgroup_sensitivity",
  "models", "Part4_cutoff_trajectory_subgroup_sensitivity_objects.rds"
)
eicu_path <- file.path(
  project_root, "data", "analysis_ready_current",
  "eICU_SOFA2_external_validation_master_current.rds"
)

model <- load_mimic_trajectory_model(model_path)
eicu <- readRDS(eicu_path)
external <- data.frame(
  sofa2_d1 = as.numeric(eicu$sofa2_dynamic_24h_max),
  sofa2_d2 = as.numeric(eicu$sofa2_dynamic_48h_max),
  sofa2_d3 = as.numeric(eicu$sofa2_dynamic_72h_max)
)
assignment <- assign_eicu_to_mimic_trajectory(
  external, model, id = eicu$patientunitstayid
)

# Reconstruct the prior implementation for a transparent impact comparison.
raw_centers <- model$raw_centers
observed <- as.matrix(external[assignment$source_row, model$score_cols])
old_distances <- vapply(seq_len(nrow(raw_centers)), function(j) {
  rowSums((sweep(observed, 2, raw_centers[j, ], "-"))^2)
}, numeric(nrow(observed)))
old_class <- rownames(raw_centers)[max.col(-old_distances, ties.method = "first")]
assignment$previous_raw_space_class <- old_class
assignment$assignment_changed <- as.character(assignment$trajectory_class) != old_class

write.csv(
  trajectory_model_parameters(model),
  file.path(out_dir, "MIMIC_trajectory_model_parameters_for_eICU.csv"),
  row.names = FALSE
)
write.csv(
  assignment,
  file.path(out_dir, "eICU_patient_level_trajectory_assignment.csv"),
  row.names = FALSE
)
write.csv(
  as.data.frame.matrix(table(
    previous = assignment$previous_raw_space_class,
    corrected = assignment$trajectory_class
  )),
  file.path(out_dir, "eICU_assignment_old_vs_corrected_confusion.csv")
)

summary_table <- data.frame(
  item = c(
    "MIMIC model object", "eICU source data", "MIMIC trajectory model",
    "distance metric", "external refitting", "eICU source rows",
    "complete day 1-3 rows assigned", "rows excluded for incomplete day 1-3",
    "assignments changed vs prior raw-space implementation",
    "change proportion among assigned", "exact ties at minimum distance"
  ),
  value = c(
    model_path, eicu_path, "K-means, k=4, nstart=100, iter.max=100; fitted in MIMIC",
    model$distance, "No", nrow(eicu), nrow(assignment),
    nrow(eicu) - nrow(assignment), sum(assignment$assignment_changed),
    sprintf("%.6f", mean(assignment$assignment_changed)),
    sum(abs(assignment$distance_margin) < .Machine$double.eps^0.5)
  )
)
write.csv(summary_table, file.path(out_dir, "eICU_trajectory_assignment_QC.csv"), row.names = FALSE)

group_summary <- as.data.frame(table(assignment$trajectory_class), stringsAsFactors = FALSE)
names(group_summary) <- c("trajectory_class", "n")
group_summary$percent <- 100 * group_summary$n / sum(group_summary$n)
write.csv(group_summary, file.path(out_dir, "eICU_corrected_trajectory_group_counts.csv"), row.names = FALSE)

print(summary_table, row.names = FALSE)
print(group_summary, row.names = FALSE)

