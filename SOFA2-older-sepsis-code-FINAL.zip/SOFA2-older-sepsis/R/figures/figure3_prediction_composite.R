set.seed(2026)

project_root <- Sys.getenv("SOFA2_PROJECT_ROOT", unset = "")
if (!nzchar(project_root)) project_root <- normalizePath(file.path(getwd(), ".."), winslash = "/", mustWork = TRUE)
project_root <- gsub("\\\\", "/", project_root)

out_dir_env <- Sys.getenv("SOFA2_FIG3_OUT_DIR", unset = "")
out_dir <- if (nzchar(out_dir_env)) gsub("\\\\", "/", out_dir_env) else file.path(project_root, "outputs", "manuscript_figure3")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

required <- c("ggplot2", "gridExtra", "officer")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) stop("Missing packages: ", paste(missing, collapse = ", "))

fig3_dir <- file.path(project_root, "outputs", "manuscript_figure3")
fig4_dir <- file.path(project_root, "outputs", "manuscript_figure4")

auc <- read.csv(file.path(fig3_dir, "Fig3A_time_dependent_AUC_SOFA2_vs_SOFA_results.csv"), check.names = FALSE)
cal <- read.csv(file.path(fig4_dir, "Fig4A_calibration_deciles_SOFA2_vs_SOFA.csv"), check.names = FALSE)
dca <- read.csv(file.path(fig4_dir, "Fig4B_DCA_net_benefit_SOFA2_vs_SOFA.csv"), check.names = FALSE)
auc_key <- read.csv(file.path(fig3_dir, "Fig3A_key_timepoint_AUC_summary.csv"), check.names = FALSE)
fig3_qc <- read.csv(file.path(fig3_dir, "Fig3A_quality_check.csv"), check.names = FALSE)
fig4_metrics <- read.csv(file.path(fig4_dir, "Fig4A_calibration_metrics_SOFA2_vs_SOFA.csv"), check.names = FALSE)

plot_auc <- rbind(
  data.frame(time = auc$time, value = auc$AUC_SOFA2, model = "SOFA-2"),
  data.frame(time = auc$time, value = auc$AUC_SOFA, model = "SOFA")
)
plot_auc$model <- factor(plot_auc$model, levels = c("SOFA-2", "SOFA"))
cal$model <- factor(cal$model, levels = c("SOFA-2", "SOFA"))
dca$model <- factor(dca$model, levels = c("SOFA-2", "SOFA", "Treat all", "Treat none"))

mean_auc_sofa2 <- mean(auc$AUC_SOFA2, na.rm = TRUE)
mean_auc_sofa <- mean(auc$AUC_SOFA, na.rm = TRUE)
mean_delta <- mean(auc$delta_AUC, na.rm = TRUE)
nb_mean <- aggregate(net_benefit ~ model, data = dca[dca$model %in% c("SOFA-2", "SOFA"), ], mean)
nb_delta <- nb_mean$net_benefit[nb_mean$model == "SOFA-2"] - nb_mean$net_benefit[nb_mean$model == "SOFA"]
slope_sofa2 <- fig4_metrics$calibration_slope[fig4_metrics$model == "SOFA-2"]
slope_sofa <- fig4_metrics$calibration_slope[fig4_metrics$model == "SOFA"]

pal <- c("SOFA-2" = "#1F4E79", "SOFA" = "#D95F02", "Treat all" = "grey35", "Treat none" = "grey65")
base_theme <- ggplot2::theme_classic(base_family = "Arial", base_size = 8) +
  ggplot2::theme(
    axis.title = ggplot2::element_text(size = 8.5),
    axis.text = ggplot2::element_text(size = 7.5, color = "black"),
    legend.title = ggplot2::element_blank(),
    legend.text = ggplot2::element_text(size = 7.5),
    legend.background = ggplot2::element_blank(),
    legend.margin = ggplot2::margin(0, 0, 1, 0),
    legend.key.width = grid::unit(0.55, "cm"),
    legend.spacing.x = grid::unit(0.20, "cm"),
    plot.margin = ggplot2::margin(2, 7, 5, 7)
  )

ymin_auc <- max(0.50, floor((min(plot_auc$value, na.rm = TRUE) - 0.015) * 100) / 100)
ymax_auc <- min(0.85, ceiling((max(plot_auc$value, na.rm = TRUE) + 0.015) * 100) / 100)
if (ymax_auc - ymin_auc < 0.08) ymax_auc <- ymin_auc + 0.08

p_auc <- ggplot2::ggplot(plot_auc, ggplot2::aes(x = time, y = value, color = model)) +
  ggplot2::geom_line(linewidth = 0.7) +
  ggplot2::geom_point(data = plot_auc[plot_auc$time %in% c(7, 14, 21, 28), ], size = 1.15) +
  ggplot2::scale_color_manual(values = pal[c("SOFA-2", "SOFA")]) +
  ggplot2::scale_x_continuous(breaks = c(1, 7, 14, 21, 28), limits = c(1, 28), expand = c(0.01, 0)) +
  ggplot2::scale_y_continuous(limits = c(ymin_auc, ymax_auc), breaks = seq(0.50, 0.85, by = 0.05)) +
  ggplot2::labs(x = "Time after ICU admission, days", y = "Time-dependent AUC") +
  base_theme +
  ggplot2::theme(
    legend.position = "top",
    legend.direction = "horizontal",
    legend.box.margin = ggplot2::margin(18, 0, 2, 0)
  )

cal_min <- min(c(cal$predicted_risk, cal$observed_risk), na.rm = TRUE)
cal_max <- max(c(cal$predicted_risk, cal$observed_risk), na.rm = TRUE)
cal_lim <- c(max(0, floor((cal_min - 0.02) * 10) / 10), min(0.8, ceiling((cal_max + 0.02) * 10) / 10))
if (cal_lim[2] - cal_lim[1] < 0.2) cal_lim[2] <- cal_lim[1] + 0.2

p_cal <- ggplot2::ggplot(cal, ggplot2::aes(x = predicted_risk, y = observed_risk, color = model)) +
  ggplot2::geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey50", linewidth = 0.35) +
  ggplot2::geom_line(linewidth = 0.6) +
  ggplot2::geom_point(size = 1.25) +
  ggplot2::scale_color_manual(values = pal[c("SOFA-2", "SOFA")]) +
  ggplot2::scale_x_continuous(limits = cal_lim, breaks = seq(0, 0.8, by = 0.1)) +
  ggplot2::scale_y_continuous(limits = cal_lim, breaks = seq(0, 0.8, by = 0.1)) +
  ggplot2::coord_equal() +
  ggplot2::labs(x = "Predicted 28-day mortality risk", y = "Observed 28-day mortality risk") +
  base_theme +
  ggplot2::theme(
    legend.position = "top",
    legend.direction = "horizontal",
    legend.box.margin = ggplot2::margin(0, 0, 2, 0)
  )

p_dca <- ggplot2::ggplot(dca, ggplot2::aes(x = threshold, y = net_benefit, color = model, linetype = model)) +
  ggplot2::geom_line(linewidth = 0.6) +
  ggplot2::scale_color_manual(values = pal) +
  ggplot2::scale_linetype_manual(values = c("SOFA-2" = "solid", "SOFA" = "solid", "Treat all" = "dashed", "Treat none" = "dotted")) +
  ggplot2::guides(color = ggplot2::guide_legend(nrow = 2, byrow = TRUE),
                  linetype = ggplot2::guide_legend(nrow = 2, byrow = TRUE)) +
  ggplot2::scale_x_continuous(limits = c(0.05, 0.60), breaks = seq(0.10, 0.60, by = 0.10)) +
  ggplot2::scale_y_continuous(limits = c(-0.05, max(dca$net_benefit, na.rm = TRUE) + 0.02)) +
  ggplot2::labs(x = "Threshold probability", y = "Net benefit") +
  base_theme +
  ggplot2::theme(
    legend.position = "top",
    legend.direction = "horizontal",
    legend.box.margin = ggplot2::margin(18, 0, 2, 0),
    legend.text = ggplot2::element_text(size = 6.8),
    legend.key.width = grid::unit(0.50, "cm"),
    legend.spacing.x = grid::unit(0.12, "cm")
  )

panel_labels <- gridExtra::arrangeGrob(
  grid::textGrob("A", x = 0.01, y = 0.25, hjust = 0, vjust = 0.5, gp = grid::gpar(fontface = "bold", fontsize = 13)),
  grid::textGrob("B", x = 0.01, y = 0.25, hjust = 0, vjust = 0.5, gp = grid::gpar(fontface = "bold", fontsize = 13)),
  grid::textGrob("C", x = 0.01, y = 0.25, hjust = 0, vjust = 0.5, gp = grid::gpar(fontface = "bold", fontsize = 13)),
  ncol = 3,
  widths = c(1, 1, 1.08)
)
panel_plots <- gridExtra::arrangeGrob(p_auc, p_cal, p_dca, ncol = 3, widths = c(1, 1, 1.08))
fig <- gridExtra::arrangeGrob(
  panel_labels,
  panel_plots,
  ncol = 1,
  heights = grid::unit.c(grid::unit(0.48, "cm"), grid::unit(1, "null"))
)

pdf_path <- file.path(out_dir, "Fig3_prediction_performance_SOFA2_vs_SOFA_ABC.pdf")
png_path <- file.path(out_dir, "Fig3_prediction_performance_SOFA2_vs_SOFA_ABC.png")
tiff_path <- file.path(out_dir, "Fig3_prediction_performance_SOFA2_vs_SOFA_ABC.tiff")

ggplot2::ggsave(pdf_path, fig, width = 180, height = 82, units = "mm", device = grDevices::cairo_pdf)
ggplot2::ggsave(png_path, fig, width = 180, height = 82, units = "mm", dpi = 300, bg = "white")
ggplot2::ggsave(tiff_path, fig, width = 180, height = 82, units = "mm", dpi = 600, compression = "lzw", bg = "white")

n_analysis <- fig3_qc$value[fig3_qc$item == "analysis_rows"][1]
events <- fig3_qc$value[fig3_qc$item == "death_events"][1]

legend_text <- paste(
  "Figure 3. Prediction performance of SOFA-2 and conventional SOFA for ICU-admission-based 28-day mortality.",
  "(A) Time-dependent area under the receiver operating characteristic curve from Day 3 through Day 28; Day 1 is not interpreted because the >=48-h ICU-stay eligibility criterion creates a design-imposed event-free window.",
  "(B) Calibration curves comparing predicted and observed 28-day mortality risk across deciles of predicted risk; the dashed diagonal line indicates perfect calibration.",
  "(C) Decision curve analysis showing net benefit across threshold probabilities, with treat-all and treat-none strategies shown for reference.",
  "All panels used the same complete-case MIMIC-IV analytic cohort."
)

results_text <- paste0(
  "The complete-case analytic cohort included N = ", format(as.numeric(n_analysis), big.mark = ","), " patients, with ",
  format(as.numeric(events), big.mark = ","), " ICU-admission-based 28-day deaths. ",
  "At day 28, the time-dependent AUC was ", sprintf("%.3f", auc_key$AUC_SOFA2[auc_key$time == 28]), " for SOFA-2 and ",
  sprintf("%.3f", auc_key$AUC_SOFA[auc_key$time == 28]), " for conventional SOFA. ",
  "Across evaluated days 3-28, mean AUCs were ", sprintf("%.3f", mean_auc_sofa2), " and ", sprintf("%.3f", mean_auc_sofa),
  " respectively (mean delta, ", sprintf("%.3f", mean_delta), "). ",
  "Calibration intercepts were ", sprintf("%.3f", fig4_metrics$calibration_intercept[fig4_metrics$model == "SOFA-2"]), " for SOFA-2 and ",
  sprintf("%.3f", fig4_metrics$calibration_intercept[fig4_metrics$model == "SOFA"]), " for SOFA; calibration slopes were ",
  sprintf("%.3f", slope_sofa2), " and ", sprintf("%.3f", slope_sofa), ", respectively. ",
  "Brier scores were ", sprintf("%.3f", fig4_metrics$brier_score[fig4_metrics$model == "SOFA-2"]), " for SOFA-2 and ",
  sprintf("%.3f", fig4_metrics$brier_score[fig4_metrics$model == "SOFA"]), " for SOFA. ",
  "Decision curve analysis was evaluated across threshold probabilities from 0.05 to 0.60; the mean net benefit difference for SOFA-2 versus SOFA was ",
  sprintf("%.3f", nb_delta), "."
)

writeLines(legend_text, file.path(out_dir, "Fig3_legend.txt"), useBytes = TRUE)
writeLines(results_text, file.path(out_dir, "Fig3_results_description.txt"), useBytes = TRUE)

doc <- officer::read_docx()
doc <- officer::body_add_par(doc, "Figure 3 Legend", style = "heading 1")
doc <- officer::body_add_par(doc, legend_text, style = "Normal")
doc <- officer::body_add_par(doc, "Results Description", style = "heading 1")
doc <- officer::body_add_par(doc, results_text, style = "Normal")
print(doc, target = file.path(out_dir, "Fig3_legend_and_results.docx"))

summary <- data.frame(
  item = c("source_auc_table", "source_calibration_table", "source_dca_table", "analysis_rows", "death_events",
           "mean_auc_sofa2", "mean_auc_sofa", "mean_delta_auc", "day28_auc_sofa2", "day28_auc_sofa",
           "calibration_intercept_sofa2", "calibration_intercept_sofa",
           "calibration_slope_sofa2", "calibration_slope_sofa",
           "brier_score_sofa2", "brier_score_sofa",
           "dca_threshold_min", "dca_threshold_max", "mean_net_benefit_delta_sofa2_minus_sofa"),
  value = c(
    file.path(fig3_dir, "Fig3A_time_dependent_AUC_SOFA2_vs_SOFA_results.csv"),
    file.path(fig4_dir, "Fig4A_calibration_deciles_SOFA2_vs_SOFA.csv"),
    file.path(fig4_dir, "Fig4B_DCA_net_benefit_SOFA2_vs_SOFA.csv"),
    n_analysis, events, mean_auc_sofa2, mean_auc_sofa, mean_delta,
    auc_key$AUC_SOFA2[auc_key$time == 28], auc_key$AUC_SOFA[auc_key$time == 28],
    fig4_metrics$calibration_intercept[fig4_metrics$model == "SOFA-2"],
    fig4_metrics$calibration_intercept[fig4_metrics$model == "SOFA"],
    slope_sofa2,
    slope_sofa,
    fig4_metrics$brier_score[fig4_metrics$model == "SOFA-2"],
    fig4_metrics$brier_score[fig4_metrics$model == "SOFA"],
    min(dca$threshold, na.rm = TRUE),
    max(dca$threshold, na.rm = TRUE),
    nb_delta
  )
)
utils::write.csv(summary, file.path(out_dir, "Fig3_prediction_performance_summary.csv"), row.names = FALSE)

script_target <- file.path(out_dir, "make_fig3_prediction_performance_abc.R")
this_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1])
if (!is.na(this_file) && nzchar(this_file) && file.exists(this_file)) {
  file.copy(this_file, script_target, overwrite = TRUE)
}

message("FIG3 ABC completed: ", out_dir)

