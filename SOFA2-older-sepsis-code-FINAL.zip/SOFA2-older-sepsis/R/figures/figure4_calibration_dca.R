set.seed(2026)

project_root <- Sys.getenv("SOFA2_PROJECT_ROOT", unset = "")
if (!nzchar(project_root)) project_root <- normalizePath(file.path(getwd(), ".."), winslash = "/", mustWork = TRUE)
project_root <- gsub("\\\\", "/", project_root)

out_dir_env <- Sys.getenv("SOFA2_FIG4_OUT_DIR", unset = "")
out_dir <- if (nzchar(out_dir_env)) gsub("\\\\", "/", out_dir_env) else file.path(project_root, "outputs", "manuscript_figure4")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

required <- c("survival", "ggplot2", "gridExtra", "officer")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) stop("Missing packages: ", paste(missing, collapse = ", "))

data_path <- file.path(project_root, "data", "analysis_ready_current", "MIMIC_SOFA2_analysis_master_current.rds")
d0 <- readRDS(data_path)

to_num <- function(x) suppressWarnings(as.numeric(x))
logit_safe <- function(p) stats::qlogis(pmin(pmax(p, 1e-6), 1 - 1e-6))
fmt <- function(x, digits = 3) sprintf(paste0("%.", digits, "f"), x)

event28 <- suppressWarnings(as.integer(d0$icu_28d_death))
death_days <- to_num(d0$death_days_from_icu)
time28 <- ifelse(event28 == 1, pmax(pmin(death_days, 28), 0.5), 28)
time28[is.na(time28) | time28 <= 0] <- 0.5

dat <- data.frame(
  time = to_num(time28),
  status = event28,
  sofa2 = to_num(d0$sofa2_dynamic24_max),
  sofa = to_num(d0$sofa_dynamic24_max),
  death_days_from_icu = death_days
)

qc <- data.frame(
  item = c(
    "source_rows", "missing_time", "missing_status", "missing_SOFA2", "missing_SOFA",
    "followup_time_le_0_before_correction", "event_marked_death_with_time_gt_28",
    "death_days_gt_28_but_status_1", "complete_case_rows"
  ),
  value = c(
    nrow(dat), sum(is.na(dat$time)), sum(is.na(dat$status)), sum(is.na(dat$sofa2)), sum(is.na(dat$sofa)),
    sum(to_num(ifelse(event28 == 1, pmin(death_days, 28), 28)) <= 0, na.rm = TRUE),
    sum(dat$status == 1 & dat$time > 28, na.rm = TRUE),
    sum(dat$status == 1 & dat$death_days_from_icu > 28, na.rm = TRUE),
    sum(stats::complete.cases(dat[, c("time", "status", "sofa2", "sofa")]))
  ),
  stringsAsFactors = FALSE
)

cc <- dat[stats::complete.cases(dat[, c("time", "status", "sofa2", "sofa")]), ]
cc$status <- as.integer(cc$status == 1)
cc$time <- pmin(pmax(cc$time, 0.5), 28)

fit_sofa2 <- survival::coxph(survival::Surv(time, status) ~ sofa2, data = cc, ties = "efron", x = TRUE)
fit_sofa <- survival::coxph(survival::Surv(time, status) ~ sofa, data = cc, ties = "efron", x = TRUE)

predict_risk_28 <- function(fit, data) {
  bh <- survival::basehaz(fit, centered = FALSE)
  h0 <- approx(bh$time, bh$hazard, xout = 28, method = "constant", rule = 2, f = 0)$y
  lp <- stats::predict(fit, newdata = data, type = "lp", reference = "zero")
  pmin(pmax(1 - exp(-h0 * exp(lp)), 1e-6), 1 - 1e-6)
}

cc$risk_sofa2 <- predict_risk_28(fit_sofa2, cc)
cc$risk_sofa <- predict_risk_28(fit_sofa, cc)

make_calibration <- function(data, risk_col, model_name, groups = 10) {
  risk <- data[[risk_col]]
  br <- unique(stats::quantile(risk, probs = seq(0, 1, length.out = groups + 1), na.rm = TRUE, type = 8))
  grp <- cut(risk, breaks = br, include.lowest = TRUE, labels = FALSE)
  out <- lapply(sort(unique(grp)), function(g) {
    idx <- which(grp == g)
    sf <- survival::survfit(survival::Surv(time, status) ~ 1, data = data[idx, , drop = FALSE])
    s28 <- summary(sf, times = 28, extend = TRUE)$surv
    data.frame(
      model = model_name,
      group = g,
      n = length(idx),
      events = sum(data$status[idx] == 1),
      predicted_risk = mean(risk[idx], na.rm = TRUE),
      observed_risk = 1 - s28
    )
  })
  do.call(rbind, out)
}

calibration <- rbind(
  make_calibration(cc, "risk_sofa2", "SOFA-2"),
  make_calibration(cc, "risk_sofa", "SOFA")
)

calibration_metrics <- function(data, risk_col, model_name) {
  risk <- data[[risk_col]]
  fit <- stats::glm(status ~ logit_safe(risk), data = data, family = stats::binomial())
  co <- stats::coef(summary(fit))
  data.frame(
    model = model_name,
    n = nrow(data),
    events = sum(data$status == 1),
    mean_predicted_risk = mean(risk),
    observed_event_rate = mean(data$status),
    calibration_intercept = unname(stats::coef(fit)[1]),
    calibration_slope = unname(stats::coef(fit)[2]),
    calibration_slope_p = co[2, 4],
    brier_score = mean((data$status - risk)^2),
    stringsAsFactors = FALSE
  )
}
metrics <- rbind(
  calibration_metrics(cc, "risk_sofa2", "SOFA-2"),
  calibration_metrics(cc, "risk_sofa", "SOFA")
)

calc_dca <- function(status, risk, thresholds, model_name) {
  n <- length(status)
  do.call(rbind, lapply(thresholds, function(pt) {
    pred <- risk >= pt
    tp <- sum(pred & status == 1)
    fp <- sum(pred & status == 0)
    data.frame(
      model = model_name,
      threshold = pt,
      net_benefit = tp / n - fp / n * pt / (1 - pt)
    )
  }))
}
thresholds <- seq(0.05, 0.60, by = 0.01)
prev <- mean(cc$status)
dca <- rbind(
  calc_dca(cc$status, cc$risk_sofa2, thresholds, "SOFA-2"),
  calc_dca(cc$status, cc$risk_sofa, thresholds, "SOFA"),
  data.frame(model = "Treat all", threshold = thresholds, net_benefit = prev - (1 - prev) * thresholds / (1 - thresholds)),
  data.frame(model = "Treat none", threshold = thresholds, net_benefit = 0)
)

hr_sofa2 <- exp(stats::coef(fit_sofa2)[["sofa2"]])
hr_sofa <- exp(stats::coef(fit_sofa)[["sofa"]])
qc <- rbind(
  qc,
  data.frame(
    item = c("analysis_rows", "death_events", "censored_or_event_free", "SOFA2_Cox_HR_per_point", "SOFA_Cox_HR_per_point", "higher_score_higher_risk"),
    value = c(nrow(cc), sum(cc$status == 1), sum(cc$status == 0), hr_sofa2, hr_sofa, hr_sofa2 > 1 && hr_sofa > 1),
    stringsAsFactors = FALSE
  )
)

pal <- c("SOFA-2" = "#1F4E79", "SOFA" = "#D95F02", "Treat all" = "grey35", "Treat none" = "grey65")
base_theme <- ggplot2::theme_classic(base_family = "Arial", base_size = 8) +
  ggplot2::theme(
    axis.title = ggplot2::element_text(size = 9),
    axis.text = ggplot2::element_text(size = 8, color = "black"),
    legend.title = ggplot2::element_blank(),
    legend.text = ggplot2::element_text(size = 8),
    legend.background = ggplot2::element_blank(),
    legend.margin = ggplot2::margin(0, 0, 1, 0),
    plot.tag = ggplot2::element_text(face = "bold", size = 13, hjust = 0, vjust = 1),
    plot.margin = ggplot2::margin(8, 8, 6, 8)
  )

cal_min <- min(c(calibration$predicted_risk, calibration$observed_risk), na.rm = TRUE)
cal_max <- max(c(calibration$predicted_risk, calibration$observed_risk), na.rm = TRUE)
cal_lim <- c(max(0, floor((cal_min - 0.02) * 10) / 10), min(0.8, ceiling((cal_max + 0.02) * 10) / 10))
if (cal_lim[2] - cal_lim[1] < 0.2) cal_lim[2] <- cal_lim[1] + 0.2

p_cal <- ggplot2::ggplot(calibration, ggplot2::aes(x = predicted_risk, y = observed_risk, color = model)) +
  ggplot2::geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey50", linewidth = 0.35) +
  ggplot2::geom_line(linewidth = 0.65) +
  ggplot2::geom_point(size = 1.5) +
  ggplot2::scale_color_manual(values = pal[c("SOFA-2", "SOFA")]) +
  ggplot2::scale_x_continuous(limits = cal_lim, breaks = seq(0, 0.8, by = 0.1)) +
  ggplot2::scale_y_continuous(limits = cal_lim, breaks = seq(0, 0.8, by = 0.1)) +
  ggplot2::coord_equal() +
  ggplot2::labs(x = "Predicted 28-day mortality risk", y = "Observed 28-day mortality risk", tag = "A") +
  base_theme +
  ggplot2::theme(
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = grid::unit(0.75, "cm"),
    legend.spacing.x = grid::unit(0.45, "cm")
  )

p_dca <- ggplot2::ggplot(dca, ggplot2::aes(x = threshold, y = net_benefit, color = model, linetype = model)) +
  ggplot2::geom_line(linewidth = 0.65) +
  ggplot2::scale_color_manual(values = pal) +
  ggplot2::scale_linetype_manual(values = c("SOFA-2" = "solid", "SOFA" = "solid", "Treat all" = "dashed", "Treat none" = "dotted")) +
  ggplot2::scale_x_continuous(limits = c(0.05, 0.60), breaks = seq(0.10, 0.60, by = 0.10)) +
  ggplot2::scale_y_continuous(limits = c(-0.05, max(dca$net_benefit, na.rm = TRUE) + 0.02)) +
  ggplot2::labs(x = "Threshold probability", y = "Net benefit", tag = "B") +
  base_theme +
  ggplot2::theme(
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = grid::unit(0.65, "cm"),
    legend.spacing.x = grid::unit(0.25, "cm"),
    legend.text = ggplot2::element_text(size = 7.5)
  )

fig <- gridExtra::arrangeGrob(p_cal, p_dca, ncol = 2, widths = c(1, 1))

pdf_path <- file.path(out_dir, "Fig4_calibration_DCA_SOFA2_vs_SOFA.pdf")
png_path <- file.path(out_dir, "Fig4_calibration_DCA_SOFA2_vs_SOFA.png")
tiff_path <- file.path(out_dir, "Fig4_calibration_DCA_SOFA2_vs_SOFA.tiff")

ggplot2::ggsave(pdf_path, fig, width = 180, height = 102, units = "mm", device = grDevices::cairo_pdf)
ggplot2::ggsave(png_path, fig, width = 180, height = 102, units = "mm", dpi = 300, bg = "white")
ggplot2::ggsave(tiff_path, fig, width = 180, height = 102, units = "mm", dpi = 600, compression = "lzw", bg = "white")

utils::write.csv(calibration, file.path(out_dir, "Fig4A_calibration_deciles_SOFA2_vs_SOFA.csv"), row.names = FALSE)
utils::write.csv(metrics, file.path(out_dir, "Fig4A_calibration_metrics_SOFA2_vs_SOFA.csv"), row.names = FALSE)
utils::write.csv(dca, file.path(out_dir, "Fig4B_DCA_net_benefit_SOFA2_vs_SOFA.csv"), row.names = FALSE)
utils::write.csv(qc, file.path(out_dir, "Fig4_quality_check.csv"), row.names = FALSE)

legend_text <- paste(
  "Figure 4. Calibration and decision curve analysis for SOFA-2 and conventional SOFA in predicting ICU-admission-based 28-day mortality.",
  "(A) Calibration curves comparing predicted and observed 28-day mortality risk across deciles of predicted risk. The dashed diagonal line indicates perfect calibration.",
  "(B) Decision curve analysis showing net benefit across threshold probabilities for SOFA-2 and conventional SOFA, with treat-all and treat-none strategies shown for reference.",
  "Both scores were evaluated in the same complete-case analytic cohort without additional imputation."
)

best_model <- if (metrics$brier_score[metrics$model == "SOFA-2"] < metrics$brier_score[metrics$model == "SOFA"]) "SOFA-2" else "SOFA"
mean_nb <- aggregate(net_benefit ~ model, data = dca[dca$model %in% c("SOFA-2", "SOFA"), ], mean)
nb_delta <- mean_nb$net_benefit[mean_nb$model == "SOFA-2"] - mean_nb$net_benefit[mean_nb$model == "SOFA"]
results_text <- paste0(
  "In the complete-case analytic cohort (N = ", format(nrow(cc), big.mark = ","), "), ",
  format(sum(cc$status == 1), big.mark = ","), " patients experienced ICU-admission-based 28-day mortality. ",
  "Calibration slopes were ", fmt(metrics$calibration_slope[metrics$model == "SOFA-2"]), " for SOFA-2 and ",
  fmt(metrics$calibration_slope[metrics$model == "SOFA"]), " for conventional SOFA; Brier scores were ",
  fmt(metrics$brier_score[metrics$model == "SOFA-2"]), " and ", fmt(metrics$brier_score[metrics$model == "SOFA"]), ", respectively. ",
  "Across threshold probabilities from 0.05 to 0.60, the mean net benefit difference for SOFA-2 versus SOFA was ",
  fmt(nb_delta), ". These findings describe predictive performance and clinical utility associations and should not be interpreted causally."
)

writeLines(legend_text, file.path(out_dir, "Fig4_legend.txt"), useBytes = TRUE)
writeLines(results_text, file.path(out_dir, "Fig4_results_description.txt"), useBytes = TRUE)

doc <- officer::read_docx()
doc <- officer::body_add_par(doc, "Figure 4 Legend", style = "heading 1")
doc <- officer::body_add_par(doc, legend_text, style = "Normal")
doc <- officer::body_add_par(doc, "Results Description", style = "heading 1")
doc <- officer::body_add_par(doc, results_text, style = "Normal")
print(doc, target = file.path(out_dir, "Fig4_legend_and_results.docx"))

script_target <- file.path(out_dir, "make_fig4_calibration_dca_sofa2_vs_sofa.R")
this_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1])
if (!is.na(this_file) && nzchar(this_file) && file.exists(this_file)) {
  file.copy(this_file, script_target, overwrite = TRUE)
}

message("FIG4 completed: ", out_dir)

