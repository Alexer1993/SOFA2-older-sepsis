set.seed(2026)

project_root <- Sys.getenv("SOFA2_PROJECT_ROOT", unset = "")
if (!nzchar(project_root)) project_root <- normalizePath(file.path(getwd(), ".."), winslash = "/", mustWork = TRUE)
project_root <- gsub("\\\\", "/", project_root)

out_dir_env <- Sys.getenv("SOFA2_FIGURE2_OUT_DIR", unset = "")
out_dir <- if (nzchar(out_dir_env)) gsub("\\\\", "/", out_dir_env) else file.path(project_root, "outputs", "manuscript_figure2")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

required <- c("survival", "ggplot2", "dplyr", "splines", "gridExtra", "officer")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) stop("Missing packages: ", paste(missing, collapse = ", "))

data_path <- file.path(project_root, "data", "analysis_ready_current", "MIMIC_SOFA2_analysis_master_current.rds")
d0 <- readRDS(data_path)

parse_time <- function(x) {
  if (inherits(x, "POSIXct")) return(x)
  x <- as.character(x)
  x[trimws(x) %in% c("", "NA", "NaN", "NULL", "NaT")] <- NA_character_
  as.POSIXct(x, tz = "UTC", tryFormats = c(
    "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M",
    "%Y-%m-%dT%H:%M:%SZ", "%Y/%m/%d %H:%M:%S",
    "%Y/%m/%d %H:%M", "%Y-%m-%d", "%Y/%m/%d"
  ))
}
to_bin <- function(x) {
  if (is.logical(x)) return(as.integer(x))
  if (is.numeric(x) || is.integer(x)) return(as.integer(x > 0))
  z <- tolower(trimws(as.character(x)))
  ifelse(z %in% c("1", "yes", "y", "true", "t", "m", "male"), 1L,
         ifelse(z %in% c("0", "no", "n", "false", "f", "female"), 0L, NA_integer_))
}
make_factor <- function(x) {
  f <- factor(x)
  if (anyNA(f)) {
    f <- addNA(f)
    levels(f)[is.na(levels(f))] <- "Missing"
  }
  droplevels(f)
}
collapse_infection <- function(x) {
  z <- tolower(trimws(enc2utf8(as.character(x))))
  out <- rep("Other/undetermined", length(z))
  out[grepl("pulmonary|lung|respir|pneumonia", z)] <- "Pulmonary"
  out[grepl("urinary|urine|uti|renal|kidney", z)] <- "Urinary"
  out[grepl("abdominal|abdomen|biliary|gastro|gi|intra|periton|hepatobiliary", z)] <- "Abdominal"
  out[grepl("bloodstream|blood stream|bacteremia|catheter", z)] <- "Bloodstream"
  out[grepl("skin|soft tissue", z)] <- "Skin/soft tissue"
  out[is.na(z) | z == ""] <- "Other/undetermined"
  factor(out, levels = c("Pulmonary", "Urinary", "Abdominal", "Bloodstream", "Skin/soft tissue", "Other/undetermined"))
}
fmt_p <- function(p) {
  if (is.na(p)) return("P = NA")
  if (p < 0.001) return("P < 0.001")
  paste0("P = ", sprintf("%.3f", p))
}
mode_level <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) == 0) return(NA_character_)
  names(sort(table(x), decreasing = TRUE))[1]
}
drop_bad_covars <- function(data, covars) {
  keep <- character(0)
  dropped <- character(0)
  for (cv in covars) {
    if (!cv %in% names(data)) {
      dropped <- c(dropped, cv)
      next
    }
    if (is.factor(data[[cv]])) {
      data[[cv]] <- droplevels(data[[cv]])
      if (nlevels(data[[cv]]) >= 2) keep <- c(keep, cv) else dropped <- c(dropped, cv)
    } else {
      vals <- unique(data[[cv]][!is.na(data[[cv]])])
      if (length(vals) >= 2) keep <- c(keep, cv) else dropped <- c(dropped, cv)
    }
  }
  list(keep = keep, dropped = dropped)
}
cox_formula <- function(exposure_terms, covars) {
  rhs <- c(exposure_terms, covars)
  as.formula(paste("survival::Surv(time28, event28) ~", paste(rhs, collapse = " + ")))
}

icu_in <- parse_time(d0$icu_intime)
sepsis_time <- parse_time(d0$sepsis_time)
death_days_raw <- suppressWarnings(as.numeric(d0$death_days_from_icu))
event28 <- suppressWarnings(as.integer(d0$icu_28d_death))
death_days <- death_days_raw
time28 <- ifelse(event28 == 1, pmax(pmin(death_days, 28), 0.5), 28)
time28[is.na(time28) | time28 <= 0] <- 0.5

lactate_raw <- suppressWarnings(as.numeric(d0$lactate_first))
lactate_missing <- as.integer(is.na(lactate_raw))
lactate_imp <- lactate_raw
lactate_imp[is.na(lactate_imp)] <- stats::median(lactate_imp, na.rm = TRUE)

d <- d0 |>
  dplyr::mutate(
    time28 = .env$time28,
    event28 = .env$event28,
    sofa2 = as.numeric(.data$sofa2_dynamic24_max),
    age_m = as.numeric(.data$age),
    male = as.integer(.data$gender %in% c("M", "Male", "male", 1)),
    charlson_m = as.numeric(.data$charlson),
    infection_source_m = collapse_infection(.data$infection_site_main_enriched),
    sepsis_onset_h = as.numeric(difftime(.env$sepsis_time, .env$icu_in, units = "hours")),
    icu_admission_source_m = make_factor(dplyr::case_when(
      .data$admission_location == "EMERGENCY ROOM" ~ "Emergency department",
      .data$admission_location %in% c("PROCEDURE SITE", "PACU") ~ "Procedure/OR",
      .data$admission_location == "TRANSFER FROM HOSPITAL" ~ "Other hospital",
      .data$admission_location %in% c("PHYSICIAN REFERRAL", "WALK-IN/SELF REFERRAL", "CLINIC REFERRAL") ~ "Ward/clinic",
      TRUE ~ "Other/unknown"
    )),
    icu_type_m = make_factor(dplyr::case_when(
      .data$careunit %in% c("Medical Intensive Care Unit (MICU)", "Medical/Surgical Intensive Care Unit (MICU/SICU)") ~ "Medical ICU",
      .data$careunit %in% c("Cardiac Vascular Intensive Care Unit (CVICU)", "Coronary Care Unit (CCU)") ~ "Cardiovascular ICU",
      .data$careunit %in% c("Surgical Intensive Care Unit (SICU)", "Trauma SICU (TSICU)") ~ "Surgical/trauma ICU",
      .data$careunit %in% c("Neuro Surgical Intensive Care Unit (Neuro SICU)", "Surgery/Vascular/Intermediate", "Surgery/Trauma") ~ "Neuro/surgical intermediate",
      TRUE ~ "Other ICU"
    )),
    lactate_imp = .env$lactate_imp,
    sofa2_q = dplyr::case_when(
      .data$sofa2 >= 1 & .data$sofa2 <= 5 ~ "Q1, 1-5",
      .data$sofa2 >= 6 & .data$sofa2 <= 7 ~ "Q2, 6-7",
      .data$sofa2 >= 8 & .data$sofa2 <= 9 ~ "Q3, 8-9",
      .data$sofa2 >= 10 ~ "Q4, 10-21",
      TRUE ~ NA_character_
    ),
    sofa2_q = factor(.data$sofa2_q, levels = c("Q1, 1-5", "Q2, 6-7", "Q3, 8-9", "Q4, 10-21"))
  )

base_covars <- c("age_m", "male", "charlson_m", "infection_source_m", "sepsis_onset_h",
                 "icu_admission_source_m", "icu_type_m", "lactate_imp")
model_vars <- c("time28", "event28", "sofa2", base_covars)
dm <- d[, model_vars]
dm <- dm[stats::complete.cases(dm), ]
dm$infection_source_m <- droplevels(dm$infection_source_m)
dm$icu_admission_source_m <- droplevels(dm$icu_admission_source_m)
dm$icu_type_m <- droplevels(dm$icu_type_m)
covar_status <- drop_bad_covars(dm, base_covars)
model_covars <- covar_status$keep

form_full <- cox_formula("splines::ns(sofa2, df = 4)", model_covars)
form_linear <- cox_formula("sofa2", model_covars)
form_no_sofa2 <- cox_formula(character(0), model_covars)

fit_full <- survival::coxph(form_full, data = dm, ties = "efron", x = TRUE)
fit_linear <- survival::coxph(form_linear, data = dm, ties = "efron", x = TRUE)
fit_no_sofa2 <- survival::coxph(form_no_sofa2, data = dm, ties = "efron", x = TRUE)

lrt_overall <- stats::anova(fit_no_sofa2, fit_full, test = "LRT")
lrt_nonlinear <- stats::anova(fit_linear, fit_full, test = "LRT")
p_overall <- lrt_overall$`Pr(>|Chi|)`[2]
p_nonlinear <- lrt_nonlinear$`Pr(>|Chi|)`[2]

ref_sofa2 <- 5
grid_sofa2 <- seq(stats::quantile(dm$sofa2, 0.01, na.rm = TRUE), stats::quantile(dm$sofa2, 0.99, na.rm = TRUE), length.out = 220)
ref_row <- dm[1, ]
ref_row$sofa2 <- ref_sofa2
ref_row$age_m <- stats::median(dm$age_m, na.rm = TRUE)
ref_row$male <- 0
ref_row$charlson_m <- stats::median(dm$charlson_m, na.rm = TRUE)
ref_row$sepsis_onset_h <- stats::median(dm$sepsis_onset_h, na.rm = TRUE)
ref_row$lactate_imp <- stats::median(dm$lactate_imp, na.rm = TRUE)
if ("infection_source_m" %in% names(ref_row)) ref_row$infection_source_m <- factor(mode_level(dm$infection_source_m), levels = levels(dm$infection_source_m))
if ("icu_admission_source_m" %in% names(ref_row)) ref_row$icu_admission_source_m <- factor(mode_level(dm$icu_admission_source_m), levels = levels(dm$icu_admission_source_m))
if ("icu_type_m" %in% names(ref_row)) ref_row$icu_type_m <- factor(mode_level(dm$icu_type_m), levels = levels(dm$icu_type_m))

pred_grid <- ref_row[rep(1, length(grid_sofa2)), ]
pred_grid$sofa2 <- grid_sofa2
mm_grid <- predict(fit_full, newdata = pred_grid, type = "lp", se.fit = TRUE)
mm_ref <- predict(fit_full, newdata = ref_row, type = "lp", se.fit = TRUE)
pred <- data.frame(
  sofa2 = grid_sofa2,
  log_hr = as.numeric(mm_grid$fit - mm_ref$fit),
  se = as.numeric(mm_grid$se.fit)
)
pred$hr <- exp(pred$log_hr)
pred$lower <- exp(pred$log_hr - 1.96 * pred$se)
pred$upper <- exp(pred$log_hr + 1.96 * pred$se)
pred$lower <- pmax(pred$lower, 0.05)
pred$upper <- pmin(pred$upper, 12)

base_theme <- ggplot2::theme_classic(base_family = "Arial", base_size = 8) +
  ggplot2::theme(
    axis.title = ggplot2::element_text(size = 8.5),
    axis.text = ggplot2::element_text(size = 7.5, color = "black"),
    legend.title = ggplot2::element_blank(),
    legend.text = ggplot2::element_text(size = 7),
    plot.margin = ggplot2::margin(7, 8, 5, 8),
    plot.tag = ggplot2::element_text(face = "bold", size = 12, hjust = 0, vjust = 1)
  )

p_rcs <- ggplot2::ggplot(pred, ggplot2::aes(x = sofa2, y = hr)) +
  ggplot2::geom_ribbon(ggplot2::aes(ymin = lower, ymax = upper), fill = "#2F6B9A", alpha = 0.18) +
  ggplot2::geom_line(color = "#1F4E79", linewidth = 0.75) +
  ggplot2::geom_hline(yintercept = 1, linetype = "dashed", color = "grey45", linewidth = 0.35) +
  ggplot2::scale_x_continuous(breaks = seq(1, 21, by = 4), limits = c(1, 21), expand = c(0.01, 0)) +
  ggplot2::scale_y_continuous(trans = "log10", breaks = c(0.5, 1, 2, 4, 8), labels = c("0.5", "1", "2", "4", "8"), limits = c(0.35, 9)) +
  ggplot2::labs(x = "Baseline SOFA-2", y = "Hazard ratio for 28-day mortality") +
  ggplot2::annotate("text", x = 1.5, y = 7.8, hjust = 0, vjust = 1, size = 2.6, family = "Arial",
                    label = paste0("P-overall ", sub("^P ", "", fmt_p(p_overall)), "\nP-nonlinear ", sub("^P ", "", fmt_p(p_nonlinear)))) +
  base_theme +
  ggplot2::labs(tag = "A")

dkm <- d[, c("time28", "event28", "sofa2", "sofa2_q")]
dkm <- dkm[stats::complete.cases(dkm), ]
surv_fit <- survival::survfit(survival::Surv(time28, event28) ~ sofa2_q, data = dkm)
surv_diff <- survival::survdiff(survival::Surv(time28, event28) ~ sofa2_q, data = dkm)
logrank_p <- 1 - stats::pchisq(surv_diff$chisq, length(surv_diff$n) - 1)

km_sum <- summary(surv_fit, times = seq(0, 28, by = 0.25))
km_df <- data.frame(
  time = km_sum$time,
  surv = km_sum$surv,
  lower = km_sum$lower,
  upper = km_sum$upper,
  strata = sub("^sofa2_q=", "", km_sum$strata)
)
km_df$strata <- factor(km_df$strata, levels = levels(dkm$sofa2_q))
pal <- c("Q1, 1-5" = "#1F77B4", "Q2, 6-7" = "#2CA02C", "Q3, 8-9" = "#FF7F0E", "Q4, 10-21" = "#D62728")

p_km <- ggplot2::ggplot(km_df, ggplot2::aes(x = time, y = surv, color = strata)) +
  ggplot2::geom_step(linewidth = 0.65) +
  ggplot2::scale_color_manual(values = pal) +
  ggplot2::scale_x_continuous(breaks = seq(0, 28, 7), limits = c(0, 28), expand = c(0.01, 0)) +
  ggplot2::scale_y_continuous(labels = function(x) sprintf("%.0f", x * 100), limits = c(0.45, 1.0), expand = c(0.01, 0)) +
  ggplot2::labs(x = "Days since ICU admission", y = "Survival probability (%)") +
  ggplot2::annotate("text", x = 1.0, y = 0.475, hjust = 0, vjust = 0, size = 2.6, family = "Arial",
                    label = paste0("Log-rank ", fmt_p(logrank_p))) +
  base_theme +
  ggplot2::theme(legend.position = "top",
                 legend.direction = "horizontal",
                 legend.key.width = grid::unit(0.55, "cm"),
                 legend.spacing.x = grid::unit(0.18, "cm"),
                 legend.margin = ggplot2::margin(0, 0, 1, 0),
                 legend.background = ggplot2::element_blank()) +
  ggplot2::labs(tag = "B")

risk_times <- c(0, 7, 14, 21, 28)
risk_sum <- summary(surv_fit, times = risk_times)
risk_df <- data.frame(
  time = risk_sum$time,
  n_risk = risk_sum$n.risk,
  strata = sub("^sofa2_q=", "", risk_sum$strata)
)
risk_df$strata <- factor(risk_df$strata, levels = rev(levels(dkm$sofa2_q)))
risk_df$label <- format(risk_df$n_risk, big.mark = ",")
risk_title <- data.frame(time = -8.0, strata = factor(rev(levels(dkm$sofa2_q)), levels = rev(levels(dkm$sofa2_q))),
                         label = rev(levels(dkm$sofa2_q)))

p_risk <- ggplot2::ggplot(risk_df, ggplot2::aes(x = time, y = strata)) +
  ggplot2::geom_text(ggplot2::aes(label = label), size = 2.25, family = "Arial", color = "black") +
  ggplot2::geom_text(data = risk_title, ggplot2::aes(x = time, y = strata, label = label, color = label),
                     inherit.aes = FALSE, size = 2.25, family = "Arial", hjust = 0) +
  ggplot2::scale_color_manual(values = pal, guide = "none") +
  ggplot2::scale_x_continuous(breaks = risk_times, limits = c(-8.5, 29.3), expand = c(0, 0)) +
  ggplot2::labs(x = NULL, y = NULL) +
  ggplot2::theme_void(base_family = "Arial", base_size = 7.5) +
  ggplot2::coord_cartesian(clip = "off") +
  ggplot2::theme(plot.margin = ggplot2::margin(8, 8, 5, 8),
                 axis.text.x = ggplot2::element_text(color = "black", size = 7),
                 axis.ticks.x = ggplot2::element_line(color = "black", linewidth = 0.25),
                 axis.line.x = ggplot2::element_line(color = "black", linewidth = 0.25)) +
  ggplot2::annotate("text", x = -8.0, y = 4.65, label = "No. at risk", hjust = 0, size = 2.35, family = "Arial", fontface = "bold")

panel_b <- gridExtra::arrangeGrob(p_km, p_risk, ncol = 1, heights = c(3.3, 0.9))
fig <- gridExtra::arrangeGrob(p_rcs, panel_b, ncol = 2, widths = c(1, 1.22))

pdf_path <- file.path(out_dir, "Figure2_RCS_KM_SOFA2_28d_mortality.pdf")
png_path <- file.path(out_dir, "Figure2_RCS_KM_SOFA2_28d_mortality.png")
tiff_path <- file.path(out_dir, "Figure2_RCS_KM_SOFA2_28d_mortality.tiff")

ggplot2::ggsave(pdf_path, fig, width = 180, height = 95, units = "mm", device = grDevices::cairo_pdf)
ggplot2::ggsave(png_path, fig, width = 180, height = 95, units = "mm", dpi = 300, bg = "white")
ggplot2::ggsave(tiff_path, fig, width = 180, height = 95, units = "mm", dpi = 600, compression = "lzw", bg = "white")

legend_text <- paste(
  "Figure 2. Association of baseline SOFA-2 with ICU-admission-based 28-day mortality.",
  "(A) Restricted cubic spline analysis showing the adjusted association between baseline SOFA-2 and 28-day mortality. The model was adjusted for age, sex, Charlson Comorbidity Index, infection source, sepsis onset after ICU admission, ICU admission source, ICU type, and lactate. The solid line indicates the estimated hazard ratio relative to a reference SOFA-2 value of 5, and the shaded area indicates the 95% confidence interval.",
  "(B) Kaplan-Meier survival curves according to baseline SOFA-2 quartiles. Quartiles were defined as Q1, 1-5; Q2, 6-7; Q3, 8-9; and Q4, 10-21. Differences across groups were assessed using the log-rank test.",
  sep = " "
)
legend_txt <- file.path(out_dir, "Figure2_legend.txt")
writeLines(legend_text, legend_txt, useBytes = TRUE)
legend_docx <- file.path(out_dir, "Figure2_legend.docx")
doc <- officer::read_docx()
doc <- officer::body_add_par(doc, "Figure 2 Legend", style = "heading 1")
doc <- officer::body_add_par(doc, legend_text, style = "Normal")
print(doc, target = legend_docx)

qc <- data.frame(
  item = c("source_data", "n_model_rcs", "events_model_rcs", "n_km", "events_km", "p_overall", "p_nonlinear", "logrank_p",
           "sofa2_q1_n", "sofa2_q2_n", "sofa2_q3_n", "sofa2_q4_n", "reference_sofa2", "figure_width_mm", "figure_height_mm"),
  value = c(data_path, nrow(dm), sum(dm$event28 == 1), nrow(dkm), sum(dkm$event28 == 1), p_overall, p_nonlinear, logrank_p,
            unname(table(dkm$sofa2_q)[1]), unname(table(dkm$sofa2_q)[2]), unname(table(dkm$sofa2_q)[3]), unname(table(dkm$sofa2_q)[4]),
            ref_sofa2, 180, 95)
)
utils::write.csv(qc, file.path(out_dir, "Figure2_quality_check.csv"), row.names = FALSE)
utils::write.csv(pred, file.path(out_dir, "Figure2A_RCS_curve_data.csv"), row.names = FALSE)
utils::write.csv(risk_df, file.path(out_dir, "Figure2B_KM_risk_table.csv"), row.names = FALSE)

message("Figure 2 completed: ", out_dir)

