suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(survival)
  library(patchwork)
  library(scales)
  library(cluster)
  library(cowplot)
  library(grid)
})

root <- normalizePath(Sys.getenv("SOFA2_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
out_dir <- file.path(root, "outputs", "manuscript_figures_v3")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

read_csv2 <- function(file) utils::read.csv(file, check.names = FALSE, stringsAsFactors = FALSE)
write_csv2 <- function(x, file) utils::write.csv(x, file, row.names = FALSE, fileEncoding = "UTF-8")

theme_pub <- function(base_size = 11) {
  theme_classic(base_size = base_size) +
    theme(
      plot.title = element_text(face = "bold", hjust = 0, size = base_size + 2),
      axis.title = element_text(face = "bold"),
      legend.title = element_blank(),
      legend.position = "right",
      strip.background = element_blank(),
      strip.text = element_text(face = "bold", size = base_size + 1),
      plot.margin = margin(6, 6, 6, 6)
    )
}

save_fig <- function(plot, name, width = 7, height = 5, dpi = 320) {
  grDevices::png(file.path(out_dir, paste0(name, ".png")), width = width, height = height, units = "in", res = dpi, bg = "white")
  print(plot)
  grDevices::dev.off()
  ggsave(file.path(out_dir, paste0(name, ".pdf")), plot, width = width, height = height, bg = "white")
}

fmt_p <- function(p) ifelse(is.na(p), "", ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
fmt_pct <- function(x) sprintf("%.1f", 100 * x)

part1_tables <- file.path(root, "outputs", "internal_part1_severity_logistic_rcs", "tables")
part2_tables <- file.path(root, "outputs", "internal_part2_sofa2_icu28_mortality", "tables")
part3_tables <- file.path(root, "outputs", "internal_part3_prediction_performance", "tables")
part4_tables <- file.path(root, "outputs", "internal_part4_cutoff_trajectory_subgroup_sensitivity", "tables")

line_cols <- c("SOFA" = "#2C7FB8", "SOFA-2" = "#D95F02",
               "Low SOFA-2" = "#2C7FB8", "High SOFA-2" = "#D95F02")

# FIG1 - final cohort flow; no SOFA-2-based exclusion step.
box_df <- tibble::tribble(
  ~id, ~x, ~y, ~w, ~h, ~label, ~fill,
  "mimic0", 0.28, 0.88, 0.34, 0.11, "MIMIC-IV after age >65, first ICU, and ICU LOS >=48 h\n(n = 23,174)", "#DDEBF7",
  "eicu0",  0.72, 0.88, 0.34, 0.11, "eICU after age >65, first ICU, and ICU LOS >=48 h\n(n = 34,481)", "#B4C7E7",
  "exclude", 0.50, 0.62, 0.64, 0.17, "Final non-SOFA eligibility exclusions:\nMIMIC: did not meet Sepsis-3 within 0-48 h (n = 10,531)\n\neICU: not in final adult sepsis-source cohort (n = 21,844);\nmissing/out-of-window sepsis timing (n = 1,200)", "#FFFFFF",
  "mimic1", 0.28, 0.38, 0.32, 0.10, "Final MIMIC derivation cohort\n(n = 12,643)", "#DDEBF7",
  "eicu1",  0.72, 0.38, 0.32, 0.10, "Final eICU validation cohort\n(n = 11,437)", "#B4C7E7",
  "analysis", 0.50, 0.13, 0.80, 0.09, "Further analysis:\nSOFA-2 association, prediction, pragmatic cutoff, early trajectories, external validation, and exploratory subgroup analyses", "#FFFFFF"
)
segment_df <- tibble::tribble(
  ~x, ~y, ~xend, ~yend, ~arrowed,
  0.28, 0.83, 0.28, 0.70, TRUE,
  0.72, 0.83, 0.72, 0.70, TRUE,
  0.28, 0.70, 0.50, 0.70, FALSE,
  0.72, 0.70, 0.50, 0.70, FALSE,
  0.50, 0.70, 0.50, 0.695, TRUE,
  0.50, 0.545, 0.50, 0.49, TRUE,
  0.50, 0.49, 0.28, 0.49, FALSE,
  0.50, 0.49, 0.72, 0.49, FALSE,
  0.28, 0.49, 0.28, 0.43, TRUE,
  0.72, 0.49, 0.72, 0.43, TRUE,
  0.28, 0.33, 0.28, 0.23, TRUE,
  0.72, 0.33, 0.72, 0.23, TRUE,
  0.28, 0.23, 0.50, 0.23, FALSE,
  0.72, 0.23, 0.50, 0.23, FALSE,
  0.50, 0.23, 0.50, 0.175, TRUE
)
p_fig1 <- ggplot() +
  geom_segment(data = segment_df %>% filter(!arrowed), aes(x, y, xend = xend, yend = yend),
               linewidth = 0.55, color = "black") +
  geom_segment(data = segment_df %>% filter(arrowed), aes(x, y, xend = xend, yend = yend),
               linewidth = 0.55, color = "black",
               arrow = arrow(length = unit(0.16, "in"), ends = "last", type = "closed")) +
  geom_rect(data = box_df, aes(xmin = x - w/2, xmax = x + w/2, ymin = y - h/2, ymax = y + h/2, fill = fill),
            color = "black", linewidth = 0.8) +
  geom_text(data = box_df, aes(x, y, label = label), size = 3.4, lineheight = 0.95) +
  scale_fill_identity() +
  coord_cartesian(xlim = c(0.04, 0.96), ylim = c(0.03, 0.97), expand = FALSE) +
  theme_void()
save_fig(p_fig1, "FIG1_flowchart_template_style", 10, 7.5)

# FIG2 - RCS + KM.
rcs_m3 <- read_csv2(file.path(part2_tables, "RCS_curve_data_Model_3.csv"))
rcs_p <- read_csv2(file.path(part2_tables, "Table5_RCS_pvalues_SOFA2_ICU28_mortality.csv")) %>% filter(model == "Model 3") %>% slice(1)
p2a <- ggplot(rcs_m3, aes(baseline_sofa2, HR)) +
  geom_ribbon(aes(ymin = lower95, ymax = upper95), fill = "#D95F02", alpha = 0.18) +
  geom_line(color = "#D95F02", linewidth = 1.05) +
  geom_hline(yintercept = 1, linetype = "dashed", color = "grey40") +
  annotate("text", x = min(rcs_m3$baseline_sofa2), y = max(rcs_m3$upper95) * 0.90,
           hjust = 0, label = paste0("P overall ", fmt_p(rcs_p$p_overall), "\nP nonlinear ", fmt_p(rcs_p$p_nonlinear)), size = 4) +
  labs(title = "A", x = "Baseline SOFA-2", y = "Hazard ratio for ICU 28-day mortality") +
  theme_pub()
km_q <- read_csv2(file.path(part2_tables, "KM_curve_data_SOFA2_groups_ICU28_mortality.csv")) %>%
  mutate(group = factor(strata, levels = c("Q1_1_5", "Q2_6_7", "Q3_8_9", "Q4_10_plus"),
                        labels = c("Q1: 1-5", "Q2: 6-7", "Q3: 8-9", "Q4: >=10")))
p2b <- ggplot(km_q, aes(time, 1 - surv, color = group)) +
  geom_step(linewidth = 0.95) +
  scale_color_manual(values = c("#1B9E77", "#7570B3", "#E6AB02", "#D95F02")) +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  labs(title = "B", x = "Days after ICU admission", y = "Cumulative ICU 28-day mortality") +
  theme_pub()
save_fig(p2a + p2b, "FIG2_SOFA2_RCS_KM", 12, 5)

# FIG3 - AUC + calibration + DCA in one figure.
auc <- read_csv2(file.path(part3_tables, "Table2_time_dependent_AUC_internal_external.csv")) %>%
  filter(cohort == "MIMIC", model %in% c("SOFA", "SOFA-2"), !is.na(AUC)) %>%
  mutate(model = factor(model, levels = c("SOFA", "SOFA-2")))
p3a <- ggplot(auc, aes(time, AUC, color = model, group = model)) +
  geom_line(linewidth = 1) + geom_point(size = 2.2) +
  scale_color_manual(values = line_cols) +
  scale_x_continuous(breaks = c(3, 7, 14, 28), limits = c(3, 28)) +
  labs(title = "A", x = "Prediction horizon, days", y = "AUC") +
  theme_pub()
cal_dec <- read_csv2(file.path(part3_tables, "Table4_calibration_28d_deciles_internal_external.csv")) %>%
  filter(cohort == "MIMIC", model %in% c("SOFA", "SOFA-2")) %>%
  mutate(model = factor(model, levels = c("SOFA", "SOFA-2")))
p3b <- ggplot(cal_dec, aes(mean_pred, observed, color = model)) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey45") +
  geom_line(linewidth = 0.95) + geom_point(size = 2.1) +
  scale_color_manual(values = line_cols) +
  coord_equal() +
  labs(title = "B", x = "Mean predicted risk", y = "Observed event rate") +
  theme_pub()
dca_wide <- read_csv2(file.path(part3_tables, "Table6_DCA_28d_internal_external.csv"))
dca <- bind_rows(lapply(c("SOFA", "SOFA-2"), function(m) {
  tibble(cohort = dca_wide[[paste0(m, ".cohort")]], model = m,
         threshold = dca_wide[[paste0(m, ".threshold")]],
         net_benefit = dca_wide[[paste0(m, ".net_benefit")]])
})) %>% filter(cohort == "MIMIC", !is.na(threshold), threshold <= 0.60)
p3c <- ggplot(dca, aes(threshold, net_benefit, color = model)) +
  geom_line(linewidth = 0.95) +
  scale_color_manual(values = line_cols) +
  labs(title = "C", x = "Threshold probability", y = "Net benefit") +
  theme_pub()
save_fig(p3a + p3b + p3c, "FIG3_prediction_performance_MIMIC", 15, 5)

# FIG4 - MaxStat and MIMIC KM only.
mimic <- readRDS(file.path(root, "data", "processed", "SOFA2_latest_sofa_with_outcomes.rds"))
eicu_pred <- readRDS(file.path(root, "data", "processed", "eicu_external_prediction_cleaned.rds"))
cutoff <- read_csv2(file.path(part4_tables, "Table1_MaxStat_SOFA2_cutoff.csv"))$cutoff[1]
mimic_surv <- mimic %>% transmute(time28 = ifelse(icu_28d_death == 1, pmin(pmax(as.numeric(death_days_from_icu), 0.01), 28), 28),
                                  event28 = as.integer(icu_28d_death == 1),
                                  sofa2 = as.numeric(sofa2_dynamic24_max)) %>%
  filter(!is.na(time28), !is.na(event28), !is.na(sofa2))
mx <- maxstat::maxstat.test(Surv(time28, event28) ~ sofa2, data = mimic_surv, smethod = "LogRank",
                            pmethod = "condMC", B = 1999, minprop = 0.1, maxprop = 0.9)
stat_df <- data.frame(cutpoint = mx$cuts, statistic = mx$stats)
p4a <- ggplot(stat_df, aes(cutpoint, statistic)) +
  geom_line(color = "#4D4D4D", linewidth = 0.9) +
  geom_vline(xintercept = cutoff, linetype = "dashed", color = "#D95F02") +
  annotate("text", x = cutoff + 0.1, y = max(stat_df$statistic), hjust = 0, vjust = 1,
           label = paste0("SOFA-2 > ", cutoff), size = 4) +
  labs(title = "A", x = "Candidate SOFA-2 cutpoint", y = "Standardized log-rank statistic") +
  theme_pub()
km_cut_data <- mimic_surv %>% mutate(group = factor(ifelse(sofa2 > cutoff, "High SOFA-2", "Low SOFA-2"),
                                                     levels = c("Low SOFA-2", "High SOFA-2")))
fit_cut <- survfit(Surv(time28, event28) ~ group, data = km_cut_data)
s_cut <- summary(fit_cut, times = sort(unique(c(0:28, mimic_surv$time28))))
km_cut <- tibble(time = s_cut$time, surv = s_cut$surv, group = sub("^group=", "", s_cut$strata))
p4b <- ggplot(km_cut, aes(time, 1 - surv, color = group)) +
  geom_step(linewidth = 0.95) +
  scale_color_manual(values = line_cols) +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  labs(title = "B", x = "Days after ICU admission", y = "Cumulative ICU 28-day mortality") +
  theme_pub()
save_fig(p4a + p4b, "FIG4_MaxStat_cutoff_MIMIC_KM", 12, 5)

# FIG5 - MIMIC trajectories.
traj_summary <- read_csv2(file.path(part4_tables, "Table5_Kmeans_trajectory_summary.csv"))
traj_long <- traj_summary %>%
  select(trajectory_class, mean_d1, mean_d2, mean_d3, n) %>%
  pivot_longer(starts_with("mean_d"), names_to = "day", values_to = "mean_sofa2") %>%
  mutate(day = as.integer(gsub("mean_d", "", day)))
p5 <- ggplot(traj_long, aes(day, mean_sofa2, color = trajectory_class, group = trajectory_class)) +
  geom_line(linewidth = 1.05) + geom_point(size = 2.4) +
  scale_x_continuous(breaks = 1:3, labels = c("Day 1", "Day 2", "Day 3")) +
  labs(x = "Time window", y = "Mean SOFA-2") +
  theme_pub()
save_fig(p5, "FIG5_MIMIC_SOFA2_trajectories", 7, 5)

# FIG6 - external validation.
auc_e <- read_csv2(file.path(part3_tables, "Table2_time_dependent_AUC_internal_external.csv")) %>%
  filter(cohort == "eICU", model %in% c("SOFA", "SOFA-2"), !is.na(AUC)) %>%
  mutate(model = factor(model, levels = c("SOFA", "SOFA-2")))
p6a <- ggplot(auc_e, aes(time, AUC, color = model, group = model)) +
  geom_line(linewidth = 1) + geom_point(size = 2.2) +
  scale_color_manual(values = line_cols) +
  scale_x_continuous(breaks = c(3, 7, 14, 28), limits = c(3, 28)) +
  labs(title = "A", x = "Prediction horizon, days", y = "AUC") +
  theme_pub()
eicu_surv <- eicu_pred %>% transmute(time28 = as.numeric(time28), event28 = as.integer(event28), sofa2 = as.numeric(sofa2)) %>%
  filter(!is.na(time28), !is.na(event28), !is.na(sofa2)) %>%
  mutate(group = factor(ifelse(sofa2 > cutoff, "High SOFA-2", "Low SOFA-2"), levels = c("Low SOFA-2", "High SOFA-2")))
fit_e <- survfit(Surv(time28, event28) ~ group, data = eicu_surv)
s_e <- summary(fit_e, times = sort(unique(c(0:28, eicu_surv$time28))))
km_e <- tibble(time = s_e$time, surv = s_e$surv, group = sub("^group=", "", s_e$strata))
p6b <- ggplot(km_e, aes(time, 1 - surv, color = group)) +
  geom_step(linewidth = 0.95) +
  scale_color_manual(values = line_cols) +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  labs(title = "B", x = "Days after ICU admission", y = "Cumulative ICU 28-day mortality") +
  theme_pub()
part4_obj <- readRDS(file.path(root, "outputs", "internal_part4_cutoff_trajectory_subgroup_sensitivity", "models", "Part4_cutoff_trajectory_subgroup_sensitivity_objects.rds"))
internal_centers <- part4_obj$kmeans_k4$centers
internal_scaled <- scale(part4_obj$trajectory_data[, c("sofa2_d1", "sofa2_d2", "sofa2_d3")])
sc_center <- attr(internal_scaled, "scaled:center")
sc_scale <- attr(internal_scaled, "scaled:scale")
class_map <- part4_obj$trajectory_data %>% count(trajectory_raw, trajectory_class, sort = TRUE) %>% group_by(trajectory_raw) %>% slice(1) %>% ungroup()
eicu_full <- readRDS(file.path(root, "data", "processed", "eicu_external_validation_final_updated.rds"))
eicu_traj <- eicu_full %>% transmute(
  sofa2_d1 = as.numeric(sofa2_dynamic_24h_max),
  sofa2_d2 = as.numeric(sofa2_dynamic_48h_max),
  sofa2_d3 = as.numeric(sofa2_dynamic_72h_max),
  event28 = as.integer(mortality_28 == 1)
) %>% filter(!is.na(sofa2_d1), !is.na(sofa2_d2), !is.na(sofa2_d3), !is.na(event28))
eicu_scaled <- sweep(as.matrix(eicu_traj[, c("sofa2_d1", "sofa2_d2", "sofa2_d3")]), 2, sc_center, "-")
eicu_scaled <- sweep(eicu_scaled, 2, sc_scale, "/")
dist_to_center <- sapply(seq_len(nrow(internal_centers)), function(i) {
  rowSums((eicu_scaled - matrix(internal_centers[i, ], nrow(eicu_scaled), ncol(eicu_scaled), byrow = TRUE))^2)
})
eicu_traj$trajectory_raw <- apply(dist_to_center, 1, which.min)
eicu_traj <- eicu_traj %>% left_join(class_map, by = "trajectory_raw")
eicu_traj_sum <- eicu_traj %>% group_by(trajectory_class) %>%
  summarise(n = n(), mean_d1 = mean(sofa2_d1), mean_d2 = mean(sofa2_d2), mean_d3 = mean(sofa2_d3), .groups = "drop")
write_csv2(eicu_traj_sum, file.path(out_dir, "FIG6C_eICU_trajectory_validation_summary.csv"))
p6c <- eicu_traj_sum %>%
  pivot_longer(starts_with("mean_d"), names_to = "day", values_to = "mean_sofa2") %>%
  mutate(day = as.integer(gsub("mean_d", "", day))) %>%
  ggplot(aes(day, mean_sofa2, color = trajectory_class, group = trajectory_class)) +
  geom_line(linewidth = 1.05) + geom_point(size = 2.4) +
  scale_x_continuous(breaks = 1:3, labels = c("Day 1", "Day 2", "Day 3")) +
  labs(title = "C", x = "Time window", y = "Mean SOFA-2") +
  theme_pub()
save_fig(p6a + p6b + p6c, "FIG6_external_validation", 15, 5)

# FIG7 - table-style subgroup forest following provided template.
ana_forest <- part4_obj$ana %>%
  mutate(
    high_sofa2 = as.integer(sofa2 > cutoff),
    age_group = cut(age_m, breaks = c(65, 75, 85, Inf), right = FALSE, labels = c("65-74", "75-84", ">=85")),
    sex_group = ifelse(male == 1, "Male", "Female"),
    malnutrition_group = ifelse(malnutrition_m == 1, "Yes", "No"),
    dementia_group = ifelse(dementia_m == 1, "Yes", "No"),
    ckd_group = ifelse(ckd_m == 1, "Yes", "No"),
    chf_group = ifelse(chf_m == 1, "Yes", "No"),
    diabetes_group = ifelse(diabetes_m == 1, "Yes", "No"),
    lactate_group = ifelse(lactate_imp > 2, ">2", "<=2")
  )
sub_vars <- c(
  "Age" = "age_group",
  "Sex" = "sex_group",
  "Malnutrition" = "malnutrition_group",
  "Dementia" = "dementia_group",
  "CKD" = "ckd_group",
  "CHF" = "chf_group",
  "Diabetes" = "diabetes_group",
  "Baseline lactate" = "lactate_group"
)
base_cov <- c("age_m", "male", "charlson_m", "infection_source_m", "sepsis_onset_h",
              "icu_admission_source_m", "icu_type_m", "lactate_imp", "lactate_missing")
cox_row <- function(dat, covs) {
  fit <- coxph(as.formula(paste("Surv(time28, event28) ~ high_sofa2 +", paste(covs, collapse = " + "))), data = dat)
  s <- summary(fit)
  tibble(
    n = nrow(dat),
    HR = s$conf.int["high_sofa2", "exp(coef)"],
    lower95 = s$conf.int["high_sofa2", "lower .95"],
    upper95 = s$conf.int["high_sofa2", "upper .95"],
    p = s$coef["high_sofa2", "Pr(>|z|)"]
  )
}
interaction_p <- function(var, covs) {
  d <- ana_forest %>% filter(!is.na(.data[[var]]))
  f0 <- as.formula(paste("Surv(time28, event28) ~ high_sofa2 + factor(", var, ") +", paste(covs, collapse = " + ")))
  f1 <- as.formula(paste("Surv(time28, event28) ~ high_sofa2 * factor(", var, ") +", paste(covs, collapse = " + ")))
  tryCatch({
    a <- anova(coxph(f0, data = d), coxph(f1, data = d), test = "LRT")
    a$`Pr(>|Chi|)`[2]
  }, error = function(e) NA_real_)
}
overall <- cox_row(ana_forest, base_cov) %>%
  mutate(row_type = "data", Variable = "Overall", Percent = 100, HR_CI = sprintf("%.2f (%.2f to %.2f)", HR, lower95, upper95),
         p_text = fmt_p(p), p_int_text = "")
forest_blocks <- bind_rows(lapply(names(sub_vars), function(lbl) {
  var <- unname(sub_vars[[lbl]])
  covs <- setdiff(base_cov, c(if (var == "age_group") "age_m", if (var == "sex_group") "male", if (var == "lactate_group") "lactate_imp"))
  p_int <- interaction_p(var, covs)
  header <- tibble(row_type = "header", Variable = lbl, n = NA_integer_, Percent = NA_real_, HR = NA_real_,
                   lower95 = NA_real_, upper95 = NA_real_, HR_CI = "", p_text = "", p_int_text = fmt_p(p_int))
  levs <- na.omit(unique(ana_forest[[var]]))
  rows <- bind_rows(lapply(levs, function(lv) {
    dat <- ana_forest %>% filter(.data[[var]] == lv)
    cox_row(dat, covs) %>%
      mutate(row_type = "data", Variable = paste0("   ", as.character(lv)),
             Percent = 100 * n / nrow(ana_forest), HR_CI = sprintf("%.2f (%.2f to %.2f)", HR, lower95, upper95),
             p_text = fmt_p(p), p_int_text = "")
  }))
  bind_rows(header, rows)
}))
forest_df <- bind_rows(
  tibble(row_type = "column_header", Variable = "Variable", n = NA_integer_, Percent = NA_real_, HR = NA_real_,
         lower95 = NA_real_, upper95 = NA_real_, HR_CI = "HR (95% CI)", p_text = "P value", p_int_text = "P for interaction"),
  overall,
  forest_blocks
) %>%
  mutate(Count = ifelse(is.na(n), "", as.character(n)),
         Percent_text = ifelse(is.na(Percent), "", sprintf("%.1f", Percent)),
         fontface = ifelse(row_type %in% c("column_header", "header"), "bold", "plain"),
         y = rev(seq_len(n())))
write_csv2(forest_df, file.path(out_dir, "FIG7_subgroup_forest_template_style_table.csv"))
bg <- tibble(y = forest_df$y, shade = rep(c(TRUE, FALSE), length.out = nrow(forest_df)))
g_left <- ggplot(forest_df, aes(y = y)) +
  geom_rect(data = bg %>% filter(shade), aes(ymin = y - 0.5, ymax = y + 0.5), xmin = -Inf, xmax = Inf, fill = "#EEF2F1", inherit.aes = FALSE) +
  geom_text(aes(x = 0.00, label = Variable, fontface = fontface), hjust = 0, size = 3.2) +
  geom_text(aes(x = 0.50, label = ifelse(row_type == "column_header", "Count", Count), fontface = fontface), hjust = 0, size = 3.2) +
  geom_text(aes(x = 0.72, label = ifelse(row_type == "column_header", "Percent", Percent_text), fontface = fontface), hjust = 0, size = 3.2) +
  geom_text(aes(x = 1.00, label = HR_CI, fontface = fontface), hjust = 0, size = 3.2) +
  coord_cartesian(xlim = c(-0.03, 1.55), ylim = c(0.5, max(forest_df$y) + 0.6), expand = FALSE) +
  theme_void()
g_mid <- ggplot(forest_df, aes(y = y)) +
  geom_rect(data = bg %>% filter(shade), aes(ymin = y - 0.5, ymax = y + 0.5), xmin = 0.75, xmax = 2.4, fill = "#EEF2F1", inherit.aes = FALSE) +
  geom_vline(xintercept = 1, linetype = "dashed", color = "grey45", linewidth = 0.4) +
  geom_errorbarh(data = forest_df %>% filter(row_type == "data"), aes(xmin = lower95, xmax = upper95), height = 0.12, linewidth = 0.45) +
  geom_point(data = forest_df %>% filter(row_type == "data"), aes(x = HR), shape = 15, size = 1.8) +
  scale_x_continuous(trans = "log10", breaks = c(0.8, 1, 1.2, 1.5, 2), limits = c(0.75, 2.4)) +
  coord_cartesian(ylim = c(0.5, max(forest_df$y) + 0.6), expand = FALSE) +
  labs(x = NULL, y = NULL) +
  theme_classic(base_size = 10) +
  theme(axis.text.y = element_blank(), axis.ticks.y = element_blank(), axis.line.y = element_blank(),
        plot.margin = margin(0, 0, 0, 0))
g_right <- ggplot(forest_df, aes(y = y)) +
  geom_rect(data = bg %>% filter(shade), aes(ymin = y - 0.5, ymax = y + 0.5), xmin = -Inf, xmax = Inf, fill = "#EEF2F1", inherit.aes = FALSE) +
  geom_text(aes(x = 0.00, label = p_text, fontface = fontface), hjust = 0, size = 3.2) +
  geom_text(aes(x = 0.55, label = p_int_text, fontface = fontface), hjust = 0, size = 3.2) +
  coord_cartesian(xlim = c(0, 1.05), ylim = c(0.5, max(forest_df$y) + 0.6), expand = FALSE) +
  theme_void()
p7 <- plot_grid(g_left, g_mid, g_right, nrow = 1, rel_widths = c(0.52, 0.24, 0.24), align = "h")
save_fig(p7, "FIG7_subgroup_forest_template_style", 12, 8)

# FIG S2 - secondary outcome RCS, panels A-E only.
rcs_files <- c("A" = "RCS_curve_data_shock_adjusted.csv",
               "B" = "RCS_curve_data_aki_adjusted.csv",
               "C" = "RCS_curve_data_vent_adjusted.csv",
               "D" = "RCS_curve_data_rrt_adjusted.csv",
               "E" = "RCS_curve_data_vaso_adjusted.csv")
rcs_sec <- bind_rows(lapply(names(rcs_files), function(panel) {
  read_csv2(file.path(part1_tables, rcs_files[[panel]])) %>% mutate(panel = panel)
}))
p_s2 <- ggplot(rcs_sec, aes(exposure_value, OR)) +
  geom_ribbon(aes(ymin = lower95, ymax = upper95), fill = "#2C7FB8", alpha = 0.16) +
  geom_line(color = "#2C7FB8", linewidth = 0.85) +
  geom_hline(yintercept = 1, linetype = "dashed", color = "grey50") +
  facet_wrap(~panel, scales = "free_y", ncol = 3) +
  labs(x = "Baseline SOFA-2", y = "Odds ratio") +
  theme_pub(10)
save_fig(p_s2, "FIGS2_secondary_outcomes_RCS", 12, 7.5)

# FIG S3-S6 - consensus clustering validation, modeled after reference S3-S6.
set.seed(2026)
traj_data <- part4_obj$trajectory_data %>%
  select(sofa2_d1, sofa2_d2, sofa2_d3) %>%
  filter(if_all(everything(), ~ !is.na(.)))
n_sample <- min(900, nrow(traj_data))
idx <- sample(seq_len(nrow(traj_data)), n_sample)
xmat <- scale(as.matrix(traj_data[idx, ]))
consensus_for_k <- function(k, reps = 60, p_item = 0.8) {
  n <- nrow(xmat)
  mat <- matrix(0, n, n)
  den <- matrix(0, n, n)
  for (r in seq_len(reps)) {
    ii <- sort(sample(seq_len(n), floor(p_item * n)))
    km <- kmeans(xmat[ii, , drop = FALSE], centers = k, nstart = 20, iter.max = 100)
    same <- outer(km$cluster, km$cluster, "==") * 1
    mat[ii, ii] <- mat[ii, ii] + same
    den[ii, ii] <- den[ii, ii] + 1
  }
  cm <- mat / den
  cm[is.na(cm)] <- 0
  diag(cm) <- 1
  full_km <- kmeans(xmat, centers = k, nstart = 50)
  ord <- hclust(as.dist(1 - cm), method = "average")$order
  list(k = k, cm = cm, ord = ord, cluster = full_km$cluster)
}
cons <- lapply(2:6, consensus_for_k)
saveRDS(cons, file.path(out_dir, "consensus_clustering_objects_K2_K6.rds"))
heat_df <- bind_rows(lapply(cons, function(o) {
  cm <- o$cm[o$ord, o$ord]
  as.data.frame(as.table(cm)) %>%
    transmute(x = as.integer(Var1), y = as.integer(Var2), value = Freq, panel = paste0("K=", o$k))
}))
p_s3 <- ggplot(heat_df, aes(x, y, fill = value)) +
  geom_raster() +
  scale_fill_gradientn(colors = c("white", "#C8D0FF", "#0000FF"), limits = c(0, 1), name = "Consensus") +
  facet_wrap(~panel, ncol = 3) +
  coord_equal() +
  theme_void(base_size = 11) +
  theme(strip.text = element_text(face = "bold", size = 14), legend.position = "right")
save_fig(p_s3, "FIGS3_consensus_matrices_K2_K6", 11, 8)

cluster_cons <- bind_rows(lapply(cons, function(o) {
  bind_rows(lapply(sort(unique(o$cluster)), function(cl) {
    members <- which(o$cluster == cl)
    val <- if (length(members) > 1) mean(o$cm[members, members][upper.tri(o$cm[members, members])], na.rm = TRUE) else NA_real_
    tibble(K = paste0("K=", o$k), cluster = as.factor(cl), consensus = val)
  }))
}))
write_csv2(cluster_cons, file.path(out_dir, "FIGS4_cluster_consensus_values.csv"))
p_s4 <- ggplot(cluster_cons, aes(K, consensus, fill = cluster)) +
  geom_col(position = position_dodge(width = 0.75), width = 0.68, color = "black", linewidth = 0.15) +
  geom_hline(yintercept = 0.8, linetype = "dashed", color = "grey40") +
  scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.2)) +
  scale_fill_brewer(palette = "Paired") +
  labs(x = NULL, y = "Cluster-consensus value") +
  theme_pub()
save_fig(p_s4, "FIGS4_cluster_consensus_plot", 8, 5)

cdf_df <- bind_rows(lapply(cons, function(o) {
  vals <- o$cm[upper.tri(o$cm)]
  tibble(value = sort(vals), cdf = seq_along(vals) / length(vals), K = paste0("K=", o$k))
}))
area_df <- cdf_df %>%
  group_by(K) %>%
  summarise(area = sum(diff(value) * (head(cdf, -1) + tail(cdf, -1)) / 2), .groups = "drop") %>%
  mutate(k_num = as.integer(gsub("K=", "", K))) %>%
  arrange(k_num) %>%
  mutate(delta_area = area - lag(area))
write_csv2(area_df, file.path(out_dir, "FIGS5_CDF_delta_area_values.csv"))
p_s5a <- ggplot(cdf_df, aes(value, cdf, color = K)) +
  geom_line(linewidth = 0.95) +
  scale_color_brewer(palette = "Dark2") +
  labs(title = "A", x = "Consensus index", y = "CDF") +
  theme_pub()
p_s5b <- ggplot(area_df %>% filter(!is.na(delta_area)), aes(k_num, delta_area)) +
  geom_line(color = "#00A6D6", linewidth = 1) +
  geom_point(shape = 21, fill = "white", color = "black", size = 3, stroke = 1.2) +
  scale_x_continuous(breaks = 3:6) +
  labs(title = "B", x = "Number of clusters (K)", y = "Delta area") +
  theme_pub()
save_fig(p_s5a + p_s5b, "FIGS5_CDF_delta_area", 12, 5)

# Predict final K=4 class from increasing observation window.
km4 <- part4_obj$kmeans_k4
traj_scaled_full <- scale(as.matrix(part4_obj$trajectory_data[, c("sofa2_d1", "sofa2_d2", "sofa2_d3")]))
centers4 <- km4$centers
pred_by_dims <- function(dims) {
  dist <- sapply(seq_len(nrow(centers4)), function(i) {
    rowSums((traj_scaled_full[, dims, drop = FALSE] -
               matrix(centers4[i, dims], nrow(traj_scaled_full), length(dims), byrow = TRUE))^2)
  })
  apply(dist, 1, which.min)
}
acc_df <- tibble(
  window = factor(c("Day 1", "Day 1-2"), levels = c("Day 1", "Day 1-2")),
  accuracy = c(
    mean(pred_by_dims(1) == km4$cluster),
    mean(pred_by_dims(1:2) == km4$cluster)
  )
)
write_csv2(acc_df, file.path(out_dir, "FIGS6_observation_window_accuracy.csv"))
p_s6 <- ggplot(acc_df, aes(window, accuracy, fill = window)) +
  geom_col(width = 0.55, color = "white", linewidth = 0.4) +
  geom_text(aes(label = sprintf("%.2f", accuracy * 100)), vjust = -0.35, fontface = "bold", size = 4) +
  scale_y_continuous(limits = c(0, 1.05), labels = percent_format(accuracy = 1)) +
  scale_fill_manual(values = c("#66C2A5", "#80B1D3")) +
  labs(x = "Observation window", y = "Trajectory class prediction accuracy") +
  theme_pub() +
  theme(legend.position = "none")
save_fig(p_s6, "FIGS6_observation_window_accuracy", 6, 5)

manifest <- tibble(
  figure = c("FIG1", "FIG2", "FIG3", "FIG4", "FIG5", "FIG6", "FIG7", "FIG S2", "FIG S3", "FIG S4", "FIG S5", "FIG S6"),
  file = c("FIG1_flowchart_template_style.png", "FIG2_SOFA2_RCS_KM.png", "FIG3_prediction_performance_MIMIC.png",
           "FIG4_MaxStat_cutoff_MIMIC_KM.png", "FIG5_MIMIC_SOFA2_trajectories.png", "FIG6_external_validation.png",
           "FIG7_subgroup_forest_template_style.png", "FIGS2_secondary_outcomes_RCS.png",
           "FIGS3_consensus_matrices_K2_K6.png", "FIGS4_cluster_consensus_plot.png",
           "FIGS5_CDF_delta_area.png", "FIGS6_observation_window_accuracy.png")
)
write_csv2(manifest, file.path(out_dir, "manuscript_figures_v3_manifest.csv"))
print(manifest)

