/*
Final eICU-CRD inclusion/exclusion count audit.

No SOFA-2 availability/value criterion is used for cohort membership.
The final adult sepsis-source membership table must be reconstructed locally from
credentialed eICU data and the study infection/sepsis definition; it must not be
created by filtering on SOFA-2.

Expected manuscript flow anchors:
  all ICU stays: 200,859
  excluded age <=65 or missing: 102,230 -> 98,629
  excluded repeated ICU stay in same hospitalization: 17,697 -> 80,932
  excluded ICU LOS <48 h: 46,451 -> 34,481
  excluded from final adult sepsis-source cohort: 21,844 -> 12,637
  missing/out-of-window sepsis timing: 1,200 -> final 11,437

Before running, create `work.eicu_final_sepsis_source_staging` containing one row
per patientunitstayid in the final adult sepsis-source cohort and `sepsis3_hr`.
SOFA-2 fields may be present for downstream analysis but are not used here.
*/
with icustay_detail as (
  select
    p.uniquepid, p.patienthealthsystemstayid, p.patientunitstayid, p.unitvisitnumber,
    case when p.age = '> 89' then 90 when p.age ~ '^[0-9]+$' then p.age::integer else null end as age,
    0 as unitadmitoffset, p.unitdischargeoffset
  from public.patient p
),
ranked_after_age as (
  select d.*, dense_rank() over (
    partition by d.patienthealthsystemstayid
    order by d.unitvisitnumber, d.unitadmitoffset, d.patientunitstayid
  ) as _filtered_icu_seq
  from icustay_detail d
  where d.age > 65
),
after_first_icu as (
  select * from ranked_after_age where _filtered_icu_seq = 1
),
after_los as (
  select * from after_first_icu
  where unitdischargeoffset is not null and unitdischargeoffset::numeric / 1440 >= 2
),
adult_sepsis_source as (
  select a.*, s.sepsis3_hr
  from after_los a
  inner join work.eicu_final_sepsis_source_staging s
    on s.patientunitstayid = a.patientunitstayid
),
final_cohort as (
  select * from adult_sepsis_source where sepsis3_hr between 0 and 48
)
select '00_eicu_v2_0_icu_stays' as step, count(*)::bigint as n from icustay_detail
union all select '01_exclude_age_le_65_or_missing', count(*)::bigint from icustay_detail where age is null or age <= 65
union all select '02_after_age_gt_65', count(*)::bigint from ranked_after_age
union all select '03_exclude_repeated_icu_same_hospitalization', count(*)::bigint from ranked_after_age where _filtered_icu_seq > 1
union all select '04_after_first_icu_per_hospitalization', count(*)::bigint from after_first_icu
union all select '05_exclude_icu_los_lt_48h', count(*)::bigint from after_first_icu where unitdischargeoffset is null or unitdischargeoffset::numeric / 1440 < 2
union all select '06_after_age_first_icu_los_ge_48h', count(*)::bigint from after_los
union all select '07_exclude_not_in_final_adult_sepsis_source', count(*)::bigint from after_los a where not exists (select 1 from work.eicu_final_sepsis_source_staging s where s.patientunitstayid = a.patientunitstayid)
union all select '08_final_adult_sepsis_source', count(*)::bigint from adult_sepsis_source
union all select '09_exclude_sepsis3_time_missing_or_outside_0_48h', count(*)::bigint from adult_sepsis_source where sepsis3_hr is null or sepsis3_hr < 0 or sepsis3_hr > 48
union all select '10_final_eicu_validation_cohort', count(*)::bigint from final_cohort
order by step;
