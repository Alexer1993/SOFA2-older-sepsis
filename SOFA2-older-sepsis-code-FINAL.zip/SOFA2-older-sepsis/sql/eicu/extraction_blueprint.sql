/*
Local eICU extraction logic for the SOFA2 older sepsis project.

Purpose:
  Convert the pasted reference SQL, which depends on prebuilt schemas such as
  easydata and eicu_sofa2, into a local PostgreSQL workflow based on the
  deployed eICU database:

    database: eicu
    schema:   public

This file is a blueprint. It is intentionally not executed automatically.
For reproducible analysis, run the blocks in order after confirming each
derived table definition.
*/

/* -------------------------------------------------------------------------
Layer 0. Raw source tables available locally
--------------------------------------------------------------------------- */

/*
Core raw eICU tables used by this workflow:

public.patient              ICU stay identity, demographics, LOS, mortality
public.hospital             hospital-level descriptors
public.diagnosis            diagnosis strings and ICD-9 codes
public.pasthistory          comorbidity history text
public.apacheapsvar         APACHE physiology variables, GCS components, urine
public.apachepredvar        APACHE prediction variables and day-1 flags
public.apachepatientresult  APACHE score, ICU/hospital mortality and LOS
public.lab                  laboratory results with offsets
public.vitalperiodic        periodic vitals
public.vitalaperiodic       nonperiodic vitals
public.intakeoutput         fluid intake/output, dialysis totals
public.infusiondrug         vasoactive and other infusion records
public.respiratorycare      ventilation episode offsets
public.respiratorycharting  respiratory charting, ventilator settings
public.treatment            treatment terms, including dialysis/ventilation cues
public.microlab             microbiology/culture data
public.medication           medication records
public.note                 admission notes, smoking status
*/


/* -------------------------------------------------------------------------
Layer 1. Local replacement for easydata.icustay_detail
--------------------------------------------------------------------------- */

/*
Reference code expected:
  easydata.icustay_detail

Local replacement:
  derive directly from public.patient, optionally left-joining public.hospital
  and public.apachepatientresult.

Important eICU time convention:
  Offsets are minutes relative to ICU unit admission. Negative values can occur
  for pre-ICU hospital events.
*/

with icustay_detail as (
  select
    p.uniquepid,
    p.patienthealthsystemstayid,
    p.patientunitstayid,
    p.unitvisitnumber,
    h.region,
    p.ethnicity,
    p.unittype,
    p.gender,
    case
      when p.age = '> 89' then 90
      when p.age ~ '^[0-9]+$' then p.age::integer
      else null
    end as age,
    0 as unitadmitoffset,
    p.unitdischargeoffset,
    p.hospitaladmitoffset,
    p.hospitaldischargeoffset,
    round((p.hospitaldischargeoffset::numeric - p.hospitaladmitoffset::numeric) / 1440, 2) as los_hospital_days,
    round(p.unitdischargeoffset::numeric / 1440, 2) as los_icu_days,
    case when p.hospitaldischargestatus = 'Expired' then 1 else 0 end as hosp_mort,
    case when p.unitdischargestatus = 'Expired' then 1 else 0 end as icu_expire_flag,
    p.admissionheight as height,
    p.admissionweight as weight,
    p.unitadmitsource,
    p.hospitaladmitsource,
    p.apacheadmissiondx
  from public.patient p
  left join public.hospital h
    on h.hospitalid = p.hospitalid
)
select *
from icustay_detail
limit 0;


/* -------------------------------------------------------------------------
Layer 2. Local base cohort logic
--------------------------------------------------------------------------- */

/*
Reference inclusion logic:
  age > 65
  first ICU stay per patienthealthsystemstayid
  ICU length of stay >= 2 days
  patientunitstayid in public.sepsis_adult_eicu

Local status:
  public.sepsis_adult_eicu is not present in the current local eICU database.
  It must be derived in Layer 4 before the final cohort is run.
*/

with icustay_detail as (
  select
    p.uniquepid,
    p.patienthealthsystemstayid,
    p.patientunitstayid,
    p.unitvisitnumber,
    h.region,
    p.ethnicity,
    p.unittype,
    p.gender,
    case
      when p.age = '> 89' then 90
      when p.age ~ '^[0-9]+$' then p.age::integer
      else null
    end as age,
    0 as unitadmitoffset,
    p.unitdischargeoffset,
    p.hospitaladmitoffset,
    p.hospitaldischargeoffset,
    round((p.hospitaldischargeoffset::numeric - p.hospitaladmitoffset::numeric) / 1440, 2) as los_hospital_days,
    round(p.unitdischargeoffset::numeric / 1440, 2) as los_icu_days,
    case when p.hospitaldischargestatus = 'Expired' then 1 else 0 end as hosp_mort,
    case when p.unitdischargestatus = 'Expired' then 1 else 0 end as icu_expire_flag,
    p.admissionheight as height,
    p.admissionweight as weight,
    p.unitadmitsource,
    p.hospitaladmitsource,
    p.apacheadmissiondx
  from public.patient p
  left join public.hospital h
    on h.hospitalid = p.hospitalid
),
first_icu as (
  select
    d.*,
    dense_rank() over (
      partition by d.patienthealthsystemstayid
      order by d.unitvisitnumber, d.unitadmitoffset, d.patientunitstayid
    ) as filtered_icu_seq
  from icustay_detail d
)
select
  *,
  case when los_hospital_days <= 28 and hosp_mort = 1 then 1 else 0 end as mortality_28_inhospital,
  case when los_hospital_days <= 30 and hosp_mort = 1 then 1 else 0 end as mortality_30_inhospital,
  case when los_hospital_days <= 90 and hosp_mort = 1 then 1 else 0 end as mortality_90_inhospital,
  case when los_hospital_days <= 365 and hosp_mort = 1 then 1 else 0 end as mortality_365_inhospital
from first_icu
where filtered_icu_seq = 1
  and los_icu_days >= 2
  and age > 65
  -- Enable after deriving local sepsis table:
  -- and patientunitstayid in (select patientunitstayid from eicu_derived.sepsis_adult_eicu)
limit 0;


/* -------------------------------------------------------------------------
Layer 3. Feature extraction templates
--------------------------------------------------------------------------- */

/*
3A. First lab value in a window.
Replace :lab_name and :window_start/:window_end with fixed values in a concrete
script. eICU lab offsets are minutes from ICU admission.
*/

with cohort as (
  select patientunitstayid
  from public.patient
  limit 0
),
lab_first as (
  select
    l.patientunitstayid,
    l.labresult as value_first,
    l.labresultoffset as value_offset,
    row_number() over (
      partition by l.patientunitstayid
      order by l.labresultoffset, l.labid
    ) as rn
  from public.lab l
  join cohort c using (patientunitstayid)
  where lower(l.labname) = lower(:lab_name)
    and l.labresult is not null
    and l.labresultoffset between :window_start and :window_end
)
select patientunitstayid, value_first, value_offset
from lab_first
where rn = 1;

/*
3B. Vasoactive therapy.
The local eICU raw table is public.infusiondrug. Drug names should be mapped
by case-insensitive pattern matching and then manually audited.
*/

with cohort as (
  select patientunitstayid
  from public.patient
  limit 0
),
vaso as (
  select
    i.patientunitstayid,
    min(i.infusionoffset) as vasoactive_first_offset
  from public.infusiondrug i
  join cohort c using (patientunitstayid)
  where lower(i.drugname) ~ '(norepinephrine|levophed|epinephrine|dopamine|dobutamine|phenylephrine|neosynephrine|vasopressin)'
  group by i.patientunitstayid
)
select
  c.patientunitstayid,
  case when v.patientunitstayid is null then 0 else 1 end as vasoactive_use,
  v.vasoactive_first_offset
from cohort c
left join vaso v using (patientunitstayid);

/*
3C. Invasive ventilation episodes.
Use respiratorycare offsets when available. Additional validation can use
respiratorycharting/treatment.
*/

with cohort as (
  select patientunitstayid
  from public.patient
  limit 0
)
select
  r.patientunitstayid,
  min(r.ventstartoffset) as invasivevent_first_offset,
  max(r.ventendoffset) as invasivevent_last_offset
from public.respiratorycare r
join cohort c using (patientunitstayid)
where r.ventstartoffset is not null
group by r.patientunitstayid;

/*
3D. RRT/CRRT.
No single derived table exists locally. Candidate sources:
  public.intakeoutput.dialysistotal
  public.treatment treatment strings
  public.apacheapsvar.dialysis
*/

with cohort as (
  select patientunitstayid
  from public.patient
  limit 0
),
rrt_io as (
  select
    io.patientunitstayid,
    min(io.intakeoutputoffset) as rrt_first_offset
  from public.intakeoutput io
  join cohort c using (patientunitstayid)
  where io.dialysistotal is not null
     or lower(coalesce(io.cellpath, '')) like '%dialysis%'
     or lower(coalesce(io.celllabel, '')) like '%dialysis%'
  group by io.patientunitstayid
),
rrt_treatment as (
  select
    t.patientunitstayid,
    min(t.treatmentoffset) as rrt_first_offset
  from public.treatment t
  join cohort c using (patientunitstayid)
  where lower(t.treatmentstring) ~ '(dialysis|crrt|cvvh|rrt|renal replacement)'
  group by t.patientunitstayid
)
select
  c.patientunitstayid,
  least(rrt_io.rrt_first_offset, rrt_treatment.rrt_first_offset) as rrt_first_offset
from cohort c
left join rrt_io using (patientunitstayid)
left join rrt_treatment using (patientunitstayid);


/* -------------------------------------------------------------------------
Layer 4. SOFA/SOFA2 and sepsis derivation placeholders
--------------------------------------------------------------------------- */

/*
The pasted reference code assumes:
  public.sepsis_adult_eicu
  public.septic_shock_eicu
  eicu_sofa2.sepsis3_sofa2
  easydata.kdigo_stages
  public.pivoted_vent_eicu

These are not present in the current local eICU public schema.

Recommended local implementation order:
  1. Create an hourly grid by patientunitstayid and hr.
  2. Derive hourly labs/vitals/organ support from raw public tables.
  3. Calculate SOFA and SOFA2 organ subscores per hour using an authorized implementation.
  4. Preserve explicit source-field availability flags. The retained public materials do not
     establish a general missing-component=0 or LOCF rule for eICU; do not invent one.
  5. Derive suspected infection time from diagnosis plus systemic-antibiotic logic used in this study.
  6. Detect Sepsis-3 and retain first fulfillment within 0-48 h after ICU admission.
  7. Construct cohort membership without using SOFA-2 availability/value as an exclusion criterion.
*/

