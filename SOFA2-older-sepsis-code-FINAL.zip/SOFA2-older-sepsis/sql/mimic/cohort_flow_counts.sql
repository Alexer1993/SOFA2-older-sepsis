/*
MIMIC-IV final inclusion/exclusion count audit.

Final cohort definition does NOT include a SOFA-2 availability/value filter.
Expected final audit anchors from the manuscript revision:
  after age >65 + first ICU per hospitalization + ICU LOS >=48 h: 23,174
  did not meet Sepsis-3 within 0-48 h: 10,531
  final MIMIC-IV cohort: 12,643
*/
with icu_base as (
  select icu.subject_id, icu.hadm_id, icu.stay_id, icu.icu_intime, icu.icu_outtime, icu.los_icu, age.age
  from mimiciv_derived.icustay_detail icu
  left join mimiciv_derived.age age on age.hadm_id = icu.hadm_id
),
after_age as (
  select * from icu_base where age > 65
),
ranked_after_age as (
  select *, row_number() over (partition by hadm_id order by icu_intime asc, stay_id asc) as rn
  from after_age
),
after_first_icu as (
  select * from ranked_after_age where rn = 1
),
after_los as (
  select * from after_first_icu where los_icu >= 2.0
),
sepsis_time_calc as (
  select stay_id, suspected_infection_time, sofa_time,
         greatest(suspected_infection_time, sofa_time) as sepsis_time
  from mimiciv_derived.sepsis3
),
after_sepsis_0_48h as (
  select a.*, s.suspected_infection_time, s.sofa_time, s.sepsis_time
  from after_los a
  inner join sepsis_time_calc s on s.stay_id = a.stay_id
  where s.sepsis_time is not null
    and s.sepsis_time >= a.icu_intime
    and s.sepsis_time <= a.icu_intime + interval '48 hour'
)
select '00_mimic_icu_stays' as step, count(*)::bigint as n from icu_base
union all select '01_exclude_age_le_65_or_missing', count(*)::bigint from icu_base where age is null or age <= 65
union all select '02_after_age_gt_65', count(*)::bigint from after_age
union all select '03_exclude_repeated_icu_same_hadm_after_age', count(*)::bigint from ranked_after_age where rn > 1
union all select '04_after_first_icu_per_hadm', count(*)::bigint from after_first_icu
union all select '05_exclude_icu_los_lt_48h_after_age_first', count(*)::bigint from after_first_icu where los_icu is null or los_icu < 2.0
union all select '06_after_age_first_los_ge_48h', count(*)::bigint from after_los
union all select '07_exclude_not_meeting_sepsis3_0_48h', count(*)::bigint from after_los where stay_id not in (select stay_id from after_sepsis_0_48h)
union all select '08_final_mimic_cohort', count(*)::bigint from after_sepsis_0_48h
order by step;
